//! 使用 libunwind/gcc_s/etc API 的 Backtrace 支持。
//!
//! 该模块包含了使用 libunwind 样式的 API 展开栈的功能。
//! 请注意，有很多类似 libunwind 的 API 的实现，这只是想一次与大多数兼容，而不是挑剔。
//!
//!
//! libunwind API 由 `_Unwind_Backtrace` 提供支持，实际上在生成回溯方面非常可靠。
//! 尚不清楚它是如何工作的 (帧指针？eh_frame 信息？两者都有？)，但似乎可行！
//!
//! 该模块的大部分复杂性是处理 libunwind 实现中的各种平台差异。
//! 否则，这是对 libunwind API 的非常简单的 Rust 绑定。
//!
//! 这是当前所有非 Windows 平台的默认展开 API。
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// 使用原始的 libunwind 指针，它只能以只读线程安全的方式进行访问，因此它是 `Sync`。
// 通过 `Clone` 发送到其他线程时，我们总是切换到不保留内部指针的版本，因此我们也应该是 `Send`。
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // macOS 链接器发出一个 "compact" 展开表，如果函数有 LSDA 或其编码与前一个条目不同，则该表只包含该函数的一个条目。
        // 因此，在 macOS 上，`_Unwind_FindEnclosingFunction` 是不可靠的 (它可以返回一个指向一些完全不相关的函数的指针)。
        // 相反，我们总是返回 ip。
        //
        // https://github.com/rust-lang/rust/issues/74771#issuecomment-664056788
        //
        // 请注意，由于此条款，在 macOS 上跳过了 `skip_inner_frames.rs` 测试，如果修复了该问题，理论上可以在 macOS 上运行该测试！
        //
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// 展开用于回溯的库接口
///
/// 请注意，死代码是允许的，因为这里只是绑定 iOS 并没有使用所有绑定，但是添加更多特定于平台的配置会严重污染代码
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // 仅由 ARM EABI 使用
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;
    }

    cfg_if::cfg_if! {
        // 自 GCC 4.2.0 以来可用，应该可以满足我们的目的
        if #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "horizon", target_arch = "arm"))
        ))] {
            extern "C" {
                pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
                pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

                #[cfg(not(all(target_os = "linux", target_arch = "s390x")))]
                // 此函数用词不当：它没有获得此框架的规范框架地址 (即调用者框架的 SP)，而是返回了该框架的 SP。
                //
                //
                // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
                //
                #[link_name = "_Unwind_GetCFA"]
                pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

            }

            // s390x 使用了一个有偏差的 CFA 值，因此我们需要使用 _Unwind_GetGR 来获取栈指针寄存器 (%r15)，而不是依赖于 _Unwind_GetCFA。
            //
            //
            #[cfg(all(target_os = "linux", target_arch = "s390x"))]
            pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                extern "C" {
                    pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
                }
                _Unwind_GetGR(ctx, 15)
            }
        } else {
            // 在 android 和 arm 上，函数 `_Unwind_GetIP` 和其他许多函数都是宏，因此我们定义了包含宏扩展的函数。
            //
            //
            // TODO: 链接到定义这些宏的头文件 (如果可以找到的话)。
            // (我，fitzgen，找不到这些宏扩展中的某些最初从中借用的头文件。)
            //
            //
            #[repr(C)]
            enum _Unwind_VRS_Result {
                _UVRSR_OK = 0,
                _UVRSR_NOT_IMPLEMENTED = 1,
                _UVRSR_FAILED = 2,
            }
            #[repr(C)]
            enum _Unwind_VRS_RegClass {
                _UVRSC_CORE = 0,
                _UVRSC_VFP = 1,
                _UVRSC_FPA = 2,
                _UVRSC_WMMXD = 3,
                _UVRSC_WMMXC = 4,
            }
            #[repr(C)]
            enum _Unwind_VRS_DataRepresentation {
                _UVRSD_UINT32 = 0,
                _UVRSD_VFPX = 1,
                _UVRSD_FPAX = 2,
                _UVRSD_UINT64 = 3,
                _UVRSD_FLOAT = 4,
                _UVRSD_DOUBLE = 5,
            }

            type _Unwind_Word = libc::c_uint;
            extern "C" {
                fn _Unwind_VRS_Get(
                    ctx: *mut _Unwind_Context,
                    klass: _Unwind_VRS_RegClass,
                    word: _Unwind_Word,
                    repr: _Unwind_VRS_DataRepresentation,
                    data: *mut c_void,
                ) -> _Unwind_VRS_Result;
            }

            pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                let mut val: _Unwind_Word = 0;
                let ptr = &mut val as *mut _Unwind_Word;
                let _ = _Unwind_VRS_Get(
                    ctx,
                    _Unwind_VRS_RegClass::_UVRSC_CORE,
                    15,
                    _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                    ptr as *mut c_void,
                );
                (val & !1) as libc::uintptr_t
            }

            // R13 是 arm 上的栈指针。
            const SP: _Unwind_Word = 13;

            pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
                let mut val: _Unwind_Word = 0;
                let ptr = &mut val as *mut _Unwind_Word;
                let _ = _Unwind_VRS_Get(
                    ctx,
                    _Unwind_VRS_RegClass::_UVRSC_CORE,
                    SP,
                    _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                    ptr as *mut c_void,
                );
                val as libc::uintptr_t
            }

            // Android 或 ARM/Linux 上也不存在此函数，因此请使其成为 no-op。
            //
            pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
                pc
            }
        }
    }
}
