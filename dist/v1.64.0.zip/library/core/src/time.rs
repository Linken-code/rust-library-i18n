#![stable(feature = "duration_core", since = "1.25.0")]

//! 时间量化。
//!
//! # Examples:
//!
//! 有多种方法可以创建新的 [`Duration`]：
//!
//! ```
//! # use std::time::Duration;
//! let five_seconds = Duration::from_secs(5);
//! assert_eq!(five_seconds, Duration::from_millis(5_000));
//! assert_eq!(five_seconds, Duration::from_micros(5_000_000));
//! assert_eq!(five_seconds, Duration::from_nanos(5_000_000_000));
//!
//! let ten_seconds = Duration::from_secs(10);
//! let seven_nanos = Duration::from_nanos(7);
//! let total = ten_seconds + seven_nanos;
//! assert_eq!(total, Duration::new(10, 7));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// `Duration` 类型代表时间跨度，通常用于系统超时。
///
/// 每个 `Duration` 由整数秒和以纳秒表示的小数部分组成。
/// 如果底层系统不支持纳秒级精度，则绑定系统超时的 API 通常会将纳秒数四舍五入。
///
/// [`Duration`] 实现了许多常见的 traits，包括 [`Add`]，[`Sub`] 和其他 [`ops`] traits。它通过返回零长度 `Duration` 来实现 [`Default`]。
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # 格式化 `Duration` 值
///
/// `Duration` 故意不实现 `Display` impl，因为有多种方法可以设置时间跨度的格式，以提高人类的可读性。
/// `Duration` 提供了一个 `Debug` impl，它显示了值的完整精度。
///
/// `Debug` 输出使用非 ASCII "µs" 后缀微秒。
/// 如果您的程序输出可能出现在不依赖于完全 Unicode 兼容性的上下文中，则您可能希望自己格式化 `Duration` 对象或使用 crate 这样做。
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
#[cfg_attr(not(test), rustc_diagnostic_item = "Duration")]
pub struct Duration {
    secs: u64,
    nanos: u32, // Always 0 <= nanos < NANOS_PER_SEC
}

impl Duration {
    /// 持续时间为一秒。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// 一毫秒的持续时间。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// 一微秒的持续时间。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// 一纳秒的持续时间。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// 持续时间为零。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[stable(feature = "duration_zero", since = "1.53.0")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// 最大持续时间。
    ///
    /// 根据平台的需要可能有所不同。
    /// 必须能够包含两个 [`Instant`] 实例或两个 [`SystemTime`] 实例之间的差异。
    /// 该约束使其在实践中的值约为 584,942,417,355 年，目前在所有平台上都使用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    /// [`Instant`]: ../../std/time/struct.Instant.html
    /// [`SystemTime`]: ../../std/time/struct.SystemTime.html
    #[stable(feature = "duration_saturating_ops", since = "1.53.0")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// 根据指定的整数秒数和其他纳秒数创建一个新的 `Duration`。
    ///
    /// 如果纳秒数大于 10 亿 (十亿分之一秒)，则它将延续到提供的秒数中。
    ///
    ///
    /// # Panics
    ///
    /// 如果纳秒的进位溢出秒计数器，则此构造方法将为 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// 根据指定的整数秒创建一个新的 `Duration`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[must_use]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// 从指定的毫秒数创建一个新的 `Duration`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[must_use]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// 从指定的微秒数创建一个新的 `Duration`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[must_use]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// 从指定的纳秒数创建一个新的 `Duration`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[must_use]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// 如果此 `Duration` 不跨越时间，则返回 true。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[must_use]
    #[stable(feature = "duration_zero", since = "1.53.0")]
    #[rustc_const_stable(feature = "duration_zero", since = "1.53.0")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// 返回此 `Duration` 包含的 _whole_ 秒数。
    ///
    /// 返回的值不包括持续时间的小数 (nanosecond) 部分，可以使用 [`subsec_nanos`] 获得。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// 要确定 `Duration` 代表的总秒数，请结合使用 `as_secs` 和 [`subsec_nanos`]：
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// 以毫秒为单位返回此 `Duration` 的小数部分。
    ///
    /// 当以毫秒表示时，这个方法不会返回持续时间的长度。
    /// 返回的数字始终代表秒的小数部分 (即，小于一千)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// 以整个微秒为单位返回此 `Duration` 的小数部分。
    ///
    /// 当以微秒表示时，这个方法不会返回持续时间的长度。
    /// 返回的数字始终代表秒的小数部分 (即，小于一百万)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// 返回此 `Duration` 的小数部分，以纳秒为单位。
    ///
    /// 当以纳秒表示时，这个方法不会返回持续时间的长度。
    /// 返回的数字始终代表秒的小数部分 (即，小于十亿)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// 返回此 `Duration` 包含的总毫秒数。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[must_use]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// 返回此 `Duration` 包含的总微秒数。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[must_use]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// 返回此 `Duration` 包含的纳秒总数。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[must_use]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// 检查 `Duration` 的添加。
    /// 计算 `self + other`，如果发生溢出则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` 饱和添加。
    /// 计算 `self + other`，如果发生溢出则返回 [`Duration::MAX`]。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[stable(feature = "duration_saturating_ops", since = "1.53.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// 检查 `Duration` 减法。
    /// 计算 `self - other`，如果结果为负或发生溢出，则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else if let Some(sub_secs) = secs.checked_sub(1) {
                secs = sub_secs;
                self.nanos + NANOS_PER_SEC - rhs.nanos
            } else {
                return None;
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` 减法饱和。
    /// 计算 `self - other`，如果结果为负或发生溢出，则返回 [`Duration::ZERO`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[stable(feature = "duration_saturating_ops", since = "1.53.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// 检查 `Duration` 乘法。
    /// 计算 `self * other`，如果发生溢出则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // 将 u64 乘以纳秒，因为它不能那样溢出。
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// 饱和 `Duration` 乘法。
    /// 计算 `self * other`，如果发生溢出则返回 [`Duration::MAX`]。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[stable(feature = "duration_saturating_ops", since = "1.53.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// 检查 `Duration` 分区。
    /// 计算 `self / other`，如果为 `other == 0`，则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts_2", since = "1.58.0")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// 以 `f64` 形式返回此 `Duration` 包含的秒数。
    ///
    /// 返回的值的确包含持续时间的小数 (nanosecond) 部分。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// 以 `f32` 形式返回此 `Duration` 包含的秒数。
    ///
    /// 返回的值的确包含持续时间的小数 (nanosecond) 部分。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// 从指定的秒数 (表示为 `f64`) 创建一个新的 `Duration`。
    ///
    /// # Panics
    /// 如果 `secs` 为 negative、溢出 `Duration` 或不是有限的，此构造函数将出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let res = Duration::from_secs_f64(0.0);
    /// assert_eq!(res, Duration::new(0, 0));
    /// let res = Duration::from_secs_f64(1e-20);
    /// assert_eq!(res, Duration::new(0, 0));
    /// let res = Duration::from_secs_f64(4.2e-7);
    /// assert_eq!(res, Duration::new(0, 420));
    /// let res = Duration::from_secs_f64(2.7);
    /// assert_eq!(res, Duration::new(2, 700_000_000));
    /// let res = Duration::from_secs_f64(3e10);
    /// assert_eq!(res, Duration::new(30_000_000_000, 0));
    /// // subnormal 浮点
    /// let res = Duration::from_secs_f64(f64::from_bits(1));
    /// assert_eq!(res, Duration::new(0, 0));
    /// // 转换使用舍入
    /// let res = Duration::from_secs_f64(0.999e-9);
    /// assert_eq!(res, Duration::new(0, 1));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        match Duration::try_from_secs_f64(secs) {
            Ok(v) => v,
            Err(e) => panic!("{}", e.description()),
        }
    }

    /// 从指定的秒数 (表示为 `f32`) 创建一个新的 `Duration`。
    ///
    /// # Panics
    /// 如果 `secs` 为 negative、溢出 `Duration` 或不是有限的，此构造函数将出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let res = Duration::from_secs_f32(0.0);
    /// assert_eq!(res, Duration::new(0, 0));
    /// let res = Duration::from_secs_f32(1e-20);
    /// assert_eq!(res, Duration::new(0, 0));
    /// let res = Duration::from_secs_f32(4.2e-7);
    /// assert_eq!(res, Duration::new(0, 420));
    /// let res = Duration::from_secs_f32(2.7);
    /// assert_eq!(res, Duration::new(2, 700_000_048));
    /// let res = Duration::from_secs_f32(3e10);
    /// assert_eq!(res, Duration::new(30_000_001_024, 0));
    /// // subnormal 浮点
    /// let res = Duration::from_secs_f32(f32::from_bits(1));
    /// assert_eq!(res, Duration::new(0, 0));
    /// // 转换使用舍入
    /// let res = Duration::from_secs_f32(0.999e-9);
    /// assert_eq!(res, Duration::new(0, 1));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        match Duration::try_from_secs_f32(secs) {
            Ok(v) => v,
            Err(e) => panic!("{}", e.description()),
        }
    }

    /// 将 `Duration` 乘以 `f64`。
    ///
    /// # Panics
    /// 如果结果为 negative、溢出 `Duration` 或不是有限的，此方法将出现 panic。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// 将 `Duration` 乘以 `f32`。
    ///
    /// # Panics
    /// 如果结果为 negative、溢出 `Duration` 或不是有限的，此方法将出现 panic。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_641));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// 将 `Duration` 除以 `f64`。
    ///
    /// # Panics
    /// 如果结果为 negative、溢出 `Duration` 或不是有限的，此方法将出现 panic。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_599));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// 将 `Duration` 除以 `f32`。
    ///
    /// # Panics
    /// 如果结果为 negative、溢出 `Duration` 或不是有限的，此方法将出现 panic。
    ///
    /// # Examples
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // 请注意，由于舍入错误，结果与 0.859_872_611 略有不同
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_580));
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_599));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// 将 `Duration` 除以 `Duration`，然后返回 `f64`。
    ///
    /// # Examples
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// 将 `Duration` 除以 `Duration`，然后返回 `f32`。
    ///
    /// # Examples
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_float", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// 用十进制表示法格式化浮点数。
        ///
        /// 数字以 `integer_part` 和小数形式给出。
        /// 小数部分的值为 `fractional_part / divisor`。
        /// 因此 `integer_part` =3，`fractional_part` =12，`divisor` =100 代表数字 `3.012`。
        /// 尾随零被省略。
        ///
        /// `divisor` 不能超过 100_000_000。
        /// 它也应该是 10 的幂，其他所有都没有意义。
        /// `fractional_part` 必须小于 `10 * divisor`!
        ///
        /// 可以添加前缀和后缀。
        /// 如果指定，整个内容都填充到格式化程序的 `width` 中。
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
            prefix: &str,
            postfix: &str,
        ) -> fmt::Result {
            // 将小数部分编码到临时缓冲区中。
            // 缓冲区仅需要容纳 9 个元素，因为 `fractional_part` 必须小于 10 ^ 9。
            //
            // 缓冲区中预填充了 '0' 数字，以简化下面的代码。
            let mut buf = [b'0'; 9];

            // 下一个数字写在这个位置
            let mut pos = 0;

            // 当剩余的数字不为零时，我们一直在将数字写入缓冲区，但尚未写入足够的数字。
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // 将新数字写入缓冲区
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // 如果指定的精度 < 9，则可能还有一些未写入缓冲区的非零数字。
            // 在那种情况下，我们需要进行舍入以匹配打印普通浮点数的语义。
            // 但是，我们只需要在四舍五入时进行工作。
            // 如果其余一位的第一位为 >= 5，则会发生这种情况。
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // 将缓冲区中包含的数字向上舍入。
                // 我们向后经过缓冲区，并保留跟踪进位。
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // 如果缓冲区中的数字不是 '9'，我们只需要递增它就可以停止 (因为我们再也没有进位)。
                    // 否则，我们将其设置为 '0' (overflow) 并继续。
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // 如果我们仍然设置了进位位，则意味着我们将整个缓冲区设置为 `0`，并且需要增加整数部分。
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // 确定缓冲区的末尾：如果设置了精度，我们将使用缓冲区中的尽可能多的数字 (上限为 9)。
            // 如果未设置，我们将仅使用所有数字，直到最后一个非零数字。
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // 这个闭包发出格式化的持续时间而不发出任何填充 (填充计算如下)。
            //
            let emit_without_padding = |f: &mut fmt::Formatter<'_>| {
                write!(f, "{}{}", prefix, integer_part)?;

                // 写出小数点和小数部分 (如果有)。
                if end > 0 {
                    // SAFETY: 我们仅将 ASCII 数字写入缓冲区，并且已将其初始化为 0，因此它包含有效的 UTF8。
                    //
                    let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                    // 如果用户要求精度 > 9，则在末尾填充 '0'。
                    let w = f.precision().unwrap_or(pos);
                    write!(f, ".{:0<width$}", s, width = w)?;
                }

                write!(f, "{}", postfix)
            };

            match f.width() {
                None => {
                    // 未指定 `width`。
                    // 在这种情况下，不需要计算输出的长度，只需发出它。
                    emit_without_padding(f)
                }
                Some(requested_w) => {
                    // 指定了 `width`。
                    // 计算输出的实际宽度，以便计算所需的填充。
                    // 它由 4 个部分组成：
                    // 1. 前缀：是 "+" 或 ""，所以我们可以只使用 len()。
                    // 2. 后缀：可以是 "µs" 所以我们必须计算 UTF8 字符。
                    let mut actual_w = prefix.len() + postfix.chars().count();
                    // 3. 整数部分：
                    if let Some(log) = integer_part.checked_log10() {
                        // integer_part 是 > 0 的，所以长度是 log10(x)+1
                        actual_w += 1 + log as usize;
                    } else {
                        // integer_part 为 0，因此长度为 1。
                        actual_w += 1;
                    }
                    // 4. 小数部分 (如果有)：
                    if end > 0 {
                        let frac_part_w = f.precision().unwrap_or(pos);
                        actual_w += 1 + frac_part_w;
                    }

                    if requested_w <= actual_w {
                        // 输出已经比 `width` 长，所以不要填充。
                        emit_without_padding(f)
                    } else {
                        // 我们需要添加填充。使用 `Formatter::padding` 帮助函数。
                        let default_align = crate::fmt::rt::v1::Alignment::Left;
                        let post_padding = f.padding(requested_w - actual_w, default_align)?;
                        emit_without_padding(f)?;
                        post_padding.write(f)
                    }
                }
            }
        }

        // 如果需要，请打印前导 '+' 标志
        let prefix = if f.sign_plus() { "+" } else { "" };

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10, prefix, "s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
                prefix,
                "ms",
            )
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
                prefix,
                "µs",
            )
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1, prefix, "ns")
        }
    }
}

/// 将秒的浮点值转换为 [`Duration`] 时可能返回的错误。
///
/// 此错误用作 [`Duration::try_from_secs_f32`] 和 [`Duration::try_from_secs_f64`] 的错误类型。
///
///
/// # Example
///
/// ```
/// #![feature(duration_checked_float)]
/// use std::time::Duration;
///
/// if let Err(e) = Duration::try_from_secs_f32(-1.0) {
///     println!("Failed conversion to Duration: {e}");
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[unstable(feature = "duration_checked_float", issue = "83400")]
pub struct FromFloatSecsError {
    kind: FromFloatSecsErrorKind,
}

impl FromFloatSecsError {
    const fn description(&self) -> &'static str {
        match self.kind {
            FromFloatSecsErrorKind::Negative => {
                "can not convert float seconds to Duration: value is negative"
            }
            FromFloatSecsErrorKind::OverflowOrNan => {
                "can not convert float seconds to Duration: value is either too big or NaN"
            }
        }
    }
}

#[unstable(feature = "duration_checked_float", issue = "83400")]
impl fmt::Display for FromFloatSecsError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.description().fmt(f)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FromFloatSecsErrorKind {
    // 值是负数。
    Negative,
    // 值太大而不能表示为 `Duration` 或 `NaN`。
    OverflowOrNan,
}

macro_rules! try_from_secs {
    (
        secs = $secs: expr,
        mantissa_bits = $mant_bits: literal,
        exponent_bits = $exp_bits: literal,
        offset = $offset: literal,
        bits_ty = $bits_ty:ty,
        double_ty = $double_ty:ty,
    ) => {{
        const MIN_EXP: i16 = 1 - (1i16 << $exp_bits) / 2;
        const MANT_MASK: $bits_ty = (1 << $mant_bits) - 1;
        const EXP_MASK: $bits_ty = (1 << $exp_bits) - 1;

        if $secs.is_sign_negative() {
            return Err(FromFloatSecsError { kind: FromFloatSecsErrorKind::Negative });
        }

        let bits = $secs.to_bits();
        let mant = (bits & MANT_MASK) | (MANT_MASK + 1);
        let exp = ((bits >> $mant_bits) & EXP_MASK) as i16 + MIN_EXP;

        let (secs, nanos) = if exp < -31 {
            // 输入表示小于 1ns，不能四舍五入
            (0u64, 0u32)
        } else if exp < 0 {
            // 输入小于 1 秒
            let t = <$double_ty>::from(mant) << ($offset + exp);
            let nanos_offset = $mant_bits + $offset;
            let nanos_tmp = u128::from(NANOS_PER_SEC) * u128::from(t);
            let nanos = (nanos_tmp >> nanos_offset) as u32;

            let rem_mask = (1 << nanos_offset) - 1;
            let rem_msb_mask = 1 << (nanos_offset - 1);
            let rem = nanos_tmp & rem_mask;
            let is_tie = rem == rem_msb_mask;
            let is_even = (nanos & 1) == 0;
            let rem_msb = nanos_tmp & rem_msb_mask == 0;
            let add_ns = !(rem_msb || (is_even && is_tie));

            // f32 没有足够的精度来触发第二个分支，因为它不能表示 0.999_999_940_395 和 1.0 之间的数字。
            //
            let nanos = nanos + add_ns as u32;
            if ($mant_bits == 23) || (nanos != NANOS_PER_SEC) { (0, nanos) } else { (1, 0) }
        } else if exp < $mant_bits {
            let secs = u64::from(mant >> ($mant_bits - exp));
            let t = <$double_ty>::from((mant << exp) & MANT_MASK);
            let nanos_offset = $mant_bits;
            let nanos_tmp = <$double_ty>::from(NANOS_PER_SEC) * t;
            let nanos = (nanos_tmp >> nanos_offset) as u32;

            let rem_mask = (1 << nanos_offset) - 1;
            let rem_msb_mask = 1 << (nanos_offset - 1);
            let rem = nanos_tmp & rem_mask;
            let is_tie = rem == rem_msb_mask;
            let is_even = (nanos & 1) == 0;
            let rem_msb = nanos_tmp & rem_msb_mask == 0;
            let add_ns = !(rem_msb || (is_even && is_tie));

            // f32 没有足够的精度来触发第二个分支。
            // 例如，它不能表示 1.999_999_880 之间的数字...
            // 和 2.0。
            // 较大的值会导致小数部分的精度更小。
            let nanos = nanos + add_ns as u32;
            if ($mant_bits == 23) || (nanos != NANOS_PER_SEC) {
                (secs, nanos)
            } else {
                (secs + 1, 0)
            }
        } else if exp < 64 {
            // 输入没有小数部分
            let secs = u64::from(mant) << (exp - $mant_bits);
            (secs, 0)
        } else {
            return Err(FromFloatSecsError { kind: FromFloatSecsErrorKind::OverflowOrNan });
        };

        Ok(Duration { secs, nanos })
    }};
}

impl Duration {
    /// [`from_secs_f32`] 的检查版本。
    ///
    /// [`from_secs_f32`]: Duration::from_secs_f32
    ///
    /// 如果 `secs` 为 negative、溢出 `Duration` 或不是有限的，则此构造函数将返回 `Err`。
    ///
    /// # Examples
    /// ```
    /// #![feature(duration_checked_float)]
    ///
    /// use std::time::Duration;
    ///
    /// let res = Duration::try_from_secs_f32(0.0);
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    /// let res = Duration::try_from_secs_f32(1e-20);
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    /// let res = Duration::try_from_secs_f32(4.2e-7);
    /// assert_eq!(res, Ok(Duration::new(0, 420)));
    /// let res = Duration::try_from_secs_f32(2.7);
    /// assert_eq!(res, Ok(Duration::new(2, 700_000_048)));
    /// let res = Duration::try_from_secs_f32(3e10);
    /// assert_eq!(res, Ok(Duration::new(30_000_001_024, 0)));
    /// // subnormal 浮点:
    /// let res = Duration::try_from_secs_f32(f32::from_bits(1));
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    ///
    /// let res = Duration::try_from_secs_f32(-5.0);
    /// assert!(res.is_err());
    /// let res = Duration::try_from_secs_f32(f32::NAN);
    /// assert!(res.is_err());
    /// let res = Duration::try_from_secs_f32(2e19);
    /// assert!(res.is_err());
    ///
    /// // 转换使用带平局分辨率的舍入来均匀
    /// let res = Duration::try_from_secs_f32(0.999e-9);
    /// assert_eq!(res, Ok(Duration::new(0, 1)));
    ///
    /// // 这个浮点数正好代表 976562.5e-9
    /// let val = f32::from_bits(0x3A80_0000);
    /// let res = Duration::try_from_secs_f32(val);
    /// assert_eq!(res, Ok(Duration::new(0, 976_562)));
    ///
    /// // 这个浮点数正好代表 2929687.5e-9
    /// let val = f32::from_bits(0x3B40_0000);
    /// let res = Duration::try_from_secs_f32(val);
    /// assert_eq!(res, Ok(Duration::new(0, 2_929_688)));
    ///
    /// // 这个浮点数正好代表 1.000_976_562_5
    /// let val = f32::from_bits(0x3F802000);
    /// let res = Duration::try_from_secs_f32(val);
    /// assert_eq!(res, Ok(Duration::new(1, 976_562)));
    ///
    /// // 这个浮点数正好代表 1.002_929_687_5
    /// let val = f32::from_bits(0x3F806000);
    /// let res = Duration::try_from_secs_f32(val);
    /// assert_eq!(res, Ok(Duration::new(1, 2_929_688)));
    /// ```
    #[unstable(feature = "duration_checked_float", issue = "83400")]
    #[inline]
    pub const fn try_from_secs_f32(secs: f32) -> Result<Duration, FromFloatSecsError> {
        try_from_secs!(
            secs = secs,
            mantissa_bits = 23,
            exponent_bits = 8,
            offset = 41,
            bits_ty = u32,
            double_ty = u64,
        )
    }

    /// [`from_secs_f64`] 的检查版本。
    ///
    /// [`from_secs_f64`]: Duration::from_secs_f64
    ///
    /// 如果 `secs` 为 negative、溢出 `Duration` 或不是有限的，则此构造函数将返回 `Err`。
    ///
    /// # Examples
    /// ```
    /// #![feature(duration_checked_float)]
    ///
    /// use std::time::Duration;
    ///
    /// let res = Duration::try_from_secs_f64(0.0);
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    /// let res = Duration::try_from_secs_f64(1e-20);
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    /// let res = Duration::try_from_secs_f64(4.2e-7);
    /// assert_eq!(res, Ok(Duration::new(0, 420)));
    /// let res = Duration::try_from_secs_f64(2.7);
    /// assert_eq!(res, Ok(Duration::new(2, 700_000_000)));
    /// let res = Duration::try_from_secs_f64(3e10);
    /// assert_eq!(res, Ok(Duration::new(30_000_000_000, 0)));
    /// // subnormal 浮点
    /// let res = Duration::try_from_secs_f64(f64::from_bits(1));
    /// assert_eq!(res, Ok(Duration::new(0, 0)));
    ///
    /// let res = Duration::try_from_secs_f64(-5.0);
    /// assert!(res.is_err());
    /// let res = Duration::try_from_secs_f64(f64::NAN);
    /// assert!(res.is_err());
    /// let res = Duration::try_from_secs_f64(2e19);
    /// assert!(res.is_err());
    ///
    /// // 转换使用带平局分辨率的舍入来均匀
    /// let res = Duration::try_from_secs_f64(0.999e-9);
    /// assert_eq!(res, Ok(Duration::new(0, 1)));
    /// let res = Duration::try_from_secs_f64(0.999_999_999_499);
    /// assert_eq!(res, Ok(Duration::new(0, 999_999_999)));
    /// let res = Duration::try_from_secs_f64(0.999_999_999_501);
    /// assert_eq!(res, Ok(Duration::new(1, 0)));
    /// let res = Duration::try_from_secs_f64(42.999_999_999_499);
    /// assert_eq!(res, Ok(Duration::new(42, 999_999_999)));
    /// let res = Duration::try_from_secs_f64(42.999_999_999_501);
    /// assert_eq!(res, Ok(Duration::new(43, 0)));
    ///
    /// // 这个浮点数正好代表 976562.5e-9
    /// let val = f64::from_bits(0x3F50_0000_0000_0000);
    /// let res = Duration::try_from_secs_f64(val);
    /// assert_eq!(res, Ok(Duration::new(0, 976_562)));
    ///
    /// // 这个浮点数正好代表 2929687.5e-9
    /// let val = f64::from_bits(0x3F68_0000_0000_0000);
    /// let res = Duration::try_from_secs_f64(val);
    /// assert_eq!(res, Ok(Duration::new(0, 2_929_688)));
    ///
    /// // 这个浮点数正好代表 1.000_976_562_5
    /// let val = f64::from_bits(0x3FF0_0400_0000_0000);
    /// let res = Duration::try_from_secs_f64(val);
    /// assert_eq!(res, Ok(Duration::new(1, 976_562)));
    ///
    /// // 这个浮点数正好代表 1.002_929_687_5
    /// let val = f64::from_bits(0x3_FF00_C000_0000_000);
    /// let res = Duration::try_from_secs_f64(val);
    /// assert_eq!(res, Ok(Duration::new(1, 2_929_688)));
    /// ```
    #[unstable(feature = "duration_checked_float", issue = "83400")]
    #[inline]
    pub const fn try_from_secs_f64(secs: f64) -> Result<Duration, FromFloatSecsError> {
        try_from_secs!(
            secs = secs,
            mantissa_bits = 52,
            exponent_bits = 11,
            offset = 44,
            bits_ty = u64,
            double_ty = u128,
        )
    }
}
