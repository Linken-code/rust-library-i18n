use crate::convert::TryFrom;
use crate::num::NonZeroUsize;
use crate::{cmp, fmt, hash, mem, num};

/// 一种存储 `usize` 的类型，它是 2 的幂，因此表示 rust 抽象机中可能的对齐方式。
///
/// 请注意，虽然在这种类型中可以表示特别大的对齐，但实际分配器和链接器可能不支持。
///
///
#[derive(Copy, Clone)]
#[repr(transparent)]
pub(crate) struct ValidAlign(ValidAlignEnum);

// ValidAlign 是 `repr(usize)`，但需要额外的步骤。
const _: () = assert!(mem::size_of::<ValidAlign>() == mem::size_of::<usize>());
const _: () = assert!(mem::align_of::<ValidAlign>() == mem::align_of::<usize>());

impl ValidAlign {
    /// 从 `usize` 的二次幂创建 `ValidAlign`。
    ///
    /// # Safety
    ///
    /// `align` 必须是 2 的幂。
    ///
    /// 等效地，对于 `0..usize::BITS` 中的某些 `exp`，它必须是 `1 << exp`。
    /// 它必须不为零。
    #[inline]
    pub(crate) const unsafe fn new_unchecked(align: usize) -> Self {
        debug_assert!(align.is_power_of_two());

        // SAFETY: 作为先决条件，这必须是 2 的幂，并且我们的变体包含所有可能的 2 幂。
        //
        unsafe { mem::transmute::<usize, ValidAlign>(align) }
    }

    #[inline]
    pub(crate) const fn as_nonzero(self) -> NonZeroUsize {
        // SAFETY: 所有的判别式都是非零的。
        unsafe { NonZeroUsize::new_unchecked(self.0 as usize) }
    }

    /// 返回以 2 为底的对齐对数。
    ///
    /// 这总是准确的，因为 `self` 代表 2 的幂。
    #[inline]
    pub(crate) fn log2(self) -> u32 {
        self.as_nonzero().trailing_zeros()
    }
}

impl fmt::Debug for ValidAlign {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?} (1 << {:?})", self.as_nonzero(), self.log2())
    }
}

impl TryFrom<NonZeroUsize> for ValidAlign {
    type Error = num::TryFromIntError;

    #[inline]
    fn try_from(align: NonZeroUsize) -> Result<ValidAlign, Self::Error> {
        if align.is_power_of_two() {
            // SAFETY: 刚刚检查了二次幂
            unsafe { Ok(ValidAlign::new_unchecked(align.get())) }
        } else {
            Err(num::TryFromIntError(()))
        }
    }
}

impl TryFrom<usize> for ValidAlign {
    type Error = num::TryFromIntError;

    #[inline]
    fn try_from(align: usize) -> Result<ValidAlign, Self::Error> {
        if align.is_power_of_two() {
            // SAFETY: 刚刚检查了二次幂
            unsafe { Ok(ValidAlign::new_unchecked(align)) }
        } else {
            Err(num::TryFromIntError(()))
        }
    }
}

impl cmp::Eq for ValidAlign {}

impl cmp::PartialEq for ValidAlign {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_nonzero() == other.as_nonzero()
    }
}

impl cmp::Ord for ValidAlign {
    #[inline]
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        self.as_nonzero().cmp(&other.as_nonzero())
    }
}

impl cmp::PartialOrd for ValidAlign {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl hash::Hash for ValidAlign {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_nonzero().hash(state)
    }
}

#[cfg(target_pointer_width = "16")]
type ValidAlignEnum = ValidAlignEnum16;
#[cfg(target_pointer_width = "32")]
type ValidAlignEnum = ValidAlignEnum32;
#[cfg(target_pointer_width = "64")]
type ValidAlignEnum = ValidAlignEnum64;

#[derive(Copy, Clone)]
#[repr(u16)]
enum ValidAlignEnum16 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
}

#[derive(Copy, Clone)]
#[repr(u32)]
enum ValidAlignEnum32 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
    _Align1Shl16 = 1 << 16,
    _Align1Shl17 = 1 << 17,
    _Align1Shl18 = 1 << 18,
    _Align1Shl19 = 1 << 19,
    _Align1Shl20 = 1 << 20,
    _Align1Shl21 = 1 << 21,
    _Align1Shl22 = 1 << 22,
    _Align1Shl23 = 1 << 23,
    _Align1Shl24 = 1 << 24,
    _Align1Shl25 = 1 << 25,
    _Align1Shl26 = 1 << 26,
    _Align1Shl27 = 1 << 27,
    _Align1Shl28 = 1 << 28,
    _Align1Shl29 = 1 << 29,
    _Align1Shl30 = 1 << 30,
    _Align1Shl31 = 1 << 31,
}

#[derive(Copy, Clone)]
#[repr(u64)]
enum ValidAlignEnum64 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
    _Align1Shl16 = 1 << 16,
    _Align1Shl17 = 1 << 17,
    _Align1Shl18 = 1 << 18,
    _Align1Shl19 = 1 << 19,
    _Align1Shl20 = 1 << 20,
    _Align1Shl21 = 1 << 21,
    _Align1Shl22 = 1 << 22,
    _Align1Shl23 = 1 << 23,
    _Align1Shl24 = 1 << 24,
    _Align1Shl25 = 1 << 25,
    _Align1Shl26 = 1 << 26,
    _Align1Shl27 = 1 << 27,
    _Align1Shl28 = 1 << 28,
    _Align1Shl29 = 1 << 29,
    _Align1Shl30 = 1 << 30,
    _Align1Shl31 = 1 << 31,
    _Align1Shl32 = 1 << 32,
    _Align1Shl33 = 1 << 33,
    _Align1Shl34 = 1 << 34,
    _Align1Shl35 = 1 << 35,
    _Align1Shl36 = 1 << 36,
    _Align1Shl37 = 1 << 37,
    _Align1Shl38 = 1 << 38,
    _Align1Shl39 = 1 << 39,
    _Align1Shl40 = 1 << 40,
    _Align1Shl41 = 1 << 41,
    _Align1Shl42 = 1 << 42,
    _Align1Shl43 = 1 << 43,
    _Align1Shl44 = 1 << 44,
    _Align1Shl45 = 1 << 45,
    _Align1Shl46 = 1 << 46,
    _Align1Shl47 = 1 << 47,
    _Align1Shl48 = 1 << 48,
    _Align1Shl49 = 1 << 49,
    _Align1Shl50 = 1 << 50,
    _Align1Shl51 = 1 << 51,
    _Align1Shl52 = 1 << 52,
    _Align1Shl53 = 1 << 53,
    _Align1Shl54 = 1 << 54,
    _Align1Shl55 = 1 << 55,
    _Align1Shl56 = 1 << 56,
    _Align1Shl57 = 1 << 57,
    _Align1Shl58 = 1 << 58,
    _Align1Shl59 = 1 << 59,
    _Align1Shl60 = 1 << 60,
    _Align1Shl61 = 1 << 61,
    _Align1Shl62 = 1 << 62,
    _Align1Shl63 = 1 << 63,
}
