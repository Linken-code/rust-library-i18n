/// 一种类型的值是否可以转换为另一种类型的值?
///
/// 当 `Self` 类型的任何值的位在给定的 `Context` 中可以安全地转换为 `Dst` 类型的值时，此 trait 由编译器针对 `Src` 和 `Self` 类型即时实现，尽管您已要求编译器进行任何安全检查对 [`Assume`] 很满意。
///
///
#[unstable(feature = "transmutability", issue = "99571")]
#[cfg_attr(not(bootstrap), lang = "transmute_trait")]
#[rustc_on_unimplemented(
    message = "`{Src}` cannot be safely transmuted into `{Self}` in the defining scope of `{Context}`.",
    label = "`{Src}` cannot be safely transmuted into `{Self}` in the defining scope of `{Context}`."
)]
pub unsafe trait BikeshedIntrinsicFrom<
    Src,
    Context,
    const ASSUME_ALIGNMENT: bool,
    const ASSUME_LIFETIMES: bool,
    const ASSUME_VALIDITY: bool,
    const ASSUME_VISIBILITY: bool,
> where
    Src: ?Sized,
{
}

/// 编译器应假定 *你* 正在检查哪些转换安全条件?
#[unstable(feature = "transmutability", issue = "99571")]
#[derive(PartialEq, Eq, Clone, Copy, Debug)]
pub struct Assume {
    /// 当 `true` 时，编译器假定 *你* 确保 (动态或静态) 目标引用对象没有比源引用对象更严格的对齐要求。
    ///
    pub alignment: bool,

    /// 当 `true` 时，编译器假设 *你* 确保生命周期不会以违反 Rust 内存模型的方式扩展。
    ///
    pub lifetimes: bool,

    /// 当 `true` 时，编译器假定 *你* 确保源类型实际上是目标类型的有效实例。
    ///
    pub validity: bool,

    /// 当 `true` 时，编译器假定 *你* 已确保您可以安全地违反目标类型 (有时也是源类型) 的类型和字段隐私。
    ///
    pub visibility: bool,
}
