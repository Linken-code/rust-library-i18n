//! The libcore prelude
//!
//! 该模块适用于 libcore 的用户，这些用户也未链接到 libstd。
//! 当以与标准库的 prelude 相同的方式使用 `#![no_std]` 时，默认情况下将导入此模块。
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015 版本的核心 prelude。
///
/// 有关更多信息，请参见 [模块级文档](self)。
#[stable(feature = "prelude_2015", since = "1.55.0")]
pub mod rust_2015 {
    #[stable(feature = "prelude_2015", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018 版本的核心 prelude。
///
/// 有关更多信息，请参见 [模块级文档](self)。
#[stable(feature = "prelude_2018", since = "1.55.0")]
pub mod rust_2018 {
    #[stable(feature = "prelude_2018", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021 版本的核心 prelude。
///
/// 有关更多信息，请参见 [模块级文档](self)。
#[stable(feature = "prelude_2021", since = "1.55.0")]
pub mod rust_2021 {
    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;

    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use crate::iter::FromIterator;

    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use crate::convert::{TryFrom, TryInto};
}

/// 核心 prelude 的 2024 年版。
///
/// 有关更多信息，请参见 [模块级文档](self)。
#[unstable(feature = "prelude_2024", issue = "none")]
pub mod rust_2024 {
    #[unstable(feature = "prelude_2024", issue = "none")]
    #[doc(no_inline)]
    pub use super::rust_2021::*;
}
