use crate::convert::TryInto;
use crate::num::{NonZeroI128, NonZeroI16, NonZeroI32, NonZeroI64, NonZeroI8, NonZeroIsize};
use crate::num::{NonZeroU128, NonZeroU16, NonZeroU32, NonZeroU64, NonZeroU8, NonZeroUsize};

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        SpecArrayEq::spec_eq(self, other)
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        SpecArrayEq::spec_ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        let b: Result<&[B; N], _> = other.try_into();
        match b {
            Ok(b) => *self == *b,
            Err(_) => false,
        }
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        let b: Result<&[B; N], _> = other.try_into();
        match b {
            Ok(b) => *self != *b,
            Err(_) => true,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        let b: Result<&[B; N], _> = self.try_into();
        match b {
            Ok(b) => *b == *other,
            Err(_) => false,
        }
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        let b: Result<&[B; N], _> = self.try_into();
        match b {
            Ok(b) => *b != *other,
            Err(_) => true,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        *self == **other
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        *self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        **self == *other
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        **self != *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        *self == **other
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        *self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        **self == *other
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        **self != *other
    }
}

// NOTE: 省略一些不太重要的提示，以减少代码膨胀 __impl_slice_eq2! { [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

trait SpecArrayEq<Other, const N: usize>: Sized {
    fn spec_eq(a: &[Self; N], b: &[Other; N]) -> bool;
    fn spec_ne(a: &[Self; N], b: &[Other; N]) -> bool;
}

impl<T: PartialEq<Other>, Other, const N: usize> SpecArrayEq<Other, N> for T {
    default fn spec_eq(a: &[Self; N], b: &[Other; N]) -> bool {
        a[..] == b[..]
    }
    default fn spec_ne(a: &[Self; N], b: &[Other; N]) -> bool {
        a[..] != b[..]
    }
}

impl<T: IsRawEqComparable<U>, U, const N: usize> SpecArrayEq<U, N> for T {
    fn spec_eq(a: &[T; N], b: &[U; N]) -> bool {
        // SAFETY: 这就是 `IsRawEqComparable` 是 `unsafe trait` 的原因。
        unsafe {
            let b = &*b.as_ptr().cast::<[T; N]>();
            crate::intrinsics::raw_eq(a, b)
        }
    }
    fn spec_ne(a: &[T; N], b: &[U; N]) -> bool {
        !Self::spec_eq(a, b)
    }
}

/// `U` 在这里存在主要是因为 `min_specialization` 没有让我在上面的专业化中重复 `T` 类型参数，所以 `T == U` 约束来自于此的实现。
///
/// # Safety
///
/// - `Self` 和 `U` 都没有任何填充。
/// - `Self` 和 `U` 具有相同的布局。
/// - `Self: PartialEq<U>` 是字节型的 (这意味着没有浮点数等)
#[rustc_specialization_trait]
unsafe trait IsRawEqComparable<U>: PartialEq<U> {}

macro_rules! is_raw_eq_comparable {
    ($($t:ty),+ $(,)?) => {$(
        unsafe impl IsRawEqComparable<$t> for $t {}
    )+};
}

// SAFETY: 所有普通整数类型都允许所有位模式作为不同的值
is_raw_eq_comparable!(u8, u16, u32, u64, u128, usize, i8, i16, i32, i64, i128, isize);

// SAFETY: bool 和 char 有 *niche*，但没有 *padding*，所以这是合理的
is_raw_eq_comparable!(bool, char);

// SAFETY: 类似地，非零类型有一个 niche，但没有 undef，它们的比较就像它们的底层数字类型。
//
is_raw_eq_comparable!(
    NonZeroU8,
    NonZeroU16,
    NonZeroU32,
    NonZeroU64,
    NonZeroU128,
    NonZeroUsize,
    NonZeroI8,
    NonZeroI16,
    NonZeroI32,
    NonZeroI64,
    NonZeroI128,
    NonZeroIsize,
);

// SAFETY: NonZero 类型保证了 "null" 优化，因此在 `Option` 中按位进行相等比较也是安全的。
// 为 `Option` 定义 `PartialOrd` 的方式意味着这对有符号类型的 `<` 或 `>` 不起作用，但因为我们只做 `==`，所以很好。
//
//
is_raw_eq_comparable!(
    Option<NonZeroU8>,
    Option<NonZeroU16>,
    Option<NonZeroU32>,
    Option<NonZeroU64>,
    Option<NonZeroU128>,
    Option<NonZeroUsize>,
    Option<NonZeroI8>,
    Option<NonZeroI16>,
    Option<NonZeroI32>,
    Option<NonZeroI64>,
    Option<NonZeroI128>,
    Option<NonZeroIsize>,
);
