use core::iter::Peekable;

/// 一个迭代器，用于对排序后的迭代器的键进行去重。
/// 当遇到重复的键时，只产生最后一个键值对。
///
/// 由 [`BTreeMap::bulk_build_from_sorted_iter`] 使用。
pub struct DedupSortedIter<K, V, I>
where
    I: Iterator<Item = (K, V)>,
{
    iter: Peekable<I>,
}

impl<K, V, I> DedupSortedIter<K, V, I>
where
    I: Iterator<Item = (K, V)>,
{
    pub fn new(iter: I) -> Self {
        Self { iter: iter.peekable() }
    }
}

impl<K, V, I> Iterator for DedupSortedIter<K, V, I>
where
    K: Eq,
    I: Iterator<Item = (K, V)>,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        loop {
            let next = match self.iter.next() {
                Some(next) => next,
                None => return None,
            };

            let peeked = match self.iter.peek() {
                Some(peeked) => peeked,
                None => return Some(next),
            };

            if next.0 != peeked.0 {
                return Some(next);
            }
        }
    }
}
