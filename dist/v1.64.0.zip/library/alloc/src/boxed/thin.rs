// 基于
// https://github.com/matthieu-m/rfc2580/blob/b58d1d3cba0d4b5e859d3617ea2d0943aaa31329/examples/thin.rs
// by matthieu-m
use crate::alloc::{self, Layout, LayoutError};
use core::fmt::{self, Debug, Display, Formatter};
use core::marker::PhantomData;
#[cfg(not(no_global_oom_handling))]
use core::marker::Unsize;
use core::mem;
use core::ops::{Deref, DerefMut};
use core::ptr::Pointee;
use core::ptr::{self, NonNull};

/// ThinBox.
///
/// 用于堆分配的瘦指针，与 T 无关。
///
/// # Examples
///
/// ```
/// #![feature(thin_box)]
/// use std::boxed::ThinBox;
///
/// let five = ThinBox::new(5);
/// let thin_slice = ThinBox::<[i32]>::new_unsize([1, 2, 3, 4]);
///
/// use std::mem::{size_of, size_of_val};
/// let size_of_ptr = size_of::<*const ()>();
/// assert_eq!(size_of_ptr, size_of_val(&five));
/// assert_eq!(size_of_ptr, size_of_val(&thin_slice));
/// ```
#[unstable(feature = "thin_box", issue = "92791")]
pub struct ThinBox<T: ?Sized> {
    // 这本质上是 `WithHeader<<T as Pointee>::Metadata>`，但在 `T` 中是不变的，我们需要协方差。
    //
    ptr: WithOpaqueHeader,
    _marker: PhantomData<T>,
}

/// 如果 `T` 是 `Send`，则 `ThinBox<T>` 是 `Send`，因为数据是拥有所有权的。
#[unstable(feature = "thin_box", issue = "92791")]
unsafe impl<T: ?Sized + Send> Send for ThinBox<T> {}

/// 如果 `T` 是 `Sync`，则 `ThinBox<T>` 是 `Sync`，因为数据是拥有所有权的。
#[unstable(feature = "thin_box", issue = "92791")]
unsafe impl<T: ?Sized + Sync> Sync for ThinBox<T> {}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T> ThinBox<T> {
    /// 将类型移动到堆中，其 `Metadata` 存储在堆分配中，而不是栈中。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(thin_box)]
    /// use std::boxed::ThinBox;
    ///
    /// let five = ThinBox::new(5);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    pub fn new(value: T) -> Self {
        let meta = ptr::metadata(&value);
        let ptr = WithOpaqueHeader::new(meta, value);
        ThinBox { ptr, _marker: PhantomData }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<Dyn: ?Sized> ThinBox<Dyn> {
    /// 将类型移动到堆中，其 `Metadata` 存储在堆分配中，而不是栈中。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(thin_box)]
    /// use std::boxed::ThinBox;
    ///
    /// let thin_slice = ThinBox::<[i32]>::new_unsize([1, 2, 3, 4]);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    pub fn new_unsize<T>(value: T) -> Self
    where
        T: Unsize<Dyn>,
    {
        let meta = ptr::metadata(&value as &Dyn);
        let ptr = WithOpaqueHeader::new(meta, value);
        ThinBox { ptr, _marker: PhantomData }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized + Debug> Debug for ThinBox<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        Debug::fmt(self.deref(), f)
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized + Display> Display for ThinBox<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        Display::fmt(self.deref(), f)
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> Deref for ThinBox<T> {
    type Target = T;

    fn deref(&self) -> &T {
        let value = self.data();
        let metadata = self.meta();
        let pointer = ptr::from_raw_parts(value as *const (), metadata);
        unsafe { &*pointer }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> DerefMut for ThinBox<T> {
    fn deref_mut(&mut self) -> &mut T {
        let value = self.data();
        let metadata = self.meta();
        let pointer = ptr::from_raw_parts_mut::<T>(value as *mut (), metadata);
        unsafe { &mut *pointer }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> Drop for ThinBox<T> {
    fn drop(&mut self) {
        unsafe {
            let value = self.deref_mut();
            let value = value as *mut T;
            self.with_header().drop::<T>(value);
        }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> ThinBox<T> {
    fn meta(&self) -> <T as Pointee>::Metadata {
        // Safety:
        //  -   非空且有效。
        unsafe { *self.with_header().header() }
    }

    fn data(&self) -> *mut u8 {
        self.with_header().value()
    }

    fn with_header(&self) -> &WithHeader<<T as Pointee>::Metadata> {
        // SAFETY: 两种类型对 `NonNull<u8>` 都是透明的
        unsafe { &*((&self.ptr) as *const WithOpaqueHeader as *const WithHeader<_>) }
    }
}

/// 指向 erased 类型数据的指针，保证为:
/// 1.
/// `NonNull::dangling()`，在指针 (`T`) 和元数据 (`H`) 都是 ZST 的情况下。
///
/// 2. 指向有效 `T` 的指针，该 `T` 在指向位置之前具有标头 `H`。
#[repr(transparent)]
struct WithHeader<H>(NonNull<u8>, PhantomData<H>);

/// `WithHeader<H>` 的不透明表示，以避免 `<T as Pointee>::Metadata` 的投影不变性。
///
#[repr(transparent)]
struct WithOpaqueHeader(NonNull<u8>);

impl WithOpaqueHeader {
    #[cfg(not(no_global_oom_handling))]
    fn new<H, T>(header: H, value: T) -> Self {
        let ptr = WithHeader::new(header, value);
        Self(ptr.0)
    }
}

impl<H> WithHeader<H> {
    #[cfg(not(no_global_oom_handling))]
    fn new<T>(header: H, value: T) -> WithHeader<H> {
        let value_layout = Layout::new::<T>();
        let Ok((layout, value_offset)) = Self::alloc_layout(value_layout) else {
            // 我们在这里传递一个空布局，因为我们不知道是哪个布局导致了 `Layout::extend` 中的算术溢出，并且 `handle_alloc_error` 将 `Layout` 作为它的参数，而不是 `Result<Layout, LayoutError>`，而且这个函数自 1.28 ._ 以来一直很稳定。
            //
            //
            // 另一方面，看看这条华丽的比目鱼!
            //
            //
            alloc::handle_alloc_error(Layout::new::<()>());
        };

        unsafe {
            // Note: 将零大小的布局传递给 `alloc::alloc` 是 UB，因此我们在这种情况下使用 `layout.dangling()`，它应该对 `T` 和 `H` 都有有效的对齐方式。
            //
            //
            let ptr = if layout.size() == 0 {
                // 一些偏执检查，主要是为了让 ThinBox 测试更能发现问题。
                //
                debug_assert!(
                    value_offset == 0 && mem::size_of::<T>() == 0 && mem::size_of::<H>() == 0
                );
                layout.dangling()
            } else {
                let ptr = alloc::alloc(layout);
                if ptr.is_null() {
                    alloc::handle_alloc_error(layout);
                }
                // Safety:
                // - 大小至少为 `aligned_header_size`。
                let ptr = ptr.add(value_offset) as *mut _;

                NonNull::new_unchecked(ptr)
            };

            let result = WithHeader(ptr, PhantomData);
            ptr::write(result.header(), header);
            ptr::write(result.value().cast(), value);

            result
        }
    }

    // Safety:
    // - 假设 `value` 可以被解引用，或者是当 `T` 和 `H` 都是 ZST 时我们使用的 `NonNull::dangling()`。
    //
    unsafe fn drop<T: ?Sized>(&self, value: *mut T) {
        unsafe {
            let value_layout = Layout::for_value_raw(value);
            // SAFETY: 如果我们正在丢弃，布局必须是可计算的
            let (layout, value_offset) = Self::alloc_layout(value_layout).unwrap_unchecked();

            // 我们只丢弃该值，因为 Pointee trait 要求元数据是可复制的，也就是可轻松丢弃的。
            //
            ptr::drop_in_place::<T>(value);

            // Note: 如果布局大小为零，则不要释放，因为指针不是来自分配器。
            //
            if layout.size() != 0 {
                alloc::dealloc(self.0.as_ptr().sub(value_offset), layout);
            } else {
                debug_assert!(
                    value_offset == 0 && mem::size_of::<H>() == 0 && value_layout.size() == 0
                );
            }
        }
    }

    fn header(&self) -> *mut H {
        // Safety:
        //  - 在指针之前至少分配了 `size_of::<H>()` 个字节。
        //  - 我们知道 H 将被对齐，因为中间指针与头部和数据的对齐方式中的较大者对齐，并且头部大小包括对齐头部所需的填充。
        //  从对齐的数据指针中减去头大小总是会导致对齐的头指针，它只是可能不指向分配的开始。
        //
        //
        //
        let hp = unsafe { self.0.as_ptr().sub(Self::header_size()) as *mut H };
        debug_assert!(hp.is_aligned());
        hp
    }

    fn value(&self) -> *mut u8 {
        self.0.as_ptr()
    }

    const fn header_size() -> usize {
        mem::size_of::<H>()
    }

    fn alloc_layout(value_layout: Layout) -> Result<(Layout, usize), LayoutError> {
        Layout::new::<H>().extend(value_layout)
    }
}
