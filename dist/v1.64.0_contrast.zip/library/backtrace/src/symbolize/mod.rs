use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Resolve an address to a symbol, passing the symbol to the specified closure. <br>解析符号的地址，然后将符号传递给指定的闭包。<br>
///
/// This function will look up the given address in areas such as the local symbol table, dynamic symbol table, or DWARF debug info (depending on the activated implementation) to find symbols to yield. <br>该函数将在局部符号表，动态符号表或 DWARF 调试信息 (取决于激活的实现) 等区域中查找给定地址，以查找要产生的符号。<br>
///
///
/// The closure may not be called if resolution could not be performed, and it also may be called more than once in the case of inlined functions. <br>如果无法执行解析，则可能不会调用闭包，对于内联函数，也可能会多次调用。<br>
///
/// Symbols yielded represent the execution at the specified `addr`, returning file/line pairs for that address (if available). <br>产生的符号表示在指定的 `addr` 处的执行，并返回该地址的 file/line 对 (如果有)。<br>
///
/// Note that if you have a `Frame` then it's recommended to use the `resolve_frame` function instead of this one. <br>请注意，如果您有 `Frame`，则建议使用 `resolve_frame` 函数而不是 `Frame` 函数。<br>
///
/// # Required features <br>要求的特性<br>
///
/// This function requires the `std` feature of the `backtrace` crate to be enabled, and the `std` feature is enabled by default. <br>此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。<br>
///
/// # Panics
///
/// This function strives to never panic, but if the `cb` provided panics then some platforms will force a double panic to abort the process. <br>这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。<br>
/// Some platforms use a C library which internally uses callbacks which cannot be unwound through, so panicking from `cb` may trigger a process abort. <br>某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` panic 可能会触发进程终止。<br>
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // only look at the top frame <br>只看顶部框架<br>
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Resolve a previously capture frame to a symbol, passing the symbol to the specified closure. <br>将先前捕获的帧解析为符号，然后将符号传递给指定的闭包。<br>
///
/// This function performs the same function as `resolve` except that it takes a `Frame` as an argument instead of an address. <br>该函数执行与 `resolve` 相同的函数，只是它将 `Frame` 作为参数而不是地址。<br>
/// This can allow some platform implementations of backtracing to provide more accurate symbol information or information about inline frames for example. <br>例如，这可以允许回溯的某些平台实现提供更准确的符号信息或有关内联帧的信息。<br>
///
/// It's recommended to use this if you can. <br>如果可以的话，建议使用此功能。<br>
///
/// # Required features <br>要求的特性<br>
///
/// This function requires the `std` feature of the `backtrace` crate to be enabled, and the `std` feature is enabled by default. <br>此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。<br>
///
/// # Panics
///
/// This function strives to never panic, but if the `cb` provided panics then some platforms will force a double panic to abort the process. <br>这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。<br>
/// Some platforms use a C library which internally uses callbacks which cannot be unwound through, so panicking from `cb` may trigger a process abort. <br>某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` panic 可能会触发进程终止。<br>
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // only look at the top frame <br>只看顶部框架<br>
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP values from stack frames are typically (always?) the instruction *after* the call that's the actual stack trace. <br>来自栈帧的 IP 值通常是 (always?) 实际栈跟踪调用之后的指令。<br>
// Symbolizing this on causes the filename/line number to be one ahead and perhaps into the void if it's near the end of the function. <br>对此进行符号化表示，导致 filename/line 数字在该函数的结尾附近，如果它在函数的末尾提前一个，并且可能成为空白。<br>
//
// This appears to basically always be the case on all platforms, so we always subtract one from a resolved ip to resolve it to the previous call instruction instead of the instruction being returned to. <br>在所有平台上，似乎基本上都是这种情况，因此我们总是从已解析的 ip 中减去一个，以将其解析为上一个调用指令，而不是返回到该指令。<br>
//
//
// Ideally we would not do this. <br>理想情况下，我们不会这样做。<br>
// Ideally we would require callers of the `resolve` APIs here to manually do the -1 and account that they want location information for the *previous* instruction, not the current. <br>理想情况下，我们将要求 `resolve` API 的调用者在此处手动执行 -1，并说明他们需要 *previous* 指令 (而不是当前指令) 的位置信息。<br>
// Ideally we'd also expose on `Frame` if we are indeed the address of the next instruction or the current. <br>理想情况下，如果我们确实是下一条指令或当前指令的地址，则也应在 `Frame` 上公开。<br>
//
// For now though this is a pretty niche concern so we just internally always subtract one. <br>就目前而言，尽管这是一个非常特殊的问题，所以我们在内部始终总是减去一个。<br>
// Consumers should keep working and getting pretty good results, so we should be good enough. <br>消费者应该继续努力并取得不错的成绩，所以我们应该足够好。<br>
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Same as `resolve`, only unsafe as it's unsynchronized. <br>与 `resolve` 相同，只是不安全，因为它未同步。<br>
///
/// This function does not have synchronization guarantees but is available when the `std` feature of this crate isn't compiled in. <br>这个函数没有同步保证，但是当这个 crate 的 `std` 特性没有被编译时，这个函数是可用的。<br>
/// See the `resolve` function for more documentation and examples. <br>有关更多文档和示例，请参见 `resolve` 函数。<br>
///
/// # Panics
///
/// See information on `resolve` for caveats on `cb` panicking. <br>有关 `cb` panic 的警告，请参见 `resolve` 上的信息。<br>
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Same as `resolve_frame`, only unsafe as it's unsynchronized. <br>与 `resolve_frame` 相同，只是不安全，因为它未同步。<br>
///
/// This function does not have synchronization guarantees but is available when the `std` feature of this crate isn't compiled in. <br>这个函数没有同步保证，但是当这个 crate 的 `std` 特性没有被编译时，这个函数是可用的。<br>
/// See the `resolve_frame` function for more documentation and examples. <br>有关更多文档和示例，请参见 `resolve_frame` 函数。<br>
///
/// # Panics
///
/// See information on `resolve_frame` for caveats on `cb` panicking. <br>有关 `cb` panic 的警告，请参见 `resolve_frame` 上的信息。<br>
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait representing the resolution of a symbol in a file. <br>一个表示文件中符号解析的 trait。<br>
///
/// This trait is yielded as a trait object to the closure given to the `backtrace::resolve` function, and it is virtually dispatched as it's unknown which implementation is behind it. <br>这个 trait 作为 trait 对象提供给 `backtrace::resolve` 函数的闭包，并且实际上它是被调度的，因为不知道它背后是哪个实现。<br>
///
///
/// A symbol can give contextual information about a function, for example the name, filename, line number, precise address, etc. <br>符号可以提供有关函数的上下文信息，例如名称，文件名，行号，精确地址等。<br>
/// Not all information is always available in a symbol, however, so all methods return an `Option`. <br>并非所有信息都始终在符号中可用，因此，所有方法都返回 `Option`。<br>
///
///
pub struct Symbol {
    // TODO: this lifetime bound needs to be persisted eventually to `Symbol`, but that's currently a breaking change. <br>这个生命周期的界限最终需要坚持到 `Symbol`，但这是一个重大突破。<br>
    // For now this is safe since `Symbol` is only ever handed out by reference and can't be cloned. <br>现在，这是安全的，因为 `Symbol` 仅由引用分发，并且不能被克隆。<br>
    //
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Returns the name of this function. <br>返回此函数的名称。<br>
    ///
    /// The returned structure can be used to query various properties about the symbol name: <br>返回的结构体可用于查询有关符号名称的各种属性：<br>
    ///
    ///
    /// * The `Display` implementation will print out the demangled symbol. <br>`Display` 的实现将打印出 demangled 符号。<br>
    /// * The raw `str` value of the symbol can be accessed (if it's valid utf-8). <br>可以访问符号的原始 `str` 值 (如果它是有效的 utf-8)。<br>
    /// * The raw bytes for the symbol name can be accessed. <br>可以访问符号名称的原始字节。<br>
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Returns the starting address of this function. <br>返回此函数的起始地址。<br>
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returns the raw filename as a slice. <br>返回原始文件名作为切片。<br>
    /// This is mainly useful for `no_std` environments. <br>这主要对 `no_std` 环境有用。<br>
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Returns the column number for where this symbol is currently executing. <br>返回此符号当前正在执行的位置的列号。<br>
    ///
    /// Only gimli currently provides a value here and even then only if `filename` returns `Some`, and so it is then consequently subject to similar caveats. <br>当前只有 gimli 在此处提供一个值，即使 `filename` 返回 `Some` 也是如此，因此也要受到类似的警告。<br>
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Returns the line number for where this symbol is currently executing. <br>返回此符号当前正在执行的行号。<br>
    ///
    /// This return value is typically `Some` if `filename` returns `Some`, and is consequently subject to similar caveats. <br>如果 `filename` 返回 `Some`，则此返回值通常为 `Some`，因此也有类似的警告。<br>
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Returns the file name where this function was defined. <br>返回定义此函数的文件名。<br>
    ///
    /// This is currently only available when libbacktrace or gimli is being used (e.g. <br>当前仅在使用 libbacktrace 或 gimli 时才可用 (例如<br>
    /// unix platforms other) and when a binary is compiled with debuginfo. <br>unix 平台其他) 以及使用 debuginfo 编译二进制文件时。<br>
    /// If neither of these conditions is met then this will likely return `None`. <br>如果这两个条件都不满足，则可能会返回 `None`。<br>
    ///
    /// # Required features <br>要求的特性<br>
    ///
    /// This function requires the `std` feature of the `backtrace` crate to be enabled, and the `std` feature is enabled by default. <br>此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。<br>
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Maybe a parsed C++ symbol, if parsing the mangled symbol as Rust failed. <br>如果将损坏的符号解析为 Rust 失败，则可能是解析的 C++ 符号。<br>
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Make sure to keep this zero-sized, so that the `cpp_demangle` feature has no cost when disabled. <br>确保保持这个零大小，这样 `cpp_demangle` 特性在禁用时没有成本。<br>
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// A wrapper around a symbol name to provide ergonomic accessors to the demangled name, the raw bytes, the raw string, etc. <br>符号名称周围的包装器，以提供符合人体工程学的访问器来访问已分解的名称，原始字节，原始字符串等。<br>
///
// Allow dead code for when the `cpp_demangle` feature is not enabled. <br>当未启用 `cpp_demangle` 特性时，允许使用死代码。<br>
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Creates a new symbol name from the raw underlying bytes. <br>从原始底层字节创建一个新的符号名称。<br>
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Returns the raw (mangled) symbol name as a `str` if the symbol is valid utf-8. <br>如果符号有效 utf-8，则将原始 (mangled) 符号名称返回为 `str`。<br>
    ///
    /// Use the `Display` implementation if you want the demangled version. <br>如果需要 demangled 版本，请使用 `Display` 实现。<br>
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Returns the raw symbol name as a list of bytes <br>以字节列表形式返回原始符号名称<br>
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // This may to print if the demangled symbol isn't actually valid, so handle the error here gracefully by not propagating it outwards. <br>如果被检索的符号实际上不是有效的，这可能会打印出来，所以通过不向外传播错误来优雅地处理这里的错误。<br>
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Attempt to reclaim that cached memory used to symbolicate addresses. <br>尝试回收用于表示地址的缓存内存。<br>
///
/// This method will attempt to release any global data structures that have otherwise been cached globally or in the thread which typically represent parsed DWARF information or similar. <br>此方法将尝试释放已全局缓存或在线程中缓存的任何数据结构，这些数据结构通常表示已解析的 DWARF 信息或类似信息。<br>
///
///
/// # Caveats
///
/// While this function is always available it doesn't actually do anything on most implementations. <br>尽管此函数始终可用，但实际上在大多数实现中都没有任何作用。<br>
/// Libraries like dbghelp or libbacktrace do not provide facilities to deallocate state and manage the allocated memory. <br>诸如 dbghelp 或 libbacktrace 之类的库不提供释放状态和管理分配的内存的功能。<br>
/// For now the `gimli-symbolize` feature of this crate is the only feature where this function has any effect. <br>目前，这个 crate 的 `gimli-symbolize` 特性是这个特性有任何作用的唯一特性。<br>
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
        any(not(backtrace_in_libstd), feature = "backtrace"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}
