//! A module to assist in managing dbghelp bindings on Windows <br>一个有助于在 Windows 上管理 dbghelp 绑定的模块<br>
//!
//! Backtraces on Windows (at least for MSVC) are largely powered through `dbghelp.dll` and the various functions that it contains. <br>Windows 上的回溯跟踪 (至少对于 MSVC 而言) 主要通过 `dbghelp.dll` 及其包含的各种函数提供支持。<br>
//! These functions are currently loaded *dynamically* rather than linking to `dbghelp.dll` statically. <br>这些函数当前是动态加载的，而不是静态链接到 `dbghelp.dll`。<br>
//! This is currently done by the standard library (and is in theory required there), but is an effort to help reduce the static dll dependencies of a library since backtraces are typically pretty optional. <br>目前，这是由标准库完成的 (理论上是由标准库完成的)，但是由于回溯通常是非常可选的，因此它旨在帮助减少库的静态 dll 依赖性。<br>
//!
//! That being said, `dbghelp.dll` almost always successfully loads on Windows. <br>话虽如此，`dbghelp.dll` 几乎总是成功地加载到 Windows 上。<br>
//!
//! Note though that since we're loading all this support dynamically we can't actually use the raw definitions in `winapi`, but rather we need to define the function pointer types ourselves and use that. <br>请注意，尽管由于我们是动态加载所有这些支持，所以我们实际上不能在 `winapi` 中使用原始定义，而是需要自己定义函数指针类型并使用它。<br>
//! We don't really want to be in the business of duplicating winapi, so we have a Cargo feature `verify-winapi` which asserts that all bindings match those in winapi and this feature is enabled on CI. <br>我们真的不希望复制 winapi，因此我们有一个 Cargo 特性 `verify-winapi`，该特性断言所有绑定均与 winapi 中的绑定匹配，并且此特性已在 CI 上启用。<br>
//!
//! Finally, you'll note here that the dll for `dbghelp.dll` is never unloaded, and that's currently intentional. <br>最后，您会在这里注意到 `dbghelp.dll` 的 dll 从未卸载，这是当前故意的。<br>
//! The thinking is that we can globally cache it and use it between calls to the API, avoiding expensive loads/unloads. <br>这种想法是，我们可以全局缓存它，并在调用 API 之间使用它，避免昂贵的加载/卸载。<br>
//! If this is a problem for leak detectors or something like that we can cross the bridge when we get there. <br>如果这是泄漏检测器之类的问题，我们可以在到达那里时桥接。<br>
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Work around `SymGetOptions` and `SymSetOptions` not being present in winapi itself. <br>解决 Winapi 本身中不存在的 `SymGetOptions` 和 `SymSetOptions` 的问题。<br>
// Otherwise this is only used when we're double-checking types against winapi. <br>否则，仅在我们针对 winapi 再次检查类型时使用。<br>
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, StackWalkEx, SymCleanup, SymFromAddrW, SymFunctionTableAccess64,
        SymGetLineFromAddrW64, SymGetModuleBase64, SymGetOptions, SymInitializeW, SymSetOptions,
    };

    extern "system" {
        // Not defined in winapi yet <br>尚未在 winapi 中定义<br>
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// This macro is used to define a `Dbghelp` structure which internally contains all the function pointers that we might load. <br>此宏用于定义 `Dbghelp` 结构体，该结构内部包含我们可能加载的所有函数指针。<br>
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// The loaded DLL for `dbghelp.dll` <br>`dbghelp.dll` 的已加载 DLL<br>
            dll: HMODULE,

            // Each function pointer for each function we might use <br>我们可能使用的每个函数的每个函数指针<br>
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Initially we haven't loaded the DLL <br>最初我们还没有加载 DLL<br>
            dll: 0 as *mut _,
            // Initiall all functions are set to zero to say they need to be dynamically loaded. <br>将所有函数的 Initiall 设置为零，以表示需要动态加载它们。<br>
            //
            $($name: 0,)*
        };

        // Convenience typedef for each function type. <br>每个函数类型的便利 typedef。<br>
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Attempts to open `dbghelp.dll`. <br>尝试打开 `dbghelp.dll`。<br>
            /// Returns success if it works or error if `LoadLibraryW` fails. <br>如果成功，则返回成功; 如果 `LoadLibraryW` 失败，则返回错误。<br>
            ///
            /// Panics if library is already loaded. <br>如果库已经加载，就会出现 panics。<br>
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Function for each method we'd like to use. <br>我们要使用的每种方法的函数。<br>
            // When called it will either read the cached function pointer or load it and return the loaded value. <br>调用时，它将读取缓存的函数指针或将其加载并返回已加载的值。<br>
            // Loads are asserted to succeed. <br>断言加载成功。<br>
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Convenience proxy to use the cleanup locks to reference dbghelp functions. <br>方便代理使用清理锁来引用 dbghelp 函数。<br>
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> DWORD;
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize all support necessary to access `dbghelp` API functions from this crate. <br>初始化从 crate 访问 `dbghelp` API 函数所需的所有支持。<br>
///
///
/// Note that this function is **safe**, it internally has its own synchronization. <br>请注意，此函数是安全的，它在内部具有自己的同步。<br>
/// Also note that it is safe to call this function multiple times recursively. <br>另请注意，以递归方式多次调用此函数是安全的。<br>
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // First thing we need to do is to synchronize this function. <br>我们需要做的第一件事就是同步这个函数。<br> This can be called concurrently from other threads or recursively within one thread. <br>可以从其他线程并发调用，也可以在一个线程内递归调用。<br>
        // Note that it's trickier than that though because what we're using here, `dbghelp`, *also* needs to be synchronized with all other callers to `dbghelp` in this process. <br>请注意，这比这要复杂得多，因为在此过程中，我们在此使用的 `dbghelp` 还必须与所有其他调用者同步到 `dbghelp`。<br>
        //
        // Typically there aren't really that many calls to `dbghelp` within the same process and we can probably safely assume that we're the only ones accessing it. <br>通常，在同一进程中实际上没有太多对 `dbghelp` 的调用，我们可以放心地假设我们是唯一访问它的人。<br>
        // There is, however, one primary other user we have to worry about which is ironically ourselves, but in the standard library. <br>但是，还有一个主要的其他用户，我们不得不担心的是讽刺的是我们自己，但是在标准库中。<br>
        // The Rust standard library depends on this crate for backtrace support, and this crate also exists on crates.io. <br>Rust 标准库依赖于此 crate 来支持回溯，并且该 crate 也存在于 crates.io 上。<br>
        // This means that if the standard library is printing a panic backtrace it may race with this crate coming from crates.io, causing segfaults. <br>这意味着，如果标准库正在打印 panic 回溯，则它可能与来自 crates.io 的 crate 竞争，从而导致段错误。<br>
        //
        // To help solve this synchronization problem we employ a Windows-specific trick here (it is, after all, a Windows-specific restriction about synchronization). <br>为了帮助解决此同步问题，我们在此处采用了 Windows 特有的技巧 (毕竟，这是 Windows 特有的关于同步的限制)。<br>
        // We create a *session-local* named mutex to protect this call. <br>我们创建一个 *会话本地* 名为互斥锁来保护此调用。<br>
        // The intention here is that the standard library and this crate don't have to share Rust-level APIs to synchronize here but can instead work behind the scenes to make sure they're synchronizing with one another. <br>这里的意图是，标准库和此 crate 不必共享 Rust 级别的 API 即可在此处进行同步，而是可以在后台进行操作以确保它们彼此同步。<br>
        //
        // That way when this function is called through the standard library or through crates.io we can be sure that the same mutex is being acquired. <br>这样，当通过标准库或 crates.io 调用此函数时，我们可以确保获取了相同的互斥锁。<br>
        //
        // So all of that is to say that the first thing we do here is we atomically create a `HANDLE` which is a named mutex on Windows. <br>所以所有这一切都是说，我们要做的第一件事就是原子地创建一个 `HANDLE`，它是 Windows 上的一个命名互斥锁。<br>
        // We synchronize a bit with other threads sharing this function specifically and ensure that only one handle is created per instance of this function. <br>我们与专门共享此函数的其他线程进行了一些同步，并确保每个此函数实例仅创建一个句柄。<br>
        // Note that the handle is never closed once it's stored in the global. <br>请注意，一旦将句柄存储在长度中，它就永远不会关闭。<br>
        //
        // After we've actually go the lock we simply acquire it, and our `Init` handle we hand out will be responsible for dropping it eventually. <br>实际执行锁定后，我们只需获取它，然后我们递出的 `Init` 句柄将最终负责将其丢弃。<br>
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew! <br>好，phew!<br> Now that we're all safely synchronized, let's actually start processing everything. <br>现在我们已经安全地同步了，让我们开始处理所有内容。<br>
        // First up we need to ensure that `dbghelp.dll` is actually loaded in this process. <br>首先，我们需要确保在此过程中实际加载了 `dbghelp.dll`。<br>
        // We do this dynamically to avoid a static dependency. <br>我们动态地执行此操作以避免静态依赖。<br>
        // This has historically been done to work around weird linking issues and is intended at making binaries a bit more portable since this is largely just a debugging utility. <br>从历史上讲，这样做是为了解决怪异的链接问题，它的目的是使二进制文件具有更高的可移植性，因为这在很大程度上只是调试实用程序。<br>
        //
        //
        // Once we've opened `dbghelp.dll` we need to call some initialization functions in it, and that's detailed more below. <br>打开 `dbghelp.dll` 之后，我们需要在其中调用一些初始化函数，下面将对其进行详细说明。<br>
        // We only do this once, though, so we've got a global boolean indicating whether we're done yet or not. <br>不过，我们只执行一次，因此我们有一个布尔值布尔值指示我们是否已经完成。<br>
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Ensure that the `SYMOPT_DEFERRED_LOADS` flag is set, because according to MSVC's own docs about this: "This is the fastest, most efficient way to use the symbol handler.", so let's do that! <br>确保设置了 `SYMOPT_DEFERRED_LOADS` 标志，因为根据 MSVC 自己的文档: "这是使用符号处理程序的最快、最有效的方法。"，让我们开始吧!<br>
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Actually initialize symbols with MSVC. <br>实际上使用 MSVC 初始化符号。<br> Note that this can fail, but we ignore it. <br>请注意，这可能会失败，但是我们将其忽略。<br>
        // There's not a ton of prior art for this per se, but LLVM internally seems to ignore the return value here and one of the sanitizer libraries in LLVM prints a scary warning if this fails but basically ignores it in the long run. <br>本身并没有很多现有技术，但是 LLVM 内部似乎忽略了这里的返回值，并且 LLVM 中的一个消毒剂库在失败时会发出可怕的警告，但从长远来看基本上会忽略它。<br>
        //
        //
        // One case this comes up a lot for Rust is that the standard library and this crate on crates.io both want to compete for `SymInitializeW`. <br>Rust 出现了很多情况，就是标准库和 crates.io 上的 crate 都想竞争 `SymInitializeW`。<br>
        // The standard library historically wanted to initialize then cleanup most of the time, but now that it's using this crate it means that someone will get to initialization first and the other will pick up that initialization. <br>历史上，标准库大多数时候都想初始化然后进行清理，但是现在它使用的是 crate，这意味着某个人将首先进行初始化，而另一个人将进行该初始化。<br>
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}
