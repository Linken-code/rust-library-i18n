/// The version of the call operator that takes an immutable receiver. <br>采用不可变接收者的调用运算符的版本。<br>
///
/// Instances of `Fn` can be called repeatedly without mutating state. <br>`Fn` 的实例可以在不改变状态的情况下重复调用。<br>
///
/// *This trait (`Fn`) is not to be confused with [function pointers] (`fn`). <br>请勿将此 trait (`Fn`) 与 [函数指针][function pointers] (`fn`) 混淆。<br>*
///
/// `Fn` is implemented automatically by closures which only take immutable references to captured variables or don't capture anything at all, as well as (safe) [function pointers] (with some caveats, see their documentation for more details). <br>`Fn` 是由闭包自动实现的，闭包只接受对捕获变量的不可变引用或根本不捕获任何东西，以及 (safe) [函数指针][function pointers] (有一些注意事项，请参见他们的文档以获取更多详细信息)。<br>
///
/// Additionally, for any type `F` that implements `Fn`, `&F` implements `Fn`, too. <br>此外，对于实现 `Fn` 的任何类型 `F`，`&F` 也实现了 `Fn`。<br>
///
/// Since both [`FnMut`] and [`FnOnce`] are supertraits of `Fn`, any instance of `Fn` can be used as a parameter where a [`FnMut`] or [`FnOnce`] is expected. <br>由于 [`FnMut`] 和 [`FnOnce`] 都是 `Fn` 的 supertraits，因此 `Fn` 的任何实例都可以用作参数，其中需要 [`FnMut`] 或 [`FnOnce`]。<br>
///
/// Use `Fn` as a bound when you want to accept a parameter of function-like type and need to call it repeatedly and without mutating state (e.g., when calling it concurrently). <br>当您要接受类似函数类型的参数并且需要反复调用且不改变状态 (例如，同时调用它) 时，请使用 `Fn` 作为绑定。<br>
/// If you do not need such strict requirements, use [`FnMut`] or [`FnOnce`] as bounds. <br>如果不需要严格的要求，请使用 [`FnMut`] 或 [`FnOnce`] 作为界限。<br>
///
/// See the [chapter on closures in *The Rust Programming Language*][book] for some more information on this topic. <br>有关此主题的更多信息，请参见 [Rust 编程语言][book] 中关于闭包的章节。<br>
///
/// Also of note is the special syntax for `Fn` traits (e.g. <br>还要注意的是 `Fn` traits 的特殊语法 (例如<br>
/// `Fn(usize, bool) -> usize`). Those interested in the technical details of this can refer to [the relevant section in the *Rustonomicon*][nomicon]. <br>`Fn(usize, bool) -> usize`)。对此技术细节感兴趣的人可以参考 [Rustonomicon 中的相关部分][nomicon]。<br>
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Calling a closure <br>调用一个闭包<br>
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Using a `Fn` parameter <br>使用 `Fn` 参数<br>
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Fn"]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    on(
        _Self = "unsafe fn",
        note = "unsafe function cannot be called generically without an unsafe block",
        // SAFETY: tidy is not smart enough to tell that the below unsafe block is a string <br>tidy 不够聪明，无法判断下面的 unsafe 块是字符串<br>
        label = "call the function in a closure: `|| unsafe {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // so that regex can rely that `&str: !FnMut` <br>这样 regex 可以依靠 `&str: !FnMut`<br>
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Performs the call operation. <br>执行调用操作。<br>
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// The version of the call operator that takes a mutable receiver. <br>采用可变接收者的调用运算符的版本。<br>
///
/// Instances of `FnMut` can be called repeatedly and may mutate state. <br>`FnMut` 的实例可以重复调用，并且可以改变状态。<br>
///
/// `FnMut` is implemented automatically by closures which take mutable references to captured variables, as well as all types that implement [`Fn`], e.g., (safe) [function pointers] (since `FnMut` is a supertrait of [`Fn`]). <br>`FnMut` 是由闭包自动实现的，闭包采用对捕获变量的可变引用，以及实现 [`Fn`] 的所有类型，例如 (safe) [函数指针][function pointers] (因为 `FnMut` 是 [`Fn`] 的 super trait)。<br>
/// Additionally, for any type `F` that implements `FnMut`, `&mut F` implements `FnMut`, too. <br>另外，对于任何实现 `FnMut` 的 `F` 类型，`&mut F` 也实现 `FnMut`。<br>
///
/// Since [`FnOnce`] is a supertrait of `FnMut`, any instance of `FnMut` can be used where a [`FnOnce`] is expected, and since [`Fn`] is a subtrait of `FnMut`, any instance of [`Fn`] can be used where `FnMut` is expected. <br>由于 [`FnOnce`] 是 `FnMut` 的 super trait，因此可以在期望 [`FnOnce`] 的地方使用 `FnMut` 的任何实例，并且由于 [`Fn`] 是 `FnMut` 的子特性，因此可以在预期 `FnMut` 的地方使用 [`Fn`] 的任何实例。<br>
///
/// Use `FnMut` as a bound when you want to accept a parameter of function-like type and need to call it repeatedly, while allowing it to mutate state. <br>当您想接受类似函数类型的参数并需要反复调用它，同时允许其改变状态时，请使用 `FnMut` 作为绑定。<br>
/// If you don't want the parameter to mutate state, use [`Fn`] as a bound; <br>如果您不希望参数改变状态，请使用 [`Fn`] 作为绑定；<br> if you don't need to call it repeatedly, use [`FnOnce`]. <br>如果不需要重复调用，请使用 [`FnOnce`]。<br>
///
/// See the [chapter on closures in *The Rust Programming Language*][book] for some more information on this topic. <br>有关此主题的更多信息，请参见 [Rust 编程语言][book] 中关于闭包的章节。<br>
///
/// Also of note is the special syntax for `Fn` traits (e.g. <br>还要注意的是 `Fn` traits 的特殊语法 (例如<br>
/// `Fn(usize, bool) -> usize`). Those interested in the technical details of this can refer to [the relevant section in the *Rustonomicon*][nomicon]. <br>`Fn(usize, bool) -> usize`)。对此技术细节感兴趣的人可以参考 [Rustonomicon 中的相关部分][nomicon]。<br>
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Calling a mutably capturing closure <br>调用可变捕获闭包<br>
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Using a `FnMut` parameter <br>使用 `FnMut` 参数<br>
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "FnMut"]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    on(
        _Self = "unsafe fn",
        note = "unsafe function cannot be called generically without an unsafe block",
        // SAFETY: tidy is not smart enough to tell that the below unsafe block is a string <br>tidy 不够聪明，无法判断下面的 unsafe 块是字符串<br>
        label = "call the function in a closure: `|| unsafe {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // so that regex can rely that `&str: !FnMut` <br>这样 regex 可以依靠 `&str: !FnMut`<br>
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Performs the call operation. <br>执行调用操作。<br>
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// The version of the call operator that takes a by-value receiver. <br>具有按值接收者的调用运算符的版本。<br>
///
/// Instances of `FnOnce` can be called, but might not be callable multiple times. <br>可以调用 `FnOnce` 的实例，但可能无法多次调用。<br> Because of this, if the only thing known about a type is that it implements `FnOnce`, it can only be called once. <br>因此，如果唯一知道类型的是它实现 `FnOnce`，则只能调用一次。<br>
///
/// `FnOnce` is implemented automatically by closures that might consume captured variables, as well as all types that implement [`FnMut`], e.g., (safe) [function pointers] (since `FnOnce` is a supertrait of [`FnMut`]). <br>`FnOnce` 由可能消耗捕获的变量的闭包以及所有实现 [`FnMut`] 的类型自动实现，例如 (safe) [函数指针][function pointers] (因为 `FnOnce` 是 [`FnMut`] 的 super trait)。<br>
///
///
/// Since both [`Fn`] and [`FnMut`] are subtraits of `FnOnce`, any instance of [`Fn`] or [`FnMut`] can be used where a `FnOnce` is expected. <br>由于 [`Fn`] 和 [`FnMut`] 都是 `FnOnce` 的子特性，因此可以在期望使用 `FnOnce` 的情况下使用 [`Fn`] 或 [`FnMut`] 的任何实例。<br>
///
/// Use `FnOnce` as a bound when you want to accept a parameter of function-like type and only need to call it once. <br>当您想接受类似函数类型的参数并且只需要调用一次时，可以使用 `FnOnce` 作为绑定。<br>
/// If you need to call the parameter repeatedly, use [`FnMut`] as a bound; <br>如果需要重复调用该参数，请使用 [`FnMut`] 作为界限；<br> if you also need it to not mutate state, use [`Fn`]. <br>如果还需要它不改变状态，请使用 [`Fn`]。<br>
///
/// See the [chapter on closures in *The Rust Programming Language*][book] for some more information on this topic. <br>有关此主题的更多信息，请参见 [Rust 编程语言][book] 中关于闭包的章节。<br>
///
/// Also of note is the special syntax for `Fn` traits (e.g. <br>还要注意的是 `Fn` traits 的特殊语法 (例如<br>
/// `Fn(usize, bool) -> usize`). Those interested in the technical details of this can refer to [the relevant section in the *Rustonomicon*][nomicon]. <br>`Fn(usize, bool) -> usize`)。对此技术细节感兴趣的人可以参考 [Rustonomicon 中的相关部分][nomicon]。<br>
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Using a `FnOnce` parameter <br>使用 `FnOnce` 参数<br>
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consumes its captured variables, so it cannot be run more than once. <br>`func` 消耗其捕获的变量，因此不能多次运行。<br>
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Attempting to invoke `func()` again will throw a `use of moved value` error for `func`. <br>再次尝试调用 `func()` 将为 `func` 引发 `use of moved value` 错误。<br>
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` can no longer be invoked at this point <br>此时无法再调用 `consume_and_return_x`<br>
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "FnOnce"]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    on(
        _Self = "unsafe fn",
        note = "unsafe function cannot be called generically without an unsafe block",
        // SAFETY: tidy is not smart enough to tell that the below unsafe block is a string <br>tidy 不够聪明，无法判断下面的 unsafe 块是字符串<br>
        label = "call the function in a closure: `|| unsafe {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // so that regex can rely that `&str: !FnMut` <br>这样 regex 可以依靠 `&str: !FnMut`<br>
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// The returned type after the call operator is used. <br>使用调用运算符后的返回类型。<br>
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Performs the call operation. <br>执行调用操作。<br>
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}
