/// Custom code within the destructor. <br>析构函数中的自定义代码。<br>
///
/// When a value is no longer needed, Rust will run a "destructor" on that value. <br>当不再需要某个值时，Rust 将对该值运行 "析构函数"。<br>
/// The most common way that a value is no longer needed is when it goes out of scope. <br>不再需要值的最常见方法是离开作用域。<br> Destructors may still run in other circumstances, but we're going to focus on scope for the examples here. <br>析构函数可能仍在其他情况下运行，但是在这里的示例中，我们将重点关注作用域。<br>
/// To learn about some of those other cases, please see [the reference] section on destructors. <br>要了解其他一些情况，请参见析构函数的 [参考][the reference] 部分。<br>
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// This destructor consists of two components: <br>此析构函数由两个组件组成：<br>
/// - A call to `Drop::drop` for that value, if this special `Drop` trait is implemented for its type. <br>如果为此类型实现了特殊的 `Drop` trait，则对该值调用 `Drop::drop`。<br>
/// - The automatically generated "drop glue" which recursively calls the destructors of all the fields of this value. <br>自动生成的 "drop glue" 递归调用该值的所有字段的析构函数。<br>
///
/// As Rust automatically calls the destructors of all contained fields, you don't have to implement `Drop` in most cases. <br>由于 Rust 自动调用所有包含字段的析构函数，因此在大多数情况下，您无需实现 `Drop`。<br>
/// But there are some cases where it is useful, for example for types which directly manage a resource. <br>但是在某些情况下它很有用，例如对于直接管理资源的类型。<br>
/// That resource may be memory, it may be a file descriptor, it may be a network socket. <br>该资源可能是内存，可能是文件描述符，可能是网络套接字。<br>
/// Once a value of that type is no longer going to be used, it should "clean up" its resource by freeing the memory or closing the file or socket. <br>一旦不再使用该类型的值，则应通过释放内存或关闭文件或套接字 "clean up" 资源。<br>
/// This is the job of a destructor, and therefore the job of `Drop::drop`. <br>这是析构函数的工作，因此也是 `Drop::drop` 的工作。<br>
///
/// ## Examples
///
/// To see destructors in action, let's take a look at the following program: <br>要查看析构函数的作用，让我们看一下以下程序：<br>
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust will first call `Drop::drop` for `_x` and then for both `_x.one` and `_x.two`, meaning that running this will print <br>Rust 将首先为 `_x` 调用 `Drop::drop`，然后为 `_x.one` 和 `_x.two` 调用，这意味着运行此命令将打印<br>
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Even if we remove the implementation of `Drop` for `HasTwoDrop`, the destructors of its fields are still called. <br>即使我们删除了针对 `HasTwoDrop` 的 `Drop` 的实现，其字段的析构函数仍然会被调用。<br>
/// This would result in <br>这将导致<br>
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## You cannot call `Drop::drop` yourself <br>您不能自己调用 `Drop::drop`<br>
///
/// Because `Drop::drop` is used to clean up a value, it may be dangerous to use this value after the method has been called. <br>因为 `Drop::drop` 是用来清理一个值的，所以在调用方法后使用该值可能很危险。<br>
/// As `Drop::drop` does not take ownership of its input, Rust prevents misuse by not allowing you to call `Drop::drop` directly. <br>由于 `Drop::drop` 不拥有其输入的所有权，因此 Rust 通过不允许您直接调用 `Drop::drop` 来防止误用。<br>
///
/// In other words, if you tried to explicitly call `Drop::drop` in the above example, you'd get a compiler error. <br>换句话说，如果您在上面的示例中尝试显式调用 `Drop::drop`，则会出现编译器错误。<br>
///
/// If you'd like to explicitly call the destructor of a value, [`mem::drop`] can be used instead. <br>如果您想显式调用一个值的析构函数，可以使用 [`mem::drop`] 代替。<br>
///
/// [`mem::drop`]: drop
///
/// ## Drop order <br>Drop 指令<br>
///
/// Which of our two `HasDrop` drops first, though? <br>但是，我们的两个 `HasDrop` 哪个先丢弃掉？<br> For structs, it's the same order that they're declared: first `one`, then `two`. <br>对于结构体，其声明顺序相同：首先是 `one`，然后是 `two`。<br>
/// If you'd like to try this yourself, you can modify `HasDrop` above to contain some data, like an integer, and then use it in the `println!` inside of `Drop`. <br>如果您想自己尝试一下，可以修改上面的 `HasDrop` 以包含一些数据 (例如整数)，然后在 `Drop` 内部的 `println!` 中使用它。<br>
/// This behavior is guaranteed by the language. <br>此行为由语言保证。<br>
///
/// Unlike for structs, local variables are dropped in reverse order: <br>与结构体不同，局部变量以相反的顺序丢弃：<br>
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// This will print <br>这将打印<br>
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Please see [the reference] for the full rules. <br>有关完整规则，请参见 [the reference]。<br>
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` and `Drop` are exclusive <br>`Copy` 和 `Drop` 是排他的<br>
///
/// You cannot implement both [`Copy`] and `Drop` on the same type. <br>您不能在同一类型上同时实现 [`Copy`] 和 `Drop`。<br> Types that are `Copy` get implicitly duplicated by the compiler, making it very hard to predict when, and how often destructors will be executed. <br>`Copy` 类型被编译器隐式复制，这使得很难预测何时以及将执行析构函数的频率。<br>
///
/// As such, these types cannot have destructors. <br>因此，这些类型不能有析构函数。<br>
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Executes the destructor for this type. <br>执行此类型的析构函数。<br>
    ///
    /// This method is called implicitly when the value goes out of scope, and cannot be called explicitly (this is compiler error [E0040]). <br>当值离开作用域时隐式调用此方法，并且不能显式调用此方法 (会得到编译器 [E0040] 错误)。<br>
    /// However, the [`mem::drop`] function in the prelude can be used to call the argument's `Drop` implementation. <br>但是，prelude 中的 [`mem::drop`] 函数可用于调用参数的 `Drop` 实现。<br>
    ///
    /// When this method has been called, `self` has not yet been deallocated. <br>当这个方法被调用时，`self` 还没有被释放。<br>
    /// That only happens after the method is over. <br>只有在方法结束后才会发生这种情况。<br>
    /// If this wasn't the case, `self` would be a dangling reference. <br>如果不是这种情况，那么 `self` 将是悬垂引用。<br>
    ///
    /// # Panics
    ///
    /// Given that a [`panic!`] will call `drop` as it unwinds, any [`panic!`] in a `drop` implementation will likely abort. <br>考虑到 [`panic!`] 在展开时将调用 `drop`，因此 `drop` 实现中的任何 [`panic!`] 都可能会终止。<br>
    ///
    /// Note that even if this panics, the value is considered to be dropped; <br>请注意，即使此 panics，该值也被视为已丢弃；<br>
    /// you must not cause `drop` to be called again. <br>您不得再次调用 `drop`。<br>
    /// This is normally automatically handled by the compiler, but when using unsafe code, can sometimes occur unintentionally, particularly when using [`ptr::drop_in_place`]. <br>这通常由编译器自动处理，但是在使用不安全的代码时，有时可能会无意间发生，尤其是在使用 [`ptr::drop_in_place`] 时。<br>
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040
    /// [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}
