//! Error types for conversion to integral types. <br>转换为整数类型的错误类型。<br>

use crate::convert::Infallible;
use crate::fmt;

/// The error type returned when a checked integral type conversion fails. <br>当检查的整数类型转换失败时，返回错误类型。<br>
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl const From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Match rather than coerce to make sure that code like `From<Infallible> for TryFromIntError` above will keep working when `Infallible` becomes an alias to `!`. <br>匹配而不是强制，以确保当 `Infallible` 成为 `!` 的别名时，上述 `From<Infallible> for TryFromIntError` 这样的代码将继续起作用。<br>
        //
        //
        match never {}
    }
}

/// An error which can be returned when parsing an integer. <br>解析整数时可以返回的错误。<br>
///
/// This error is used as the error type for the `from_str_radix()` functions on the primitive integer types, such as [`i8::from_str_radix`]. <br>此错误用作原始整数类型 (例如 [`i8::from_str_radix`]) 上 `from_str_radix()` 函数的错误类型。<br>
///
/// # Potential causes <br>潜在原因<br>
///
/// Among other causes, `ParseIntError` can be thrown because of leading or trailing whitespace in the string e.g., when it is obtained from the standard input. <br>除其他原因外，例如，当从标准输入中获取 `ParseIntError` 时，可能会由于字符串中的前导或尾随空格而抛出 `ParseIntError`。<br>
///
/// Using the [`str::trim()`] method ensures that no whitespace remains before parsing. <br>使用 [`str::trim()`] 方法可确保在解析之前不留空格。<br>
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {e}");
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum to store the various types of errors that can cause parsing an integer to fail. <br>枚举存储各种类型的错误，这些错误可能导致解析整数失败。<br>
///
/// # Example
///
/// ```
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[stable(feature = "int_error_matching", since = "1.55.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Value being parsed is empty. <br>被解析的值是空的。<br>
    ///
    /// This variant will be constructed when parsing an empty string. <br>解析空字符串时将创建此变体。<br>
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    Empty,
    /// Contains an invalid digit in its context. <br>在其上下文中包含无效数字。<br>
    ///
    /// Among other causes, this variant will be constructed when parsing a string that contains a non-ASCII char. <br>除其他原因外，当解析包含非 ASCII 字符的字符串时，将创建这个变体。<br>
    ///
    /// This variant is also constructed when a `+` or `-` is misplaced within a string either on its own or in the middle of a number. <br>当 `+` 或 `-` 单独放置在字符串中或放置在数字中间时，也会创建此变体。<br>
    ///
    ///
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    InvalidDigit,
    /// Integer is too large to store in target integer type. <br>整数太大，无法存储为目标整数类型。<br>
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    PosOverflow,
    /// Integer is too small to store in target integer type. <br>整数太小，无法存储为目标整数类型。<br>
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    NegOverflow,
    /// Value was Zero <br>值为零<br>
    ///
    /// This variant will be emitted when the parsing string has a value of zero, which would be illegal for non-zero types. <br>当解析字符串的值为零时，将发出此变体，这对于非零类型是非法的。<br>
    ///
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    Zero,
}

impl ParseIntError {
    /// Outputs the detailed cause of parsing an integer failing. <br>输出解析整数失败的详细原因。<br>
    #[must_use]
    #[stable(feature = "int_error_matching", since = "1.55.0")]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}
