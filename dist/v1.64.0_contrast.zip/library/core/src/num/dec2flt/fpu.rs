//! Platform-specific, assembly instructions to avoid intermediate rounding on architectures with FPUs. <br>特定于平台的装配说明，以避免对具有 FPU 的架构进行中间舍入。<br>
//!

pub use fpu_precision::set_precision;

// On x86, the x87 FPU is used for float operations if the SSE/SSE2 extensions are not available. <br>在 x86 上，如果 SSE/SSE2 扩展不可用，则将 x87 FPU 用于浮动操作。<br>
// The x87 FPU operates with 80 bits of precision by default, which means that operations will round to 80 bits causing double rounding to happen when values are eventually represented as <br>x87 FPU 默认情况下以 80 位精度运行，这意味着运算将舍入到 80 位，从而在最终将值表示为时将发生双舍入<br>
//
// 32/64 bit float values. <br>32/64 位浮点值。<br> To overcome this, the FPU control word can be set so that the computations are performed in the desired precision. <br>为了克服这个问题，可以设置 FPU 控制字，以便以所需的精度执行计算。<br>
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use core::arch::asm;
    use core::mem::size_of;

    /// A structure used to preserve the original value of the FPU control word, so that it can be restored when the structure is dropped. <br>一种结构体，用于保留 FPU 控制字的原始值，以便在丢弃该结构体时可以将其恢复。<br>
    ///
    ///
    /// The x87 FPU is a 16-bits register whose fields are as follows: <br>x87 FPU 是一个 16 位寄存器，其字段如下：<br>
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// The documentation for all of the fields is available in the IA-32 Architectures Software Developer's Manual (Volume 1). <br>IA-32 体系结构软件开发人员手册 (第 1 卷) 中提供了所有字段的文档。<br>
    ///
    /// The only field which is relevant for the following code is PC, Precision Control. <br>与以下代码相关的唯一字段是 PC，Precision Control。<br>
    /// This field determines the precision of the operations performed by the  FPU. <br>该字段确定 FPU 执行的操作的精度。<br>
    /// It can be set to: <br>可以设置为：<br>
    ///  - 0b00, single precision i.e., 32-bits <br>0b00，单精度，即 32 位<br>
    ///  - 0b10, double precision i.e., 64-bits <br>0b10，双精度，即 64 位<br>
    ///  - 0b11, double extended precision i.e., 80-bits (default state) The 0b01 value is reserved and should not be used. <br>0b11，双精度扩展精度，即 80 位 (默认状态) 0b01 值是保留的，不应使用。<br>
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: the `fldcw` instruction has been audited to be able to work correctly with any `u16` <br>`fldcw` 指令已通过审核，可以与任何 `u16` 一起正常使用<br>
        //
        unsafe {
            asm!(
                "fldcw word ptr [{}]",
                in(reg) &cw,
                options(nostack),
            )
        }
    }

    /// Sets the precision field of the FPU to `T` and returns a `FPUControlWord`. <br>将 FPU 的 precision 字段设置为 `T` 并返回 `FPUControlWord`。<br>
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Compute the value for the Precision Control field that is appropriate for `T`. <br>计算适用于 `T` 的 Precision Control 字段的值。<br>
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits <br>32 位<br>
            8 => 0x0200, // 64 bits <br>64 位<br>
            _ => 0x0300, // default, 80 bits <br>默认为 80 位<br>
        };

        // Get the original value of the control word to restore it later, when the `FPUControlWord` structure is dropped <br>丢弃 `FPUControlWord` 结构体时，获取控制字的原始值以在以后还原它<br>
        //
        // SAFETY: the `fnstcw` instruction has been audited to be able to work correctly with any `u16` <br>`fnstcw` 指令已通过审核，可以与任何 `u16` 一起正常使用<br>
        //
        unsafe {
            asm!(
                "fnstcw word ptr [{}]",
                in(reg) &mut cw,
                options(nostack),
            )
        }

        // Set the control word to the desired precision. <br>将控制字设置为所需的精度。<br>
        // This is achieved by masking away the old precision (bits 8 and 9, 0x300) and replacing it with the precision flag computed above. <br>这可以通过掩盖旧的精度 (位 8 和 9，0x300) 并将其替换为上面计算的精度标志来实现。<br>
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

// In most architectures, floating point operations have an explicit bit size, therefore the precision of the computation is determined on a per-operation basis. <br>在大多数体系结构中，浮点运算具有显式的位大小，因此计算的精度取决于每个运算。<br>
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}
