//! Representation of a float as the significant digits and exponent. <br>将浮点数表示为有效数字和指数。<br>

use crate::num::dec2flt::float::RawFloat;
use crate::num::dec2flt::fpu::set_precision;

#[rustfmt::skip]
const INT_POW10: [u64; 16] = [
    1,
    10,
    100,
    1000,
    10000,
    100000,
    1000000,
    10000000,
    100000000,
    1000000000,
    10000000000,
    100000000000,
    1000000000000,
    10000000000000,
    100000000000000,
    1000000000000000,
];

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Number {
    pub exponent: i64,
    pub mantissa: u64,
    pub negative: bool,
    pub many_digits: bool,
}

impl Number {
    /// Detect if the float can be accurately reconstructed from native floats. <br>检测是否可以从原生浮点数准确地重建浮点数。<br>
    fn is_fast_path<F: RawFloat>(&self) -> bool {
        F::MIN_EXPONENT_FAST_PATH <= self.exponent
            && self.exponent <= F::MAX_EXPONENT_DISGUISED_FAST_PATH
            && self.mantissa <= F::MAX_MANTISSA_FAST_PATH
            && !self.many_digits
    }

    /// The fast path algorithm using machine-sized integers and floats. <br>使用机器大小的整数和浮点数的快速路径算法。<br>
    ///
    /// This is extracted into a separate function so that it can be attempted before constructing a Decimal. <br>这被提取到一个单独的函数中，以便可以在创建一个 Decimal 之前尝试它。<br>
    /// This only works if both the mantissa and the exponent can be exactly represented as a machine float, since IEE-754 guarantees no rounding will occur. <br>这只适用于尾数和指数都可以精确表示为机器浮点数的情况，因为 IEE-754 保证不会发生舍入。<br>
    ///
    ///
    /// There is an exception: disguised fast-path cases, where we can shift powers-of-10 from the exponent to the significant digits. <br>有一个例外：伪装的快速路径情况，我们可以将 10 的幂从指数转移到有效数字。<br>
    ///
    ///
    pub fn try_fast_path<F: RawFloat>(&self) -> Option<F> {
        // The fast path crucially depends on arithmetic being rounded to the correct number of bits without any intermediate rounding. <br>快速路径至关重要地取决于将算术四舍五入到正确的位数，而无需任何中间舍入。<br>
        // On x86 (without SSE or SSE2) this requires the precision of the x87 FPU stack to be changed so that it directly rounds to 64/32 bit. <br>在 x86 (不带 SSE 或 SSE2) 上，这需要更改 x87 FPU 栈的精度，以便直接将其舍入为 64/32 位。<br>
        // The `set_precision` function takes care of setting the precision on architectures which require setting it by changing the global state (like the control word of the x87 FPU). <br>`set_precision` 函数负责在需要通过更改 ^ 状态 (例如 x87 FPU 的控制字) 进行设置的体系结构上设置精度。<br>
        //
        //
        let _cw = set_precision::<F>();

        if self.is_fast_path::<F>() {
            let mut value = if self.exponent <= F::MAX_EXPONENT_FAST_PATH {
                // normal fast path <br>正常快速路径<br>
                let value = F::from_u64(self.mantissa);
                if self.exponent < 0 {
                    value / F::pow10_fast_path((-self.exponent) as _)
                } else {
                    value * F::pow10_fast_path(self.exponent as _)
                }
            } else {
                // disguised fast path <br>伪装的快速路径<br>
                let shift = self.exponent - F::MAX_EXPONENT_FAST_PATH;
                let mantissa = self.mantissa.checked_mul(INT_POW10[shift as usize])?;
                if mantissa > F::MAX_MANTISSA_FAST_PATH {
                    return None;
                }
                F::from_u64(mantissa) * F::pow10_fast_path(F::MAX_EXPONENT_FAST_PATH as _)
            };
            if self.negative {
                value = -value;
            }
            Some(value)
        } else {
            None
        }
    }
}
