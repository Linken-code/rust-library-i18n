//! Functions to parse floating-point numbers. <br>解析浮点数的函数。<br>

use crate::num::dec2flt::common::{is_8digits, AsciiStr, ByteSlice};
use crate::num::dec2flt::float::RawFloat;
use crate::num::dec2flt::number::Number;

const MIN_19DIGIT_INT: u64 = 100_0000_0000_0000_0000;

/// Parse 8 digits, loaded as bytes in little-endian order. <br>解析 8 位数字，以小端顺序加载为字节。<br>
///
/// This uses the trick where every digit is in [0x030, 0x39], and therefore can be parsed in 3 multiplications, much faster than the normal 8. <br>这使用了一个技巧，即每个数字都在 [0x030，0x39] 中，因此可以在 3 次乘法中解析，比正常的 8 次乘法要快得多。<br>
///
/// This is based off the algorithm described in "Fast numeric string to int", available here: <https://johnnylee-sde.github.io/Fast-numeric-string-to-int/>. <br>这是基于 "将数字字符串快速转换为整数" 中描述的算法，可在此处获得: <https://johnnylee-sde.github.io/Fast-numeric-string-to-int/>。<br>
///
///
///
fn parse_8digits(mut v: u64) -> u64 {
    const MASK: u64 = 0x0000_00FF_0000_00FF;
    const MUL1: u64 = 0x000F_4240_0000_0064;
    const MUL2: u64 = 0x0000_2710_0000_0001;
    v -= 0x3030_3030_3030_3030;
    v = (v * 10) + (v >> 8); // will not overflow, fits in 63 bits <br>不会溢出，适合 63 位<br>
    let v1 = (v & MASK).wrapping_mul(MUL1);
    let v2 = ((v >> 16) & MASK).wrapping_mul(MUL2);
    ((v1.wrapping_add(v2) >> 32) as u32) as u64
}

/// Parse digits until a non-digit character is found. <br>解析数字直到找到非数字字符。<br>
fn try_parse_digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    // may cause overflows, to be handled later <br>可能会导致溢出，稍后处理<br>
    s.parse_digits(|digit| {
        *x = x.wrapping_mul(10).wrapping_add(digit as _);
    });
}

/// Parse up to 19 digits (the max that can be stored in a 64-bit integer). <br>解析最多 19 位数字 (可以存储在 64 位整数中的最大值)。<br>
fn try_parse_19digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    while *x < MIN_19DIGIT_INT {
        if let Some(&c) = s.as_ref().first() {
            let digit = c.wrapping_sub(b'0');
            if digit < 10 {
                *x = (*x * 10) + digit as u64; // no overflows here <br>这里没有溢出<br>
                // SAFETY: cannot be empty <br>不能为空<br>
                unsafe {
                    s.step();
                }
            } else {
                break;
            }
        } else {
            break;
        }
    }
}

/// Try to parse 8 digits at a time, using an optimized algorithm. <br>尝试使用优化算法一次解析 8 位数字。<br>
fn try_parse_8digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    // may cause overflows, to be handled later <br>可能会导致溢出，稍后处理<br>
    if let Some(v) = s.read_u64() {
        if is_8digits(v) {
            *x = x.wrapping_mul(1_0000_0000).wrapping_add(parse_8digits(v));
            // SAFETY: already ensured the buffer was >= 8 bytes in read_u64. <br>已经确保缓冲区在 read_u64 中 >= 8 个字节。<br>
            unsafe {
                s.step_by(8);
            }
            if let Some(v) = s.read_u64() {
                if is_8digits(v) {
                    *x = x.wrapping_mul(1_0000_0000).wrapping_add(parse_8digits(v));
                    // SAFETY: already ensured the buffer was >= 8 bytes in try_read_u64. <br>已经确保 try_read_u64 中的缓冲区 >= 8 个字节。<br>
                    unsafe {
                        s.step_by(8);
                    }
                }
            }
        }
    }
}

/// Parse the scientific notation component of a float. <br>解析浮点数的科学记数法组件。<br>
fn parse_scientific(s: &mut AsciiStr<'_>) -> Option<i64> {
    let mut exponent = 0_i64;
    let mut negative = false;
    if let Some(&c) = s.as_ref().get(0) {
        negative = c == b'-';
        if c == b'-' || c == b'+' {
            // SAFETY: s cannot be empty <br>s 不能为空<br>
            unsafe {
                s.step();
            }
        }
    }
    if s.first_isdigit() {
        s.parse_digits(|digit| {
            // no overflows here, saturate well before overflow <br>这里没有溢出，在溢出之前饱和<br>
            if exponent < 0x10000 {
                exponent = 10 * exponent + digit as i64;
            }
        });
        if negative { Some(-exponent) } else { Some(exponent) }
    } else {
        None
    }
}

/// Parse a partial, non-special floating point number. <br>解析部分非特殊浮点数。<br>
///
/// This creates a representation of the float as the significant digits and the decimal exponent. <br>这将创建浮点数表示为有效数字和十进制指数。<br>
///
fn parse_partial_number(s: &[u8], negative: bool) -> Option<(Number, usize)> {
    let mut s = AsciiStr::new(s);
    let start = s;
    debug_assert!(!s.is_empty());

    // parse initial digits before dot <br>解析点之前的初始数字<br>
    let mut mantissa = 0_u64;
    let digits_start = s;
    try_parse_digits(&mut s, &mut mantissa);
    let mut n_digits = s.offset_from(&digits_start);

    // handle dot with the following digits <br>用以下数字处理点<br>
    let mut n_after_dot = 0;
    let mut exponent = 0_i64;
    let int_end = s;
    if s.first_is(b'.') {
        // SAFETY: s cannot be empty due to first_is <br>由于 first_is，s 不能为空<br>
        unsafe { s.step() };
        let before = s;
        try_parse_8digits(&mut s, &mut mantissa);
        try_parse_digits(&mut s, &mut mantissa);
        n_after_dot = s.offset_from(&before);
        exponent = -n_after_dot as i64;
    }

    n_digits += n_after_dot;
    if n_digits == 0 {
        return None;
    }

    // handle scientific format <br>处理科学格式<br>
    let mut exp_number = 0_i64;
    if s.first_is2(b'e', b'E') {
        // SAFETY: s cannot be empty <br>s 不能为空<br>
        unsafe {
            s.step();
        }
        // If None, we have no trailing digits after exponent, or an invalid float. <br>如果没有，我们在指数之后没有尾随数字，或者一个无效的浮点数。<br>
        exp_number = parse_scientific(&mut s)?;
        exponent += exp_number;
    }

    let len = s.offset_from(&start) as _;

    // handle uncommon case with many digits <br>处理多位数的罕见情况<br>
    if n_digits <= 19 {
        return Some((Number { exponent, mantissa, negative, many_digits: false }, len));
    }

    n_digits -= 19;
    let mut many_digits = false;
    let mut p = digits_start;
    while p.first_is2(b'0', b'.') {
        // SAFETY: p cannot be empty due to first_is2 <br>由于 first_is2，p 不能为空<br>
        unsafe {
            // '0' = b'.' + 2
            n_digits -= p.first_unchecked().saturating_sub(b'0' - 1) as isize;
            p.step();
        }
    }
    if n_digits > 0 {
        // at this point we have more than 19 significant digits, let's try again <br>此时我们有超过 19 位有效数字，让我们再试一次<br>
        many_digits = true;
        mantissa = 0;
        let mut s = digits_start;
        try_parse_19digits(&mut s, &mut mantissa);
        exponent = if mantissa >= MIN_19DIGIT_INT {
            // big int <br>大整数<br>
            int_end.offset_from(&s)
        } else {
            // SAFETY: the next byte must be present and be '.' We know this is true because we had more than 19 digits previously, so we overflowed a 64-bit integer, but parsing only the integral digits produced less than 19 digits. <br>下一个字节必须存在并且是 '.' 我们知道这是真的，因为我们之前有超过 19 位数字，所以我们溢出了一个 64 位整数，但只解析整数位产生少于 19 位数字。<br>
            // That means we must have a decimal point, and at least 1 fractional digit. <br>这意味着我们必须有一个小数点，并且至少有 1 个小数位。<br>
            //
            //
            //
            //
            unsafe { s.step() };
            let before = s;
            try_parse_19digits(&mut s, &mut mantissa);
            -s.offset_from(&before)
        } as i64;
        // add back the explicit part <br>添加回显式部分<br>
        exponent += exp_number;
    }

    Some((Number { exponent, mantissa, negative, many_digits }, len))
}

/// Try to parse a non-special floating point number. <br>尝试解析一个非特殊的浮点数。<br>
pub fn parse_number(s: &[u8], negative: bool) -> Option<Number> {
    if let Some((float, rest)) = parse_partial_number(s, negative) {
        if rest == s.len() {
            return Some(float);
        }
    }
    None
}

/// Parse a partial representation of a special, non-finite float. <br>解析特殊的非有限浮点数的部分表示。<br>
fn parse_partial_inf_nan<F: RawFloat>(s: &[u8]) -> Option<(F, usize)> {
    fn parse_inf_rest(s: &[u8]) -> usize {
        if s.len() >= 8 && s[3..].as_ref().starts_with_ignore_case(b"inity") { 8 } else { 3 }
    }
    if s.len() >= 3 {
        if s.starts_with_ignore_case(b"nan") {
            return Some((F::NAN, 3));
        } else if s.starts_with_ignore_case(b"inf") {
            return Some((F::INFINITY, parse_inf_rest(s)));
        }
    }
    None
}

/// Try to parse a special, non-finite float. <br>尝试解析一个特殊的、非有限的浮点数。<br>
pub fn parse_inf_nan<F: RawFloat>(s: &[u8], negative: bool) -> Option<F> {
    if let Some((mut float, rest)) = parse_partial_inf_nan::<F>(s) {
        if rest == s.len() {
            if negative {
                float = -float;
            }
            return Some(float);
        }
    }
    None
}
