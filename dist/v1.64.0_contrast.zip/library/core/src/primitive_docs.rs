// `library/{std,core}/src/primitive_docs.rs` should have the same contents. <br>`library/{std,core}/src/primitive_docs.rs` 应该具有相同的内容。<br>
// These are different files so that relative links work properly without having to have `CARGO_PKG_NAME` set, but conceptually they should always be the same. <br>这些是不同的文件，因此相关链接无需设置 `CARGO_PKG_NAME` 即可正常工作，但从概念上讲，它们应该始终相同。<br>
//
#[doc(primitive = "bool")]
#[doc(alias = "true")]
#[doc(alias = "false")]
/// The boolean type. <br>布尔类型。<br>
///
/// The `bool` represents a value, which could only be either [`true`] or [`false`]. <br>`bool` 代表一个值，它只能是 [`true`] 或 [`false`]。<br>
/// If you cast a `bool` into an integer, [`true`] will be 1 and [`false`] will be 0. <br>如果将 `bool` 转换为整数，则 [`true`] 表示为 1，[`false`] 表示为 0。<br>
///
/// # Basic usage <br>基本用法<br>
///
/// `bool` implements various traits, such as [`BitAnd`], [`BitOr`], [`Not`], etc., which allow us to perform boolean operations using `&`, `|` and `!`. <br>`bool` 实现了各种 traits，例如 [`BitAnd`]、[`BitOr`]、[`Not`] 等，允许我们使用 `&`、`|` 和 `!` 执行布尔运算。<br>
///
///
/// [`if`] requires a `bool` value as its conditional. <br>[`if`] 需要一个 `bool` 值作为它的条件。<br>
/// [`assert!`], which is an important macro in testing, checks whether an expression is [`true`] and panics if it isn't. <br>[`assert!`] 是测试中的一个重要宏，检查表达式是否为 [`true`]，如果不是则为 panics。<br>
///
/// ```
/// let bool_val = true & false | false;
/// assert!(!bool_val);
/// ```
///
/// [`true`]: ../std/keyword.true.html
/// [`false`]: ../std/keyword.false.html
/// [`BitAnd`]: ops::BitAnd
/// [`BitOr`]: ops::BitOr
/// [`Not`]: ops::Not
/// [`if`]: ../std/keyword.if.html
///
/// # Examples
///
/// A trivial example of the usage of `bool`: <br>`bool` 用法的一个简单示例：<br>
///
/// ```
/// let praise_the_borrow_checker = true;
///
/// // using the `if` conditional <br>使用 `if` 有条件<br>
/// if praise_the_borrow_checker {
///     println!("oh, yeah!");
/// } else {
///     println!("what?!!");
/// }
///
/// // ... or, a match pattern <br>或者，匹配模式<br>
/// match praise_the_borrow_checker {
///     true => println!("keep praising!"),
///     false => println!("you should praise!"),
/// }
/// ```
///
/// Also, since `bool` implements the [`Copy`] trait, we don't have to worry about the move semantics (just like the integer and float primitives). <br>另外，由于 `bool` 实现了 [`Copy`] trait，因此我们不必担心移动语义 (就像整数和浮点图元一样)。<br>
///
/// Now an example of `bool` cast to integer type: <br>现在将 `bool` 强制转换为整数类型的示例：<br>
///
/// ```
/// assert_eq!(true as i32, 1);
/// assert_eq!(false as i32, 0);
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_bool {}

#[doc(primitive = "never")]
#[doc(alias = "!")]
//
/// The `!` type, also called "never". <br>`!` 类型，也称为 "never"。<br>
///
/// `!` represents the type of computations which never resolve to any value at all. <br>`!` 表示永远不会解析为任何值的计算类型。<br>
/// For example, the [`exit`] function `fn exit(code: i32) -> !` exits the process without ever returning, and so returns `!`. <br>例如，[`exit`] 函数 `fn exit(code: i32) -> !` 退出该进程而不返回，因此返回 `!`。<br>
///
/// `break`, `continue` and `return` expressions also have type `!`. <br>`break`、`continue` 和 `return` 表达式也具有 `!` 类型。<br> For example we are allowed to write: <br>例如，我们可以写：<br>
///
/// ```
/// #![feature(never_type)]
/// # fn foo() -> u32 {
/// let x: ! = {
///     return 123
/// };
/// # }
/// ```
///
/// Although the `let` is pointless here, it illustrates the meaning of `!`. <br>尽管 `let` 在这里毫无意义，但它说明了 `!` 的含义。<br>
/// Since `x` is never assigned a value (because `return` returns from the entire function), `x` can be given type `!`. <br>由于从未给 `x` 赋值 (因为 `return` 从整个函数返回)，因此可以给 `x` 指定 `!` 类型。<br>
/// We could also replace `return 123` with a `panic!` or a never-ending `loop` and this code would still be valid. <br>我们也可以将 `return 123` 替换为 `panic!` 或永无休止的 `loop`，并且此代码仍然有效。<br>
///
/// A more realistic usage of `!` is in this code: <br>以下代码更实际地使用 `!`：<br>
///
/// ```
/// # fn get_a_number() -> Option<u32> { None }
/// # loop {
/// let num: u32 = match get_a_number() {
///     Some(num) => num,
///     None => break,
/// };
/// # }
/// ```
///
/// Both match arms must produce values of type [`u32`], but since `break` never produces a value at all we know it can never produce a value which isn't a [`u32`]. <br>两个匹配分支都必须产生 [`u32`] 类型的值，但是由于 `break` 根本不会产生值，我们知道它永远不会产生不是 [`u32`] 的值。<br>
///
/// This illustrates another behaviour of the `!` type - expressions with type `!` will coerce into any other type. <br>这说明了 `!` 类型的另一种行为 - 类型为 `!` 的表达式将强制转换为任何其他类型。<br>
///
/// [`u32`]: prim@u32
///
///
///
#[doc = concat!("[`exit`]: ", include_str!("../primitive_docs/process_exit.md"))]
/// # `!` and generics <br>`!` 和泛型<br>
///
/// ## Infallible errors <br>绝对的错误<br>
///
/// The main place you'll see `!` used explicitly is in generic code. <br>您将看到显式使用的 `!` 的主要位置是泛型代码。<br> Consider the [`FromStr`] trait: <br>考虑 [`FromStr`] trait：<br>
///
/// ```
/// trait FromStr: Sized {
///     type Err;
///     fn from_str(s: &str) -> Result<Self, Self::Err>;
/// }
/// ```
///
/// When implementing this trait for [`String`] we need to pick a type for [`Err`]. <br>当为 [`String`] 实现此 trait 时，我们需要为 [`Err`] 选择一个类型。<br> And since converting a string into a string will never result in an error, the appropriate type is `!`. <br>并且由于将字符串转换为字符串永远不会导致错误，因此适当的类型是 `!`。<br>
/// (Currently the type actually used is an enum with no variants, though this is only because `!` was added to Rust at a later date and it may change in the future.) With an [`Err`] type of `!`, if we have to call [`String::from_str`] for some reason the result will be a [`Result<String, !>`] which we can unpack like this: <br>(目前实际使用的类型是一个没有变体的枚举，尽管这只是因为 `!` 以后才会被添加到 Rust 中，并且将来可能会发生变化。) 对于 [`Err`] 类型的 `!`，如果我们由于某种原因不得不调用 [`String::from_str`]，那么结果将是 [`Result<String, !>`]，我们可以像这样解包：<br>
///
///
/// ```
/// #![feature(exhaustive_patterns)]
/// use std::str::FromStr;
/// let Ok(s) = String::from_str("hello");
/// ```
///
/// Since the [`Err`] variant contains a `!`, it can never occur. <br>由于 [`Err`] 变体包含 `!`，因此永远不会发生。<br> If the `exhaustive_patterns` feature is present this means we can exhaustively match on [`Result<T, !>`] by just taking the [`Ok`] variant. <br>如果存在 `exhaustive_patterns` 特性，则意味着我们只需采用 [`Ok`] 变体就可以在 [`Result<T, !>`] 上进行穷尽的匹配。<br>
/// This illustrates another behaviour of `!` - it can be used to "delete" certain enum variants from generic types like `Result`. <br>这说明了 `!` 的另一种行为 - 它可以用于 "delete" 泛型 (如 `Result`) 中的某些枚举变体。<br>
///
/// ## Infinite loops <br>无限循环<br>
///
/// While [`Result<T, !>`] is very useful for removing errors, `!` can also be used to remove successes as well. <br>尽管 [`Result<T, !>`] 对于消除错误非常有用，但 `!` 也可以用于消除成功。<br> If we think of [`Result<T, !>`] as "if this function returns, it has not errored," we get a very intuitive idea of [`Result<!, E>`] as well: if the function returns, it *has* errored. <br>如果我们将 [`Result<T, !>`] 视为 "if this function returns, it has not errored,"，那么我们也会非常直观地想到 [`Result<!, E>`]: 如果函数返回，则 *有* 错误。<br>
///
/// For example, consider the case of a simple web server, which can be simplified to: <br>例如，考虑一个简单的 Web 服务器的情况，它可以简化为：<br>
///
/// ```ignore (hypothetical-example)
/// loop {
///     let (client, request) = get_request().expect("disconnected");
///     let response = request.process();
///     response.send(client);
/// }
/// ```
///
/// Currently, this isn't ideal, because we simply panic whenever we fail to get a new connection. <br>目前，这并不理想，因为只要无法建立新的连接，我们就简单地使用 panic。<br>
/// Instead, we'd like to keep track of this error, like this: <br>相反，我们想跟踪此错误，如下所示：<br>
///
/// ```ignore (hypothetical-example)
/// loop {
///     match get_request() {
///         Err(err) => break err,
///         Ok((client, request)) => {
///             let response = request.process();
///             response.send(client);
///         },
///     }
/// }
/// ```
///
/// Now, when the server disconnects, we exit the loop with an error instead of panicking. <br>现在，当服务器断开连接时，我们以错误退出循环而不是 panic。<br> While it might be intuitive to simply return the error, we might want to wrap it in a [`Result<!, E>`] instead: <br>虽然简单地返回错误可能很直观，但我们可能希望将其包装在 [`Result<!, E>`] 中：<br>
///
/// ```ignore (hypothetical-example)
/// fn server_loop() -> Result<!, ConnectionError> {
///     loop {
///         let (client, request) = get_request()?;
///         let response = request.process();
///         response.send(client);
///     }
/// }
/// ```
///
/// Now, we can use `?` instead of `match`, and the return type makes a lot more sense: if the loop ever stops, it means that an error occurred. <br>现在，我们可以使用 `?` 代替 `match`，并且返回类型更有意义：如果循环停止，则意味着发生了错误。<br> We don't even have to wrap the loop in an `Ok` because `!` coerces to `Result<!, ConnectionError>` automatically. <br>我们甚至不必将循环包装在 `Ok` 中，因为 `!` 会自动强制转换为 `Result<!, ConnectionError>`。<br>
///
/// [`String::from_str`]: str::FromStr::from_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`String`]: ", include_str!("../primitive_docs/string_string.md"))]
/// [`FromStr`]: str::FromStr
///
/// # `!` and traits <br>`!` 和 traits<br>
///
/// When writing your own traits, `!` should have an `impl` whenever there is an obvious `impl` which doesn't `panic!`. <br>编写自己的 traits 时，只要有明显的 `impl` 而不是 `panic!`，`!` 就应该有一个 `impl`。<br>
/// The reason is that functions returning an `impl Trait` where `!` does not have an `impl` of `Trait` cannot diverge as their only possible code path. <br>原因是返回 `impl Trait` 且 `!` 没有 `impl` 的函数不能作为它的唯一可能的代码路径发散。<br>
/// In other words, they can't return `!` from every code path. <br>换句话说，它们不能从每个代码路径返回 `!`。<br>
/// As an example, this code doesn't compile: <br>例如，此代码不会编译：<br>
///
/// ```compile_fail
/// use std::ops::Add;
///
/// fn foo() -> impl Add<u32> {
///     unimplemented!()
/// }
/// ```
///
/// But this code does: <br>但是这段代码可以做到：<br>
///
/// ```
/// use std::ops::Add;
///
/// fn foo() -> impl Add<u32> {
///     if true {
///         unimplemented!()
///     } else {
///         0
///     }
/// }
/// ```
///
/// The reason is that, in the first example, there are many possible types that `!` could coerce to, because many types implement `Add<u32>`. <br>原因是，在第一个示例中，`!` 可以强制转换为许多可能的类型，因为许多类型实现了 `Add<u32>`。<br>
/// However, in the second example, the `else` branch returns a `0`, which the compiler infers from the return type to be of type `u32`. <br>但是，在第二个示例中，`else` 分支返回 `0`，编译器从返回类型推断出它为 `u32` 类型。<br>
/// Since `u32` is a concrete type, `!` can and will be coerced to it. <br>由于 `u32` 是具体类型，因此 `!` 可以并且将被强制使用。<br>
/// See issue [#36375] for more information on this quirk of `!`. <br>有关此 `!` 的更多信息，请参见问题 [#36375]。<br>
///
/// [#36375]: https://github.com/rust-lang/rust/issues/36375
///
/// As it turns out, though, most traits can have an `impl` for `!`. <br>但是，事实证明，大多数 traits 都可以将 `impl` 用作 `!`。<br> Take [`Debug`] for example: <br>以 [`Debug`] 为例：<br>
///
/// ```
/// #![feature(never_type)]
/// # use std::fmt;
/// # trait Debug {
/// #     fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result;
/// # }
/// impl Debug for ! {
///     fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
///         *self
///     }
/// }
/// ```
///
/// Once again we're using `!`'s ability to coerce into any other type, in this case [`fmt::Result`]. <br>我们再次使用 `! ` 的功能来强制转换为任何其他类型，在本例中为 [`fmt::Result`]。<br>
/// Since this method takes a `&!` as an argument we know that it can never be called (because there is no value of type `!` for it to be called with). <br>由于此方法将 `&!` 作为参数，因此我们知道它永远不能被调用 (因为没有 `!` 类型的值可以调用它)。<br>
/// Writing `*self` essentially tells the compiler "We know that this code can never be run, so just treat the entire function body as having type [`fmt::Result`]". <br>编写 `*self` 实质上就是告诉编译器 "我们知道这段代码永远无法运行，所以只需将整个函数体视为具有类型 [`fmt::Result`]"。<br>
/// This pattern can be used a lot when implementing traits for `!`. <br>当为 `!` 实现 traits 时，可以使用这种模式。<br>
/// Generally, any trait which only has methods which take a `self` parameter should have such an impl. <br>通常，任何仅具有采用 `self` 参数的方法的 trait 都应具有这样的含义。<br>
///
/// On the other hand, one trait which would not be appropriate to implement is [`Default`]: <br>另一方面，不适合实现的一个 trait 是 [`Default`]：<br>
///
/// ```
/// trait Default {
///     fn default() -> Self;
/// }
/// ```
///
/// Since `!` has no values, it has no default value either. <br>由于 `!` 没有值，因此也没有默认值。<br>
/// It's true that we could write an `impl` for this which simply panics, but the same is true for any type (we could `impl Default` for (eg.) [`File`] by just making [`default()`] panic.) <br>的确，我们可以为此编写一个 `impl`，它只是 panics，但是对于任何类型都一样 (我们可以通过仅将 [`default()`] panic 制作为 (eg.) [`File`] 来使用 `impl Default`)。<br>
///
///
///
///
///
///
#[doc = concat!("[`File`]: ", include_str!("../primitive_docs/fs_file.md"))]
/// [`Debug`]: fmt::Debug
/// [`default()`]: Default::default
///
#[unstable(feature = "never_type", issue = "35121")]
mod prim_never {}

#[doc(primitive = "char")]
#[allow(rustdoc::invalid_rust_codeblocks)]
/// A character type. <br>一个字符类型。<br>
///
/// The `char` type represents a single character. <br>`char` 类型代表一个字符。<br> More specifically, since 'character' isn't a well-defined concept in Unicode, `char` is a '[Unicode scalar value]'. <br>更具体地说，由于 'character' 在 Unicode 中不是一个明确定义的概念，因此 `char` 是一个 [Unicode 标量值][Unicode scalar value]。<br>
///
/// This documentation describes a number of methods and trait implementations on the `char` type. <br>本文档描述了 `char` 类型上的许多方法和 trait 实现。<br> For technical reasons, there is additional, separate documentation in [the `std::char` module](char/index.html) as well. <br>由于技术原因，[the `std::char` module](char/index.html) 中还有其他单独的文档。<br>
///
/// # Validity
///
/// A `char` is a '[Unicode scalar value]', which is any '[Unicode code point]' other than a [surrogate code point]. <br>`char` 是一个 [Unicode 标量值][Unicode scalar value]，它是除 [代理代码点][surrogate code point] 之外的任何 [Unicode 代码点][Unicode code point]。<br> This has a fixed numerical definition: <br>这有一个固定的数字定义:<br>
/// code points are in the range 0 to 0x10FFFF, inclusive. <br>代码点在 0 到 0x10FFFF 的范围内，包括 0 到 0x10FFFF。<br>
/// Surrogate code points, used by UTF-16, are in the range 0xD800 to 0xDFFF. <br>UTF-16 使用的代理代码点在 0xD800 到 0xDFFF 范围内。<br>
///
/// No `char` may be constructed, whether as a literal or at runtime, that is not a Unicode scalar value: <br>无论是作为字面量还是在运行时，都不能构造不是 Unicode 标量值的 `char`:<br>
///
/// ```compile_fail
/// // Each of these is a compiler error <br>这些都是编译器错误<br>
/// ['\u{D800}', '\u{DFFF}', '\u{110000}'];
/// ```
///
/// ```should_panic
/// // Panics; from_u32 returns None. <br>Panics; from_u32 返回 None。<br>
/// char::from_u32(0xDE01).unwrap();
/// ```
///
/// ```no_run
/// // Undefined behaviour <br>未定义的行为<br>
/// unsafe { char::from_u32_unchecked(0x110000) };
/// ```
///
/// USVs are also the exact set of values that may be encoded in UTF-8. <br>USV 也是可以在 UTF-8 中编码的精确值集。<br>
/// Because `char` values are USVs and `str` values are valid UTF-8, it is safe to store any `char` in a `str` or read any character from a `str` as a `char`. <br>因为 `char` 值是 USV 而 `str` 值是有效的 UTF-8，所以将任何 `char` 存储在 `str` 中或从 `str` 读取任何字符作为 `char` 是安全的。<br>
///
/// The gap in valid `char` values is understood by the compiler, so in the below example the two ranges are understood to cover the whole range of possible `char` values and there is no error for a [non-exhaustive match]. <br>编译器可以理解有效 `char` 值的差距，因此在下面的示例中，这两个范围被理解为涵盖了可能的 `char` 值的整个范围，并且 [非穷举匹配][non-exhaustive match] 没有错误。<br>
///
///
/// ```
/// let c: char = 'a';
/// match c {
///     '\0' ..= '\u{D7FF}' => false,
///     '\u{E000}' ..= '\u{10FFFF}' => true,
/// };
/// ```
///
/// All USVs are valid `char` values, but not all of them represent a real character. <br>所有的 USV 都是有效的 `char` 值，但并不是所有的都代表一个真实的字符。<br>
/// Many USVs are not currently assigned to a character, but may be in the future ("reserved"); <br>许多 USV 目前没有分配给一个字符，但将来可能会被分配 ("保留");<br> some will never be a character ("noncharacters"); <br>有些永远不会是字符 ("非字符");<br> and some may be given different meanings by different users ("private use"). <br>并且有些可能被不同的用户赋予不同的含义 ("私有使用")。<br>
///
/// [Unicode code point]: https://www.unicode.org/glossary/#code_point
/// [Unicode scalar value]: https://www.unicode.org/glossary/#unicode_scalar_value
/// [non-exhaustive match]: ../book/ch06-02-match.html#matches-are-exhaustive
/// [surrogate code point]: https://www.unicode.org/glossary/#surrogate_code_point
///
/// # Representation
///
/// `char` is always four bytes in size. <br>`char` 的大小始终为四个字节。<br> This is a different representation than a given character would have as part of a [`String`]. <br>这与给定字符作为 [`String`] 的一部分的表示形式不同。<br> For example: <br>例如：<br>
///
/// ```
/// let v = vec!['h', 'e', 'l', 'l', 'o'];
///
/// // five elements times four bytes for each element <br>五个元素乘以每个元素四个字节<br>
/// assert_eq!(20, v.len() * std::mem::size_of::<char>());
///
/// let s = String::from("hello");
///
/// // five elements times one byte per element <br>5 个元素乘以每个元素一个字节<br>
/// assert_eq!(5, s.len() * std::mem::size_of::<u8>());
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`String`]: ", include_str!("../primitive_docs/string_string.md"))]
/// As always, remember that a human intuition for 'character' might not map to Unicode's definitions. <br>与往常一样，请记住，人类对 'character' 的直觉可能不是 map 到 Unicode 的定义。<br>
/// For example, despite looking similar, the 'é' character is one Unicode code point while 'é' is two Unicode code points: <br>例如，尽管看起来相似，但 'é' 字符是一个 Unicode 代码点，而 'é' 是两个 Unicode 代码点：<br>
///
/// ```
/// let mut chars = "é".chars();
/// // U+00e9: 'latin small letter e with acute' <br>U+00e9: '带锐音符的拉丁小写字母 e'<br>
/// assert_eq!(Some('\u{00e9}'), chars.next());
/// assert_eq!(None, chars.next());
///
/// let mut chars = "é".chars();
/// // U+0065: 'latin small letter e' <br>U+0065: ' 拉丁小写字母 e'<br>
/// assert_eq!(Some('\u{0065}'), chars.next());
/// // U+0301: 'combining acute accent' <br>U+0301: '结合重音'<br>
/// assert_eq!(Some('\u{0301}'), chars.next());
/// assert_eq!(None, chars.next());
/// ```
///
/// This means that the contents of the first string above _will_ fit into a `char` while the contents of the second string _will not_. <br>这意味着 _will_ 上方的第一个字符串的内容适合 `char`，而第二个字符串 _will_ 的内容则不会。<br>
///
/// Trying to create a `char` literal with the contents of the second string gives an error: <br>尝试使用第二个字符串的内容创建 `char` 字面量会产生错误：<br>
///
/// ```text
/// error: character literal may only contain one codepoint: 'é'
/// let c = 'é';
///         ^^^
/// ```
///
/// Another implication of the 4-byte fixed size of a `char` is that per-`char` processing can end up using a lot more memory: <br>`char` 的 4 字节固定大小的另一个含义是，每个字符处理可能最终会使用更多的内存：<br>
///
/// ```
/// let s = String::from("love: ❤️");
/// let v: Vec<char> = s.chars().collect();
///
/// assert_eq!(12, std::mem::size_of_val(&s[..]));
/// assert_eq!(32, std::mem::size_of_val(&v[..]));
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_char {}

#[doc(primitive = "unit")]
#[doc(alias = "(")]
#[doc(alias = ")")]
#[doc(alias = "()")]
//
/// The `()` type, also called "unit". <br>`()` 类型，也称为 "unit"。<br>
///
/// The `()` type has exactly one value `()`, and is used when there is no other meaningful value that could be returned. <br>`()` 类型只有一个值 `()`，在没有其他有意义的值可以返回时使用。<br>
/// `()` is most commonly seen implicitly: functions without a `-> ...` implicitly have return type `()`, that is, these are equivalent: <br>`()` 最常见的是隐式的：没有 `-> ...` 的函数隐式具有返回类型 `()`，也就是说，它们是等价的：<br>
///
/// ```rust
/// fn long() -> () {}
///
/// fn short() {}
/// ```
///
/// The semicolon `;` can be used to discard the result of an expression at the end of a block, making the expression (and thus the block) evaluate to `()`. <br>分号 `;` 可用于在块末尾丢弃表达式的结果，从而使表达式 (从而使该块) 的值为 `()`。<br>
///
/// For example, <br>例如，<br>
///
/// ```rust
/// fn returns_i64() -> i64 {
///     1i64
/// }
/// fn returns_unit() {
///     1i64;
/// }
///
/// let is_i64 = {
///     returns_i64()
/// };
/// let is_unit = {
///     returns_i64();
/// };
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_unit {}

// Required to make auto trait impls render. <br>需要进行自动 trait impls 渲染。<br>
// See src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls <br>请参见 src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls<br>
#[doc(hidden)]
impl () {}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for () {
    fn clone(&self) -> Self {
        loop {}
    }
}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
impl Copy for () {
    // empty
}

#[doc(primitive = "pointer")]
#[doc(alias = "ptr")]
#[doc(alias = "*")]
#[doc(alias = "*const")]
#[doc(alias = "*mut")]
//
/// Raw, unsafe pointers, `*const T`, and `*mut T`. <br>原始的、不安全的指针 `*const T` 和 `*mut T`。<br>
///
/// *[See also the `std::ptr` module](ptr).*
///
/// Working with raw pointers in Rust is uncommon, typically limited to a few patterns. <br>在 Rust 中使用裸指针并不常见，通常仅限于几种模式。<br>
/// Raw pointers can be unaligned or [`null`]. <br>裸指针可以是未对齐的或 [`null`]。<br> However, when a raw pointer is dereferenced (using the `*` operator), it must be non-null and aligned. <br>但是，当解引用裸指针 (使用 `*` 运算符) 时，它必须为非 null 并对齐。<br>
///
/// Storing through a raw pointer using `*ptr = data` calls `drop` on the old value, so [`write`] must be used if the type has drop glue and memory is not already initialized - otherwise `drop` would be called on the uninitialized memory. <br>使用 `*ptr = data` 通过裸指针存储会在旧值上调用 `drop`，因此，如果该类型具有 drop glue 并且尚未初始化内存，则必须使用 [`write`]; 否则，将在未初始化的内存上调用 `drop`。<br>
///
///
/// Use the [`null`] and [`null_mut`] functions to create null pointers, and the [`is_null`] method of the `*const T` and `*mut T` types to check for null. <br>使用 [`null`] 和 [`null_mut`] 函数创建空指针，并使用 `*const T` 和 `*mut T` 类型的 [`is_null`] 方法检查空值。<br>
/// The `*const T` and `*mut T` types also define the [`offset`] method, for pointer math. <br>`*const T` 和 `*mut T` 类型还定义了用于指针数学的 [`offset`] 方法。<br>
///
/// # Common ways to create raw pointers <br>创建裸指针的常用方法<br>
///
/// ## 1. Coerce a reference (`&T`) or mutable reference (`&mut T`). <br>强制引用 (`&T`) 或可变引用 (`&mut T`)。<br>
///
/// ```
/// let my_num: i32 = 10;
/// let my_num_ptr: *const i32 = &my_num;
/// let mut my_speed: i32 = 88;
/// let my_speed_ptr: *mut i32 = &mut my_speed;
/// ```
///
/// To get a pointer to a boxed value, dereference the box: <br>要获得指向 boxed 值的指针，请解引用 box：<br>
///
/// ```
/// let my_num: Box<i32> = Box::new(10);
/// let my_num_ptr: *const i32 = &*my_num;
/// let mut my_speed: Box<i32> = Box::new(88);
/// let my_speed_ptr: *mut i32 = &mut *my_speed;
/// ```
///
/// This does not take ownership of the original allocation and requires no resource management later, but you must not use the pointer after its lifetime. <br>这不会获得原始分配的所有权，并且以后不需要任何资源管理，但是您一定不能在其生命周期之后使用该指针。<br>
///
/// ## 2. Consume a box (`Box<T>`). <br>消费 box (`Box<T>`)。<br>
///
/// The [`into_raw`] function consumes a box and returns the raw pointer. <br>[`into_raw`] 函数消费 box 并返回裸指针。<br> It doesn't destroy `T` or deallocate any memory. <br>它不会销毁 `T` 或释放任何内存。<br>
///
/// ```
/// let my_speed: Box<i32> = Box::new(88);
/// let my_speed: *mut i32 = Box::into_raw(my_speed);
///
/// // By taking ownership of the original `Box<T>` though we are obligated to put it together later to be destroyed. <br>通过拥有原始 `Box<T>` 的所有权，我们有义务稍后将其放在一起销毁。<br>
/////
/// unsafe {
///     drop(Box::from_raw(my_speed));
/// }
/// ```
///
/// Note that here the call to [`drop`] is for clarity - it indicates that we are done with the given value and it should be destroyed. <br>请注意，此处对 [`drop`] 的调用是为了清楚起见 - 表示我们已经完成了给定值的操作，应将其销毁。<br>
///
/// ## 3. Create it using `ptr::addr_of!` <br>使用 `ptr::addr_of!` 创建它<br>
///
/// Instead of coercing a reference to a raw pointer, you can use the macros [`ptr::addr_of!`] (for `*const T`) and [`ptr::addr_of_mut!`] (for `*mut T`). <br>您可以使用宏 [`ptr::addr_of!`] (对于 `*const T`) 和 [`ptr::addr_of_mut!`] (对于 `*mut T`)，而不是强制引用裸指针。<br>
/// These macros allow you to create raw pointers to fields to which you cannot create a reference (without causing undefined behaviour), such as an unaligned field. <br>这些宏允许您创建裸指针指向您无法创建引用的字段 (不会导致未定义的行为)，例如未对齐的字段。<br>
/// This might be necessary if packed structs or uninitialized memory is involved. <br>如果涉及包装的结构或未初始化的内存，这可能是必要的。<br>
///
/// ```
/// #[derive(Debug, Default, Copy, Clone)]
/// #[repr(C, packed)]
/// struct S {
///     aligned: u8,
///     unaligned: u32,
/// }
/// let s = S::default();
/// let p = std::ptr::addr_of!(s.unaligned); // not allowed with coercion <br>不允许强制转换<br>
/// ```
///
/// ## 4. Get it from C. <br>从 C 获取它。<br>
///
/// ```
/// # #![feature(rustc_private)]
/// extern crate libc;
///
/// use std::mem;
///
/// unsafe {
///     let my_num: *mut i32 = libc::malloc(mem::size_of::<i32>()) as *mut i32;
///     if my_num.is_null() {
///         panic!("failed to allocate memory");
///     }
///     libc::free(my_num as *mut libc::c_void);
/// }
/// ```
///
/// Usually you wouldn't literally use `malloc` and `free` from Rust, but C APIs hand out a lot of pointers generally, so are a common source of raw pointers in Rust. <br>通常，您实际上不会使用 Rust 中的 `malloc` 和 `free`，但是 C API 通常会发出很多指针，因此 Rust 中的裸指针常见来源。<br>
///
/// [`null`]: ptr::null
/// [`null_mut`]: ptr::null_mut
/// [`is_null`]: pointer::is_null
/// [`offset`]: pointer::offset
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`into_raw`]: ", include_str!("../primitive_docs/box_into_raw.md"))]
/// [`drop`]: mem::drop
/// [`write`]: ptr::write
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_pointer {}

#[doc(primitive = "array")]
#[doc(alias = "[]")]
#[doc(alias = "[T;N]")] // unfortunately, rustdoc doesn't have fuzzy search for aliases <br>不幸的是，rustdoc 没有对别名的模糊搜索<br>
#[doc(alias = "[T; N]")]
/// A fixed-size array, denoted `[T; N]`, for the element type, `T`, and the non-negative compile-time constant size, `N`. <br>一个固定大小的数组，表示为 `[T; N]`，用于元素类型 `T` 和非负编译时常量大小 `N`。<br>
///
/// There are two syntactic forms for creating an array: <br>创建数组有两种语法形式：<br>
///
/// * A list with each element, i.e., `[x, y, z]`. <br>包含每个元素的列表，即 `[x, y, z]`。<br>
/// * A repeat expression `[x; N]`, which produces an array with `N` copies of `x`. <br>重复表达式 `[x; N]`，该数组生成包含 `x` 的 `N` 副本的数组。<br>
///   The type of `x` must be [`Copy`]. <br>`x` 的类型必须为 [`Copy`]。<br>
///
/// Note that `[expr; 0]` is allowed, and produces an empty array. <br>请注意，`[expr; 0]` 是允许的，并产生一个空数组。<br>
/// This will still evaluate `expr`, however, and immediately drop the resulting value, so be mindful of side effects. <br>然而，这仍然会计算 `expr`，并立即丢弃结果值，因此请注意副作用。<br>
///
/// Arrays of *any* size implement the following traits if the element type allows it: <br>如果元素类型允许，则任何大小的数组都将实现以下 traits：<br>
///
/// - [`Copy`]
/// - [`Clone`]
/// - [`Debug`]
/// - [`IntoIterator`] (implemented for `[T; N]`, `&[T; N]` and `&mut [T; N]`) <br>[`IntoIterator`] (为 `[T; N]`、`&[T; N]` 和 `&mut [T; N]` 实现)<br>
/// - [`PartialEq`], [`PartialOrd`], [`Eq`], [`Ord`]
/// - [`Hash`]
/// - [`AsRef`], [`AsMut`]
/// - [`Borrow`], [`BorrowMut`]
///
/// Arrays of sizes from 0 to 32 (inclusive) implement the [`Default`] trait if the element type allows it. <br>如果元素类型允许，则大小为 0 到 32 (inclusive) 的数组将实现 [`Default`] trait。<br>
/// As a stopgap, trait implementations are statically generated up to size 32. <br>作为权宜之计，trait 实现是静态生成的，最大大小为 32。<br>
///
/// Arrays coerce to [slices (`[T]`)][slice], so a slice method may be called on an array. <br>数组强制转换为 [slices (`[T]`) ][slice]，因此可以在数组上调用 slice 方法。<br> Indeed, this provides most of the API for working with arrays. <br>实际上，这提供了用于处理数组的大多数 API。<br>
/// Slices have a dynamic size and do not coerce to arrays. <br>切片具有动态大小，并且不强制转换为数组。<br>
///
/// You can move elements out of an array with a [slice pattern]. <br>您可以使用 [切片模式][slice pattern] 将元素移出数组。<br> If you want one element, see [`mem::replace`]. <br>如果需要一个元素，请参见 [`mem::replace`]。<br>
///
/// # Examples
///
/// ```
/// let mut array: [i32; 3] = [0; 3];
///
/// array[1] = 1;
/// array[2] = 2;
///
/// assert_eq!([1, 2], &array[1..]);
///
/// // This loop prints: 0 1 2 <br>该循环打印: 0 1 2<br>
/// for x in array {
///     print!("{x} ");
/// }
/// ```
///
/// You can also iterate over reference to the array's elements: <br>您还可以迭代数组元素的引用：<br>
///
/// ```
/// let array: [i32; 3] = [0; 3];
///
/// for x in &array { }
/// ```
///
/// You can use a [slice pattern] to move elements out of an array: <br>您可以使用 [切片模式][slice pattern] 将元素移出数组：<br>
///
/// ```
/// fn move_away(_: String) { /* Do interesting things. */ }
///
/// let [john, roa] = ["John".to_string(), "Roa".to_string()];
/// move_away(john);
/// move_away(roa);
/// ```
///
/// # Editions
///
/// Prior to Rust 1.53, arrays did not implement [`IntoIterator`] by value, so the method call `array.into_iter()` auto-referenced into a [slice iterator](slice::iter). <br>在 Rust 1.53 之前，数组没有按值实现 [`IntoIterator`]，因此调用 `array.into_iter()` 方法自动引用到 [slice 迭代器](slice::iter)。<br>
/// Right now, the old behavior is preserved in the 2015 and 2018 editions of Rust for compatibility, ignoring [`IntoIterator`] by value. <br>目前，为了兼容性，Rust 的 2015 和 2018 版本中保留了旧行为，忽略了 [`IntoIterator`] 的值。<br>
/// In the future, the behavior on the 2015 and 2018 edition might be made consistent to the behavior of later editions. <br>将来，2015 年和 2018 年版本的行为可能会与以后版本的行为一致。<br>
///
/// ```rust,edition2018
/// // Rust 2015 and 2018: <br>Rust 2015 和 2018：<br>
///
/// # #![allow(array_into_iter)] // override our `deny(warnings)` <br>覆盖我们的 `deny(warnings)`<br>
/// let array: [i32; 3] = [0; 3];
///
/// // This creates a slice iterator, producing references to each value. <br>这将创建一个切片迭代器，产生对每个值的引用。<br>
/// for item in array.into_iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // The `array_into_iter` lint suggests this change for future compatibility: <br>`array_into_iter` lint 建议进行此更改以实现未来兼容性：<br>
/// for item in array.iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // You can explicitly iterate an array by value using `IntoIterator::into_iter` <br>您可以使用 `IntoIterator::into_iter` 按值显式迭代数组<br>
/// for item in IntoIterator::into_iter(array).enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// Starting in the 2021 edition, `array.into_iter()` uses `IntoIterator` normally to iterate by value, and `iter()` should be used to iterate by reference like previous editions. <br>从 2021 版开始，`array.into_iter()` 通常使用 `IntoIterator` 进行值迭代，而应该像以前的版本一样使用 `iter()` 进行引用迭代。<br>
///
///
/// ```rust,edition2021
/// // Rust 2021:
///
/// let array: [i32; 3] = [0; 3];
///
/// // This iterates by reference: <br>这通过引用进行迭代：<br>
/// for item in array.iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // This iterates by value: <br>这是按值迭代的：<br>
/// for item in array.into_iter().enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// Future language versions might start treating the `array.into_iter()` syntax on editions 2015 and 2018 the same as on edition 2021. <br>未来的语言版本可能会开始将 2015 和 2018 版的 `array.into_iter()` 语法与 2021 版相同。<br>
/// So code using those older editions should still be written with this change in mind, to prevent breakage in the future. <br>因此，在编写使用这些旧版本的代码时仍应牢记这一更改，以防止将来出现破坏。<br>
/// The safest way to accomplish this is to avoid the `into_iter` syntax on those editions. <br>实现这一点最安全的方法是避免这些版本中的 `into_iter` 语法。<br>
/// If an edition update is not viable/desired, there are multiple alternatives: <br>如果版本更新不是不可行/不受欢迎的，则有多种选择：<br>
/// * use `iter`, equivalent to the old behavior, creating references <br>使用 `iter`，相当于旧行为，创建引用<br>
/// * use [`IntoIterator::into_iter`], equivalent to the post-2021 behavior (Rust 1.53+) <br>使用 [`IntoIterator::into_iter`]，相当于 2021 年后的行为 (Rust 1.53+)<br>
/// * replace `for ... <br>替换 `for ....<br>
/// in array.into_iter() {` with `for ... <br>in array.into_iter() {` 和 `for ...<br>
/// in array {`, equivalent to the post-2021 behavior (Rust 1.53+) <br>in array {`，相当于 2021 年后的行为 (Rust 1.53+)<br>
///
/// ```rust,edition2018
/// // Rust 2015 and 2018: <br>Rust 2015 和 2018：<br>
///
/// let array: [i32; 3] = [0; 3];
///
/// // This iterates by reference: <br>这通过引用进行迭代：<br>
/// for item in array.iter() {
///     let x: &i32 = item;
///     println!("{x}");
/// }
///
/// // This iterates by value: <br>这是按值迭代的：<br>
/// for item in IntoIterator::into_iter(array) {
///     let x: i32 = item;
///     println!("{x}");
/// }
///
/// // This iterates by value: <br>这是按值迭代的：<br>
/// for item in array {
///     let x: i32 = item;
///     println!("{x}");
/// }
///
/// // IntoIter can also start a chain. <br>IntoIter 也可以启动一个链。<br>
/// // This iterates by value: <br>这是按值迭代的：<br>
/// for item in IntoIterator::into_iter(array).enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// [slice]: prim@slice
/// [`Debug`]: fmt::Debug
/// [`Hash`]: hash::Hash
/// [`Borrow`]: borrow::Borrow
/// [`BorrowMut`]: borrow::BorrowMut
/// [slice pattern]: ../reference/patterns.html#slice-patterns
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_array {}

#[doc(primitive = "slice")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
/// A dynamically-sized view into a contiguous sequence, `[T]`. <br>一个动态大小的视图到一个连续的序列，`[T]`。<br>
/// Contiguous here means that elements are laid out so that every element is the same distance from its neighbors. <br>这里的连续意味着元素的布局应使每个元素与其相邻元素之间的距离相同。<br>
///
/// *[See also the `std::slice` module](crate::slice).*
///
/// Slices are a view into a block of memory represented as a pointer and a length. <br>切片是一个内存块的视图，表示为一个指针和一个长度。<br>
///
/// ```
/// // slicing a Vec <br>切片 Vec<br>
/// let vec = vec![1, 2, 3];
/// let int_slice = &vec[..];
/// // coercing an array to a slice <br>将数组强制转换为切片<br>
/// let str_slice: &[&str] = &["one", "two", "three"];
/// ```
///
/// Slices are either mutable or shared. <br>切片是可变的或共享的。<br>
/// The shared slice type is `&[T]`, while the mutable slice type is `&mut [T]`, where `T` represents the element type. <br>共享切片类型为 `&[T]`，而可变切片类型为 `&mut [T]`，其中 `T` 表示元素类型。<br>
/// For example, you can mutate the block of memory that a mutable slice points to: <br>例如，您可以更改可变切片所指向的内存块：<br>
///
/// ```
/// let mut x = [1, 2, 3];
/// let x = &mut x[..]; // Take a full slice of `x`. <br>取 `x` 的完整切片。<br>
/// x[1] = 7;
/// assert_eq!(x, &[1, 7, 3]);
/// ```
///
/// As slices store the length of the sequence they refer to, they have twice the size of pointers to [`Sized`](marker/trait.Sized.html) types. <br>当切片存储所引用序列的长度时，它们的指针大小是 [`Sized`](marker/trait.Sized.html) 类型的两倍。<br>
///
/// Also see the reference on [dynamically sized types](../reference/dynamically-sized-types.html). <br>另请参见 [动态大小的类型](../reference/dynamically-sized-types.html) 上的引用。<br>
///
/// ```
/// # use std::rc::Rc;
/// let pointer_size = std::mem::size_of::<&u8>();
/// assert_eq!(2 * pointer_size, std::mem::size_of::<&[u8]>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<*const [u8]>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<Box<[u8]>>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<Rc<[u8]>>());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_slice {}

#[doc(primitive = "str")]
//
/// String slices. <br>字符串切片。<br>
///
/// *[See also the `std::str` module](crate::str).*
///
/// The `str` type, also called a 'string slice', is the most primitive string type. <br>`str` 类型，也称为字符串切片，是最原始的字符串类型。<br>
/// It is usually seen in its borrowed form, `&str`. <br>它通常以其借用形式 `&str` 出现。<br>
/// It is also the type of string literals, `&'static str`. <br>也是字符串字面量的类型，`&'static str`。<br>
///
/// String slices are always valid UTF-8. <br>字符串切片始终是有效的 UTF-8。<br>
///
/// # Examples
///
/// String literals are string slices: <br>字符串字面量是字符串切片：<br>
///
/// ```
/// let hello = "Hello, world!";
///
/// // with an explicit type annotation <br>带有明确的类型注解<br>
/// let hello: &'static str = "Hello, world!";
/// ```
///
/// They are `'static` because they're stored directly in the final binary, and so will be valid for the `'static` duration. <br>它们是 `'static`，因为它们直接存储在最终二进制文件中，因此在 `'static` 持续时间内有效。<br>
///
///
/// # Representation
///
/// A `&str` is made up of two components: a pointer to some bytes, and a length. <br>`&str` 由两个部分组成：一个指向某些字节的指针和一个长度。<br>
/// You can look at these with the [`as_ptr`] and [`len`] methods: <br>您可以使用 [`as_ptr`] 和 [`len`] 方法查看它们：<br>
///
/// ```
/// use std::slice;
/// use std::str;
///
/// let story = "Once upon a time...";
///
/// let ptr = story.as_ptr();
/// let len = story.len();
///
/// // story has nineteen bytes <br>story 有十九个字节<br>
/// assert_eq!(19, len);
///
/// // We can re-build a str out of ptr and len. <br>我们可以根据 ptr 和 len 重新构建一个 str。<br>
/// // This is all unsafe because we are responsible for making sure the two components are valid: <br>这都是不安全的，因为我们有责任确保两个组件均有效：<br>
/// let s = unsafe {
///     // First, we build a &[u8]... <br>首先，我们建立一个 &[u8] ...<br>
///     let slice = slice::from_raw_parts(ptr, len);
///
///     // ... and then convert that slice into a string slice <br>然后将该切片转换为字符串<br>
///     str::from_utf8(slice)
/// };
///
/// assert_eq!(s, Ok(story));
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: str::len
///
/// Note: This example shows the internals of `&str`. <br>本示例显示了 `&str` 的内部结构。<br>
/// `unsafe` should not be used to get a string slice under normal circumstances. <br>在正常情况下，不应使用 `unsafe` 来获取字符串切片。<br>
/// Use `as_str` instead. <br>请改用 `as_str`。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_str {}

#[doc(primitive = "tuple")]
#[doc(alias = "(")]
#[doc(alias = ")")]
#[doc(alias = "()")]
//
/// A finite heterogeneous sequence, `(T, U, ..)`. <br>一个有限异构序列，`(T, U, ..)`。<br>
///
/// Let's cover each of those in turn: <br>让我们依次介绍其中的每一个：<br>
///
/// Tuples are *finite*. <br>元组是有限的。<br> In other words, a tuple has a length. <br>换句话说，元组具有长度。<br> Here's a tuple of length `3`: <br>这是长度为 `3` 的元组：<br>
///
/// ```
/// ("hello", 5, 'c');
/// ```
///
/// 'Length' is also sometimes called 'arity' here; <br>'Length' 有时也称为 'arity'；<br> each tuple of a different length is a different, distinct type. <br>每个不同长度的元组都是不同的，不同的类型。<br>
///
/// Tuples are *heterogeneous*. <br>元组是异构的。<br> This means that each element of the tuple can have a different type. <br>这意味着元组的每个元素可以具有不同的类型。<br>
/// In that tuple above, it has the type: <br>在上面的元组中，其类型为：<br>
///
/// ```
/// # let _:
/// (&'static str, i32, char)
/// # = ("hello", 5, 'c');
/// ```
///
/// Tuples are a *sequence*. <br>元组是一个序列。<br> This means that they can be accessed by position; <br>这意味着可以按位置访问它们；<br>
/// this is called 'tuple indexing', and it looks like this: <br>这称为元组索引，它看起来像这样：<br>
///
/// ```rust
/// let tuple = ("hello", 5, 'c');
///
/// assert_eq!(tuple.0, "hello");
/// assert_eq!(tuple.1, 5);
/// assert_eq!(tuple.2, 'c');
/// ```
///
/// The sequential nature of the tuple applies to its implementations of various traits. <br>元组的顺序性质适用于各种 traits 的实现。<br>
/// For example, in [`PartialOrd`] and [`Ord`], the elements are compared sequentially until the first non-equal set is found. <br>例如，在 [`PartialOrd`] 和 [`Ord`] 中，元素按顺序进行比较，直到找到第一个不相等的集合。<br>
///
///
/// For more about tuples, see [the book](../book/ch03-02-data-types.html#the-tuple-type). <br>有关元组的更多信息，请参见 [这本书](../book/ch03-02-data-types.html#the-tuple-type)。<br>
///
///
///
// Hardcoded anchor in src/librustdoc/html/format.rs linked to as `#trait-implementations-1` <br>src/librustdoc/html/format.rs 中的硬编码锚链接到 `#trait-implementations-1`<br>
//
/// # Trait implementations <br>trait 实现<br>
///
/// In this documentation the shorthand `(T₁, T₂, …, Tₙ)` is used to represent tuples of varying length. <br>在本文档中，简写 `(T₁, T₂,…, Tₙ)` 用于表示不同长度的元组。<br>
/// When that is used, any trait bound expressed on `T` applies to each element of the tuple independently. <br>当使用它时，在 `T` 上表达的任何 trait bound 都独立地应用于元组的每个元素。<br>
/// Note that this is a convenience notation to avoid repetitive documentation, not valid Rust syntax. <br>请注意，这是一种方便的符号，以避免重复文档，不是有效的 Rust 语法。<br>
///
/// Due to a temporary restriction in Rust’s type system, the following traits are only implemented on tuples of arity 12 or less. <br>由于 Rust 的类型系统的临时限制，以下 traits 仅在 arity 12 或更少的元组上实现。<br>
/// In the future, this may change: <br>在未来，这可能会改变:<br>
///
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`Debug`]
/// * [`Default`]
/// * [`Hash`]
///
/// [`Debug`]: fmt::Debug
/// [`Hash`]: hash::Hash
///
/// The following traits are implemented for tuples of any length. <br>以下 traits 用于任意长度的元组。<br>
/// These traits have implementations that are automatically generated by the compiler, so are not limited by missing language features. <br>这些 traits 具有由编译器自动生成的实现，因此不受缺少语言，特性，的限制。<br>
///
///
/// * [`Clone`]
/// * [`Copy`]
/// * [`Send`]
/// * [`Sync`]
/// * [`Unpin`]
/// * [`UnwindSafe`]
/// * [`RefUnwindSafe`]
///
/// [`Unpin`]: marker::Unpin
/// [`UnwindSafe`]: panic::UnwindSafe
/// [`RefUnwindSafe`]: panic::RefUnwindSafe
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let tuple = ("hello", 5, 'c');
///
/// assert_eq!(tuple.0, "hello");
/// ```
///
/// Tuples are often used as a return type when you want to return more than one value: <br>当您要返回多个值时，通常将元组用作返回类型：<br>
///
/// ```
/// fn calculate_point() -> (i32, i32) {
///     // Don't do a calculation, that's not the point of the example <br>不要进行计算，这不是示例的重点<br>
///     (4, 5)
/// }
///
/// let point = calculate_point();
///
/// assert_eq!(point.0, 4);
/// assert_eq!(point.1, 5);
///
/// // Combining this with patterns can be nicer. <br>将此与模式结合起来会更好。<br>
///
/// let (x, y) = calculate_point();
///
/// assert_eq!(x, 4);
/// assert_eq!(y, 5);
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_tuple {}

// Required to make auto trait impls render. <br>需要进行自动 trait impls 渲染。<br>
// See src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls <br>请参见 src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls<br>
#[doc(hidden)]
impl<T> (T,) {}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(fake_variadic))]
/// This trait is implemented on arbitrary-length tuples. <br>这个 trait 在任意长度的元组上实现。<br>
impl<T: Clone> Clone for (T,) {
    fn clone(&self) -> Self {
        loop {}
    }
}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(fake_variadic))]
/// This trait is implemented on arbitrary-length tuples. <br>这个 trait 在任意长度的元组上实现。<br>
impl<T: Copy> Copy for (T,) {
    // empty
}

#[doc(primitive = "f32")]
/// A 32-bit floating point type (specifically, the "binary32" type defined in IEEE 754-2008). <br>32 位浮点类型 (特别是 IEEE 754-2008 中定义的 "binary32" 类型)。<br>
///
/// This type can represent a wide range of decimal numbers, like `3.5`, `27`, `-113.75`, `0.0078125`, `34359738368`, `0`, `-1`. <br>此类型可以表示各种十进制数字，例如 `3.5`，`27`，`-113.75`，`0.0078125`，`34359738368`，`0`，`-1`。<br> So unlike integer types (such as `i32`), floating point types can represent non-integer numbers, too. <br>因此，与整数类型 (例如 `i32`) 不同，浮点类型也可以表示非整数。<br>
///
/// However, being able to represent this wide range of numbers comes at the cost of precision: floats can only represent some of the real numbers and calculation with floats round to a nearby representable number. <br>但是，能够表示这么广泛的数字是以牺牲精度为代价的：浮点数只能表示某些实数，并且计算时会将浮点数舍入到附近的可表示数字。<br>
/// For example, `5.0` and `1.0` can be exactly represented as `f32`, but `1.0 / 5.0` results in `0.20000000298023223876953125` since `0.2` cannot be exactly represented as `f32`. <br>例如，`5.0` 和 `1.0` 可以精确地表示为 `f32`，但是 `1.0 / 5.0` 会导致 `0.20000000298023223876953125`，因为 `0.2` 不能精确地表示为 `f32`。<br> Note, however, that printing floats with `println` and friends will often discard insignificant digits: `println!("{}", 1.0f32 / 5.0f32)` will print `0.2`. <br>但是请注意，带有 `println` 的浮动彩信和朋友经常会丢弃无关紧要的数字: `println!("{}", 1.0f32 / 5.0f32)` 会打印 `0.2`。<br>
///
/// Additionally, `f32` can represent some special values: <br>此外，`f32` 可以表示一些特殊值：<br>
///
/// - −0.0: IEEE 754 floating point numbers have a bit that indicates their sign, so −0.0 is a possible value. <br>-0.0: IEEE 754 浮点数有一个表示它们的符号的位，所以 `-0.0` 是一个可能的值。<br> For comparison −0.0 = +0.0, but floating point operations can carry the sign bit through arithmetic operations. <br>对于比较 `-0.0 = +0.0`，但浮点运算可以通过算术运算携带符号位。<br>
/// This means −0.0 × +0.0 produces −0.0 and a negative number rounded to a value smaller than a float can represent also produces −0.0. <br>这意味着 `-0.0 × +0.0` 产生 `-0.0`，四舍五入到小于浮点值的负数也产生 `-0.0`。<br>
/// - [∞](#associatedconstant.INFINITY) and [−∞](#associatedconstant.NEG_INFINITY): these result from calculations like `1.0 / 0.0`. <br>[∞](#associatedconstant.INFINITY) 和 [−∞](#associatedconstant.NEG_INFINITY): 这些是由 `1.0 / 0.0` 等计算得出的。<br>
/// - [NaN (not a number)](#associatedconstant.NAN): this value results from calculations like `(-1.0).sqrt()`. <br>[NaN (不是一个数字)](#associatedconstant.NAN): 此值由 `(-1.0).sqrt()` 等计算得出。<br> NaN has some potentially unexpected behavior: <br>NaN 有一些潜在的意外行为:<br>
///   - It is unequal to any float, including itself! <br>它不等于任何浮点数，包括它自己!<br> This is the reason `f32` doesn't implement the `Eq` trait. <br>这就是 `f32` 没有实现 `Eq` trait 的原因。<br>
///   - It is also neither smaller nor greater than any float, making it impossible to sort by the default comparison operation, which is the reason `f32` doesn't implement the `Ord` trait. <br>它既不小于也不大于任何浮点数，因此无法通过默认比较操作进行排序，这就是 `f32` 没有实现 `Ord` trait 的原因。<br>
///   - It is also considered *infectious* as almost all calculations where one of the operands is NaN will also result in NaN. <br>它也被认为是*传染的*，因为几乎所有操作数之一为 NaN 的计算也会导致 NaN。<br> The explanations on this page only explicitly document behavior on NaN operands if this default is deviated from. <br>如果此默认值偏离，此页面上的说明仅明确记录 NaN 操作数的行为。<br>
///   - Lastly, there are multiple bit patterns that are considered NaN. <br>最后，有多个位模式被认为是 NaN。<br>
///     Rust does not currently guarantee that the bit patterns of NaN are preserved over arithmetic operations, and they are not guaranteed to be portable or even fully deterministic! <br>Rust 目前不保证 NaN 的位模式在算术运算中得到保留，也不保证它们是可移植的，甚至是完全确定的!<br> This means that there may be some surprising results upon inspecting the bit patterns, as the same calculations might produce NaNs with different bit patterns. <br>这意味着在检查位模式时可能会有一些令人惊讶的结果，因为相同的计算可能会产生具有不同位模式的 NaN。<br>
///
///
/// When the number resulting from a primitive operation (addition, subtraction, multiplication, or division) on this type is not exactly representable as `f32`, it is rounded according to the roundTiesToEven direction defined in IEEE 754-2008. <br>当此类型的原始操作 (加法、减法、乘法或除法) 产生的数字不能完全表示为 `f32` 时，它会根据 IEEE 754-2008 中定义的 roundTiesToEven 方向进行四舍五入。<br> That means: <br>这意味着:<br>
///
/// - The result is the representable value closest to the true value, if there is a unique closest representable value. <br>如果存在唯一的最接近的可表示值，则结果是最接近真实值的可表示值。<br>
/// - If the true value is exactly half-way between two representable values, the result is the one with an even least-significant binary digit. <br>如果真值恰好在两个可表示值的中间，则结果是具有偶数最低有效二进制数字的结果。<br>
/// - If the true value's magnitude is ≥ `f32::MAX` + 2<sup>(`f32::MAX_EXP` − `f32::MANTISSA_DIGITS` − 1)</sup>, the result is ∞ or −∞ (preserving the true value's sign). <br>如果真值的大小 ≥ `f32::MAX` + 2 <sup>(`f32::MAX_EXP`-`f32::MANTISSA_DIGITS`-1)</sup>，则结果为 ∞ 或 -∞ (保留真值的符号)。<br>
///
/// For more information on floating point numbers, see [Wikipedia][wikipedia]. <br>有关浮点数的更多信息，请参见 [维基百科][wikipedia]。<br>
///
/// *[See also the `std::f32::consts` module](crate::f32::consts).*
///
/// [wikipedia]: https://en.wikipedia.org/wiki/Single-precision_floating-point_format
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_f32 {}

#[doc(primitive = "f64")]
/// A 64-bit floating point type (specifically, the "binary64" type defined in IEEE 754-2008). <br>64 位浮点类型 (特别是 IEEE 754-2008 中定义的 "binary64" 类型)。<br>
///
/// This type is very similar to [`f32`], but has increased precision by using twice as many bits. <br>此类型与 [`f32`] 非常相似，但是通过使用两倍的位来提高精度。<br>
/// Please see [the documentation for `f32`][`f32`] or [Wikipedia on double precision values][wikipedia] for more information. <br>请参见 [`f32`] 的文档或关于双精度值的 [维基百科][wikipedia] 了解更多信息。<br>
///
///
/// *[See also the `std::f64::consts` module](crate::f64::consts).*
///
/// [`f32`]: prim@f32
/// [wikipedia]: https://en.wikipedia.org/wiki/Double-precision_floating-point_format
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_f64 {}

#[doc(primitive = "i8")]
//
/// The 8-bit signed integer type. <br>8 位带符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i8 {}

#[doc(primitive = "i16")]
//
/// The 16-bit signed integer type. <br>16 位带符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i16 {}

#[doc(primitive = "i32")]
//
/// The 32-bit signed integer type. <br>32 位带符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i32 {}

#[doc(primitive = "i64")]
//
/// The 64-bit signed integer type. <br>64 位带符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i64 {}

#[doc(primitive = "i128")]
//
/// The 128-bit signed integer type. <br>128 位带符号整数类型。<br>
#[stable(feature = "i128", since = "1.26.0")]
mod prim_i128 {}

#[doc(primitive = "u8")]
//
/// The 8-bit unsigned integer type. <br>8 位无符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u8 {}

#[doc(primitive = "u16")]
//
/// The 16-bit unsigned integer type. <br>16 位无符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u16 {}

#[doc(primitive = "u32")]
//
/// The 32-bit unsigned integer type. <br>32 位无符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u32 {}

#[doc(primitive = "u64")]
//
/// The 64-bit unsigned integer type. <br>64 位无符号整数类型。<br>
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u64 {}

#[doc(primitive = "u128")]
//
/// The 128-bit unsigned integer type. <br>128 位无符号整数类型。<br>
#[stable(feature = "i128", since = "1.26.0")]
mod prim_u128 {}

#[doc(primitive = "isize")]
//
/// The pointer-sized signed integer type. <br>指针大小的有符号整数类型。<br>
///
/// The size of this primitive is how many bytes it takes to reference any location in memory. <br>该原语的大小是引用内存中任何位置所需要的字节数。<br>
/// For example, on a 32 bit target, this is 4 bytes and on a 64 bit target, this is 8 bytes. <br>例如，在 32 位目标上，这是 4 个字节，而在 64 位目标上，这是 8 个字节。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_isize {}

#[doc(primitive = "usize")]
//
/// The pointer-sized unsigned integer type. <br>指针大小的无符号整数类型。<br>
///
/// The size of this primitive is how many bytes it takes to reference any location in memory. <br>该原语的大小是引用内存中任何位置所需要的字节数。<br>
/// For example, on a 32 bit target, this is 4 bytes and on a 64 bit target, this is 8 bytes. <br>例如，在 32 位目标上，这是 4 个字节，而在 64 位目标上，这是 8 个字节。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_usize {}

#[doc(primitive = "reference")]
#[doc(alias = "&")]
#[doc(alias = "&mut")]
//
/// References, both shared and mutable. <br>引用，包括共享引用和可变引用。<br>
///
/// A reference represents a borrow of some owned value. <br>引用代表某种拥有值的借用。<br> You can get one by using the `&` or `&mut` operators on a value, or by using a [`ref`](../std/keyword.ref.html) or <code>[ref](../std/keyword.ref.html) [mut](../std/keyword.mut.html)</code> pattern. <br>您可以通过在值上使用 `&` 或 `&mut` 运算符，或者使用 [`ref`](../std/keyword.ref.html) 或 <code>[ref](../std/keyword.ref.html) [mut](../std/keyword.mut.html)</code> 模式。<br>
///
/// For those familiar with pointers, a reference is just a pointer that is assumed to be aligned, not null, and pointing to memory containing a valid value of `T` - for example, <code>&[bool]</code> can only point to an allocation containing the integer values `1` ([`true`](../std/keyword.true.html)) or `0` ([`false`](../std/keyword.false.html)), but creating a <code>&[bool]</code> that points to an allocation containing the value `3` causes undefined behaviour. <br>对于那些熟悉指针的人来说，引用只是一个被认为是对齐的指针，而不是空的，并且指向包含有效值 `T` 的内存 -- 例如， <code>&[bool]</code> 只能指向包含整数值 `1` ([`true`](../std/keyword.true.html)) 或 `0` ([`false`](../std/keyword.false.html)) 的分配，但创建一个 <code>&[bool]</code> 指向包含值 `3` 的分配会导致未定义的行为。<br>
///
/// In fact, <code>[Option]\<&T></code> has the same memory representation as a nullable but aligned pointer, and can be passed across FFI boundaries as such. <br>事实上，<code>[Option]\<&T></code> 与可为空但已对齐的指针具有相同的内存表示，并且可以像这样跨 FFI 边界传递。<br>
///
/// In most cases, references can be used much like the original value. <br>在大多数情况下，引用可以像原始值一样使用。<br> Field access, method calling, and indexing work the same (save for mutability rules, of course). <br>字段访问，方法调用和索引工作相同 (当然，要保留可变性规则)。<br> In addition, the comparison operators transparently defer to the referent's implementation, allowing references to be compared the same as owned values. <br>另外，比较运算符透明地遵从引用对象的实现，从而允许将引用与拥有的值进行比较。<br>
///
/// References have a lifetime attached to them, which represents the scope for which the borrow is valid. <br>引用具有附加的生命周期，代表借用有效的作用域。<br> A lifetime is said to "outlive" another one if its representative scope is as long or longer than the other. <br>如果一个生命周期的代表作用域与另一个生命周期一样长或更长，则将其称为 "outlive"。<br> The `'static` lifetime is the longest lifetime, which represents the total life of the program. <br>`'static` 生命周期是最长的生命周期，它代表程序的总生命周期。<br>
/// For example, string literals have a `'static` lifetime because the text data is embedded into the binary of the program, rather than in an allocation that needs to be dynamically managed. <br>例如，字符串字面量具有 `'static` 生命周期，因为文本数据嵌入到程序的二进制文件中，而不是嵌入在需要动态管理的分配中。<br>
///
/// `&mut T` references can be freely coerced into `&T` references with the same referent type, and references with longer lifetimes can be freely coerced into references with shorter ones. <br>`&mut T` 引用可以自由强制转换为 `&T` 引用类型相同的引用，生命周期较长的引用可以自由强制转换为较短的引用。<br>
///
/// Reference equality by address, instead of comparing the values pointed to, is accomplished via implicit reference-pointer coercion and raw pointer equality via [`ptr::eq`], while [`PartialEq`] compares values. <br>通过地址引用相等，而不是比较所指向的值，是通过 [`ptr::eq`] 通过隐式引用指针强制和裸指针相等来实现的，而 [`PartialEq`] 则是对值进行比较。<br>
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(five_ref == other_five_ref);
///
/// assert!(ptr::eq(five_ref, same_five_ref));
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// For more information on how to use references, see [the book's section on "References and Borrowing"][book-refs]. <br>有关如何使用引用的更多信息，请参见 [本书的 "References and Borrowing" 章节][book-refs]。<br>
///
/// [book-refs]: ../book/ch04-02-references-and-borrowing.html
///
/// # Trait implementations <br>trait 实现<br>
///
/// The following traits are implemented for all `&T`, regardless of the type of its referent: <br>对于所有 `&T` 都实现了以下 traits，无论其引用的类型是什么：<br>
///
/// * [`Copy`]
/// * [`Clone`] \(Note that this will not defer to `T`'s `Clone` implementation if it exists!) <br>[`Clone`] \(请注意，如果存在的话，这不会遵循 `T` 的 `Clone` 实现！)<br>
/// * [`Deref`]
/// * [`Borrow`]
/// * [`fmt::Pointer`]
///
/// [`Deref`]: ops::Deref
/// [`Borrow`]: borrow::Borrow
///
/// `&mut T` references get all of the above except `Copy` and `Clone` (to prevent creating multiple simultaneous mutable borrows), plus the following, regardless of the type of its referent: <br>`&mut T` 引用除了 `Copy` 和 `Clone` (防止创建多个同时借用) 之外的所有内容，加上以下内容，无论其所指对象的类型如何：<br>
///
/// * [`DerefMut`]
/// * [`BorrowMut`]
///
/// [`DerefMut`]: ops::DerefMut
/// [`BorrowMut`]: borrow::BorrowMut
/// [bool]: prim@bool
///
/// The following traits are implemented on `&T` references if the underlying `T` also implements that trait: <br>如果底层 `T` 也实现了该 trait，则在 `&T` 引用上实现以下 traits：<br>
///
/// * All the traits in [`std::fmt`] except [`fmt::Pointer`] (which is implemented regardless of the type of its referent) and [`fmt::Write`] <br>[`std::fmt`] 中的所有 traits，除了 [`fmt::Pointer`] (无论其引用对象的类型是什么，它都被实现) 和 [`fmt::Write`]<br>
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`AsRef`]
/// * [`Fn`] \(in addition, `&T` references get [`FnMut`] and [`FnOnce`] if `T: Fn`) <br>[`Fn`] \(另外，`&T` 引用 [`FnMut`] 和 [`FnOnce`] 如果 `T: Fn`)<br>
/// * [`Hash`]
/// * [`ToSocketAddrs`]
/// * [`Send`] \(`&T` references also require <code>T: [Sync]</code>) <br>[`Send`] \(`&T` 引用也需要 <code>T: [Sync]</code>)<br>
///
/// [`std::fmt`]: fmt
/// [`Hash`]: hash::Hash
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`ToSocketAddrs`]: ", include_str!("../primitive_docs/net_tosocketaddrs.md"))]
/// `&mut T` references get all of the above except `ToSocketAddrs`, plus the following, if `T` implements that trait: <br>`&mut T` 引用获得除 `ToSocketAddrs` 之外的所有上述内容，加上以下内容，如果 `T` 实现了 trait：<br>
///
///
/// * [`AsMut`]
/// * [`FnMut`] \(in addition, `&mut T` references get [`FnOnce`] if `T: FnMut`) <br>[`FnMut`] \(另外，如果 `T: FnMut`，`&mut T` 引用得到 [`FnOnce`])<br>
/// * [`fmt::Write`]
/// * [`Iterator`]
/// * [`DoubleEndedIterator`]
/// * [`ExactSizeIterator`]
/// * [`FusedIterator`]
/// * [`TrustedLen`]
/// * [`io::Write`]
/// * [`Read`]
/// * [`Seek`]
/// * [`BufRead`]
///
/// [`FusedIterator`]: iter::FusedIterator
/// [`TrustedLen`]: iter::TrustedLen
///
#[doc = concat!("[`Seek`]: ", include_str!("../primitive_docs/io_seek.md"))]
#[doc = concat!("[`BufRead`]: ", include_str!("../primitive_docs/io_bufread.md"))]
#[doc = concat!("[`Read`]: ", include_str!("../primitive_docs/io_read.md"))]
#[doc = concat!("[`io::Write`]: ", include_str!("../primitive_docs/io_write.md"))]
/// Note that due to method call deref coercion, simply calling a trait method will act like they work on references as well as they do on owned values! <br>请注意，由于采用了调用解引用强制多态方法，只需调用 trait 方法就可以像处理引用一样，也可以使用其拥有的值！<br> The implementations described here are meant for generic contexts, where the final type `T` is a type parameter or otherwise not locally known. <br>这里描述的实现是针对泛型上下文的，其中最终类型 `T` 是类型参数或本地未知。<br>
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_ref {}

#[doc(primitive = "fn")]
//
/// Function pointers, like `fn(usize) -> bool`. <br>函数指针，例如 `fn(usize) -> bool`。<br>
///
/// *See also the traits [`Fn`], [`FnMut`], and [`FnOnce`]. <br>另请参见 traits [`Fn`]，[`FnMut`] 和 [`FnOnce`]。<br>*
///
/// [`Fn`]: ops::Fn
/// [`FnMut`]: ops::FnMut
/// [`FnOnce`]: ops::FnOnce
///
/// Function pointers are pointers that point to *code*, not data. <br>函数指针是指向 *code* 的指针，而不是数据。<br> They can be called just like functions. <br>它们可以像函数一样被调用。<br>
/// Like references, function pointers are, among other things, assumed to not be null, so if you want to pass a function pointer over FFI and be able to accommodate null pointers, make your type [`Option<fn()>`](core::option#options-and-pointers-nullable-pointers) with your required signature. <br>像引用一样，函数指针被假定为不为空，所以如果您想通过 FFI 传递函数指针并能够容纳空指针，请使用所需的签名来创建类型 [`Option<fn()>`](core::option#options-and-pointers-nullable-pointers)。<br>
///
///
/// ### Safety
///
/// Plain function pointers are obtained by casting either plain functions, or closures that don't capture an environment: <br>普通函数指针是通过强制转换不能捕获环境的普通函数或闭包而获得的：<br>
///
/// ```
/// fn add_one(x: usize) -> usize {
///     x + 1
/// }
///
/// let ptr: fn(usize) -> usize = add_one;
/// assert_eq!(ptr(5), 6);
///
/// let clos: fn(usize) -> usize = |x| x + 5;
/// assert_eq!(clos(5), 10);
/// ```
///
/// In addition to varying based on their signature, function pointers come in two flavors: safe and unsafe. <br>除了根据其签名而有所不同外，函数指针还具有两种形式：安全和不安全。<br>
/// Plain `fn()` function pointers can only point to safe functions, while `unsafe fn()` function pointers can point to safe or unsafe functions. <br>普通 `fn()` 函数指针只能指向安全函数，而 `unsafe fn()` 函数指针可以指向安全或不安全函数。<br>
///
/// ```
/// fn add_one(x: usize) -> usize {
///     x + 1
/// }
///
/// unsafe fn add_one_unsafely(x: usize) -> usize {
///     x + 1
/// }
///
/// let safe_ptr: fn(usize) -> usize = add_one;
///
/// // ERROR: mismatched types: expected normal fn, found unsafe fn let bad_ptr: fn(usize) -> usize = add_one_unsafely; <br>不匹配的类型：预期正常 fn，发现不安全 fn let bad_ptr: fn(usize) -> usize=add_one_unsafely；<br>
/////
///
/// let unsafe_ptr: unsafe fn(usize) -> usize = add_one_unsafely;
/// let really_safe_ptr: unsafe fn(usize) -> usize = add_one;
/// ```
///
/// ### ABI
///
/// On top of that, function pointers can vary based on what ABI they use. <br>最重要的是，函数指针可以根据它们使用的 ABI 有所不同。<br> This is achieved by adding the `extern` keyword before the type, followed by the ABI in question. <br>这是通过在类型之前添加 `extern` 关键字，然后是所涉及的 ABI 来实现的。<br> The default ABI is "Rust", i.e., `fn()` is the exact same type as `extern "Rust" fn()`. <br>默认的 ABI 是 "Rust"，即 `fn()` 是与 `extern "Rust" fn()` 完全相同的类型。<br>
/// A pointer to a function with C ABI would have type `extern "C" fn()`. <br>指向带有 C ABI 的函数的指针的类型为 `extern "C" fn()`。<br>
///
/// `extern "ABI" { ... }` blocks declare functions with ABI "ABI". <br>`extern "ABI" { ... }` 块用 ABI "ABI" 声明函数。<br> The default here is "C", i.e., functions declared in an `extern {...}` block have "C" ABI. <br>此处的默认值为 "C"，即，在 `extern {...}` 块中声明的函数具有 "C" ABI。<br>
///
/// For more information and a list of supported ABIs, see [the nomicon's section on foreign calling conventions][nomicon-abi]. <br>有关更多信息和受支持的 ABI 列表，请参见 [nomicon 中关于外部调用约定的部分][nomicon-abi]。<br>
///
/// [nomicon-abi]: ../nomicon/ffi.html#foreign-calling-conventions
///
/// ### Variadic functions <br>可变函数<br>
///
/// Extern function declarations with the "C" or "cdecl" ABIs can also be *variadic*, allowing them to be called with a variable number of arguments. <br>"C" 或 "cdecl" ABI 的 Extern 函数声明也可以 *variadic*，允许使用可变数量的参数来调用它们。<br> Normal Rust functions, even those with an `extern "ABI"`, cannot be variadic. <br>普通的 Rust 函数，即使是 `extern "ABI"` 的函数，也不能可变。<br>
/// For more information, see [the nomicon's section on variadic functions][nomicon-variadic]. <br>有关更多信息，请参见 [关于可变参数函数的 nomicon 部分][nomicon-variadic]。<br>
///
/// [nomicon-variadic]: ../nomicon/ffi.html#variadic-functions
///
/// ### Creating function pointers <br>创建函数指针<br>
///
/// When `bar` is the name of a function, then the expression `bar` is *not* a function pointer. <br>如果 `bar` 是函数的名称，则表达式 `bar`*不是* 函数指针。<br> Rather, it denotes a value of an unnameable type that uniquely identifies the function `bar`. <br>相反，它表示唯一标识函数 `bar` 的无法命名类型的值。<br> The value is zero-sized because the type already identifies the function. <br>该值的大小为零，因为该类型已经标识了该函数。<br>
/// This has the advantage that "calling" the value (it implements the `Fn*` traits) does not require dynamic dispatch. <br>这样做的好处是 "calling" 值 (实现 `Fn*` traits) 不需要动态分配。<br>
///
/// This zero-sized type *coerces* to a regular function pointer. <br>零大小的类型 *强制* 到常规函数指针。<br> For example: <br>例如：<br>
///
/// ```rust
/// use std::mem;
///
/// fn bar(x: i32) {}
///
/// let not_bar_ptr = bar; // `not_bar_ptr` is zero-sized, uniquely identifying `bar` <br>`not_bar_ptr` 是零大小的，唯一标识是 `bar`<br>
/// assert_eq!(mem::size_of_val(&not_bar_ptr), 0);
///
/// let bar_ptr: fn(i32) = not_bar_ptr; // force coercion to function pointer <br>强制转换为函数指针<br>
/// assert_eq!(mem::size_of_val(&bar_ptr), mem::size_of::<usize>());
///
/// let footgun = &bar; // this is a shared reference to the zero-sized type identifying `bar` <br>这是对标识 `bar` 的零大小类型的共享引用<br>
/// ```
///
/// The last line shows that `&bar` is not a function pointer either. <br>最后一行显示 `&bar` 也不是函数指针。<br> Rather, it is a reference to the function-specific ZST. <br>相反，它是特定于函数的 ZST 的引用。<br> `&bar` is basically never what you want when `bar` is a function. <br>当 `bar` 是一个函数时，`&bar` 基本上不是您想要的。<br>
///
/// ### Casting to and from integers <br>转换为整数和从整数转换<br>
///
/// You cast function pointers directly to integers: <br>您将函数指针直接转换为整数:<br>
///
/// ```rust
/// let fnptr: fn(i32) -> i32 = |x| x+2;
/// let fnptr_addr = fnptr as usize;
/// ```
///
/// However, a direct cast back is not possible. <br>但是，直接回退是不可能的。<br> You need to use `transmute`: <br>您需要使用 `transmute`:<br>
///
/// ```rust
/// # let fnptr: fn(i32) -> i32 = |x| x+2;
/// # let fnptr_addr = fnptr as usize;
/// let fnptr = fnptr_addr as *const ();
/// let fnptr: fn(i32) -> i32 = unsafe { std::mem::transmute(fnptr) };
/// assert_eq!(fnptr(40), 42);
/// ```
///
/// Crucially, we `as`-cast to a raw pointer before `transmute`ing to a function pointer. <br>至关重要的是，我们在转换为函数指针之前 `as`-cast 为一个裸指针。<br>
/// This avoids an integer-to-pointer `transmute`, which can be problematic. <br>这避免了整数到指针 `transmute`，这可能是有问题的。<br>
/// Transmuting between raw pointers and function pointers (i.e., two pointer types) is fine. <br>在裸指针 (即两个指针类型) 之间转换是可以的。<br>
///
/// Note that all of this is not portable to platforms where function pointers and data pointers have different sizes. <br>请注意，所有这些都不能移植到函数指针和数据指针具有不同大小的平台。<br>
///
/// ### Trait implementations <br>trait 实现<br>
///
/// In this documentation the shorthand `fn (T₁, T₂, …, Tₙ)` is used to represent non-variadic function pointers of varying length. <br>在本文档中，简写 `fn (T₁, T₂,…, Tₙ)` 用于表示可变长度的非可变函数指针。<br> Note that this is a convenience notation to avoid repetitive documentation, not valid Rust syntax. <br>请注意，这是一种方便的符号，以避免重复文档，不是有效的 Rust 语法。<br>
///
/// Due to a temporary restriction in Rust's type system, these traits are only implemented on functions that take 12 arguments or less, with the `"Rust"` and `"C"` ABIs. <br>由于 Rust 的类型系统中的临时限制，这些 traits 仅在 `"Rust"` 和 `"C"` ABI 上使用不超过 12 个参数的函数上实现。<br> In the future, this may change: <br>在未来，这可能会改变:<br>
///
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`Hash`]
/// * [`Pointer`]
/// * [`Debug`]
///
/// The following traits are implemented for function pointers with any number of arguments and any ABI. <br>以下 traits 是为具有任意数量参数和任意 ABI 的函数指针实现的。<br>
/// These traits have implementations that are automatically generated by the compiler, so are not limited by missing language features: <br>这些 traits 具有由编译器自动生成的实现，因此不受缺少语言特性的限制:<br>
///
/// * [`Clone`]
/// * [`Copy`]
/// * [`Send`]
/// * [`Sync`]
/// * [`Unpin`]
/// * [`UnwindSafe`]
/// * [`RefUnwindSafe`]
///
/// [`Hash`]: hash::Hash
/// [`Pointer`]: fmt::Pointer
/// [`UnwindSafe`]: panic::UnwindSafe
/// [`RefUnwindSafe`]: panic::RefUnwindSafe
///
/// In addition, all *safe* function pointers implement [`Fn`], [`FnMut`], and [`FnOnce`], because these traits are specially known to the compiler. <br>此外，所有 *safe* 函数指针都实现了 [`Fn`]、[`FnMut`] 和 [`FnOnce`]，因为这些 traits 是编译器特别知道的。<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_fn {}

// Required to make auto trait impls render. <br>需要进行自动 trait impls 渲染。<br>
// See src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls <br>请参见 src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls<br>
#[doc(hidden)]
#[cfg(not(bootstrap))]
impl<Ret, T> fn(T) -> Ret {}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(fake_variadic))]
/// This trait is implemented on function pointers with any number of arguments. <br>这个 trait 是在具有任意数量参数的函数指针上实现的。<br>
impl<Ret, T> Clone for fn(T) -> Ret {
    fn clone(&self) -> Self {
        loop {}
    }
}

// Fake impl that's only really used for docs. <br>仅真正用于文档的假 impl。<br>
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(fake_variadic))]
/// This trait is implemented on function pointers with any number of arguments. <br>这个 trait 是在具有任意数量参数的函数指针上实现的。<br>
impl<Ret, T> Copy for fn(T) -> Ret {
    // empty
}
