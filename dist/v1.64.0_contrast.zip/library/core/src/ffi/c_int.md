Equivalent to C's `signed int` (`int`) type. <br>等效于 C 的 `signed int` (`int`) 类型。<br>

This type will almost always be [`i32`], but may differ on some esoteric systems. <br>这种类型几乎总是 [`i32`]，但在某些深奥的系统上可能有所不同。<br> The C standard technically only requires that this type be a signed integer that is at least the size of a [`short`]; <br>C 标准从技术上仅要求此类型为带符号的整数，至少应为 [`short`] 的大小。<br> some systems define it as an [`i16`], for example. <br>例如，某些系统将其定义为 [`i16`]。<br>

[`short`]: c_short
