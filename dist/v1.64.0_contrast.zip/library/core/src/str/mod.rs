//! String manipulation. <br>字符串操作。<br>
//!
//! For more details, see the [`std::str`] module. <br>有关更多详细信息，请参见 [`std::str`] 模块。<br>
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod count;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char::{self, EscapeDebugExtArgs};
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::{next_code_point, utf8_char_width};

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

#[inline(never)]
#[cold]
#[track_caller]
#[rustc_allow_const_fn_unstable(const_eval_select)]
const fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    // SAFETY: panics for both branches <br>两个分支的 panic<br>
    unsafe {
        crate::intrinsics::const_eval_select(
            (s, begin, end),
            slice_error_fail_ct,
            slice_error_fail_rt,
        )
    }
}

const fn slice_error_fail_ct(_: &str, _: usize, _: usize) -> ! {
    panic!("failed to slice string");
}

fn slice_error_fail_rt(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let trunc_len = s.floor_char_boundary(MAX_DISPLAY_LENGTH);
    let s_trunc = &s[..trunc_len];
    let ellipsis = if trunc_len < s.len() { "[...]" } else { "" };

    // 1. out of bounds <br>越界<br>
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {oob_index} is out of bounds of `{s_trunc}`{ellipsis}");
    }

    // 2. begin <= end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. character boundary <br>角色边界<br>
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // find the character <br>找到角色<br>
    let char_start = s.floor_char_boundary(index);
    // `char_start` must be less than len and a char boundary <br>`char_start` 必须小于 len 和一个字符边界<br>
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[cfg(not(test))]
impl str {
    /// Returns the length of `self`. <br>返回 `self` 的长度。<br>
    ///
    /// This length is in bytes, not [`char`]s or graphemes. <br>该长度以字节为单位，而不是 [`char`] 或字素。<br>
    /// In other words, it might not be what a human considers the length of the string. <br>换句话说，它可能不是人类认为的字符串长度。<br>
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.39.0")]
    #[must_use]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Returns `true` if `self` has a length of zero bytes. <br>如果 `self` 的长度为零字节，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.39.0")]
    #[must_use]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Checks that `index`-th byte is the first byte in a UTF-8 code point sequence or the end of the string. <br>检查第 index 个字节是 UTF-8 代码点序列中的第一个字节还是字符串的末尾。<br>
    ///
    ///
    /// The start and end of the string (when `index == self.len()`) are considered to be boundaries. <br>字符串的开头和结尾 (当 `index == self.len()`) 被视为边界时。<br>
    ///
    /// Returns `false` if `index` is greater than `self.len()`. <br>如果 `index` 大于 `self.len()`，则返回 `false`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // start of `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // second byte of `ö` <br>`ö` 的第二个字节<br>
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // third byte of `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[must_use]
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[rustc_const_unstable(feature = "const_is_char_boundary", issue = "none")]
    #[inline]
    pub const fn is_char_boundary(&self, index: usize) -> bool {
        // 0 is always ok. <br>0 总是可以的。<br>
        // Test for 0 explicitly so that it can optimize out the check easily and skip reading string data for that case. <br>显式测试 0，以便可以轻松优化检查，并在这种情况下跳过读取字符串数据。<br>
        //
        // Note that optimizing `self.get(..index)` relies on this. <br>请注意，优化 `self.get(..index)` 依赖于此。<br>
        if index == 0 {
            return true;
        }

        match self.as_bytes().get(index) {
            // For `None` we have two options: <br>对于 `None`，我们有两个选择：<br>
            //
            // - index == self.len() Empty strings are valid, so return true <br>index == self.len() 空字符串是有效的，因此返回 true<br>
            // - index > self.len() In this case return false <br>index > self.len() 在这种情况下返回 false<br>
            //
            // The check is placed exactly here, because it improves generated code on higher opt-levels. <br>检查正好放在这里，因为它改进了更高 opt-level 上生成的代码。<br>
            // See PR #84751 for more details. <br>有关更多详细信息，请参见 PR #84751。<br>
            //
            //
            None => index == self.len(),

            Some(&b) => b.is_utf8_char_boundary(),
        }
    }

    /// Finds the closest `x` not exceeding `index` where `is_char_boundary(x)` is `true`. <br>查找不超过 `index` 的最接近的 `x`，其中 `is_char_boundary(x)` 是 `true`。<br>
    ///
    /// This method can help you truncate a string so that it's still valid UTF-8, but doesn't exceed a given number of bytes. <br>此方法可以帮助您截断字符串，使其仍然是有效的 UTF-8，但不超过给定的字节数。<br>
    /// Note that this is done purely at the character level and can still visually split graphemes, even though the underlying characters aren't split. <br>请注意，这纯粹是在字符级别完成的，并且仍然可以在视觉上分割字素，即使底层字符没有被分割。<br>
    ///
    /// For example, the emoji 🧑‍🔬 (scientist) could be split so that the string only includes 🧑 (person) instead. <br>例如，表情符号 🧑‍🔬 (科学家) 可以被拆分，以便字符串仅包含 🧑 (人)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(round_char_boundary)]
    /// let s = "❤️🧡💛💚💙💜";
    /// assert_eq!(s.len(), 26);
    /// assert!(!s.is_char_boundary(13));
    ///
    /// let closest = s.floor_char_boundary(13);
    /// assert_eq!(closest, 10);
    /// assert_eq!(&s[..closest], "❤️🧡");
    /// ```
    ///
    #[unstable(feature = "round_char_boundary", issue = "93743")]
    #[inline]
    pub fn floor_char_boundary(&self, index: usize) -> usize {
        if index >= self.len() {
            self.len()
        } else {
            let lower_bound = index.saturating_sub(3);
            let new_index = self.as_bytes()[lower_bound..=index]
                .iter()
                .rposition(|b| b.is_utf8_char_boundary());

            // SAFETY: we know that the character boundary will be within four bytes <br>我们知道字符边界将在四个字节内<br>
            unsafe { lower_bound + new_index.unwrap_unchecked() }
        }
    }

    /// Finds the closest `x` not below `index` where `is_char_boundary(x)` is `true`. <br>查找不低于 `index` 的最接近的 `x`，其中 `is_char_boundary(x)` 是 `true`。<br>
    ///
    /// This method is the natural complement to [`floor_char_boundary`]. <br>这种方法是对 [`floor_char_boundary`] 的自然补充。<br>
    /// See that method for more details. <br>有关更多详细信息，请参见该方法。<br>
    ///
    /// [`floor_char_boundary`]: str::floor_char_boundary
    ///
    /// # Panics
    ///
    /// Panics if `index > self.len()`. <br>如果 `index > self.len()`，就会出现 panic。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(round_char_boundary)]
    /// let s = "❤️🧡💛💚💙💜";
    /// assert_eq!(s.len(), 26);
    /// assert!(!s.is_char_boundary(13));
    ///
    /// let closest = s.ceil_char_boundary(13);
    /// assert_eq!(closest, 14);
    /// assert_eq!(&s[..closest], "❤️🧡💛");
    /// ```
    #[unstable(feature = "round_char_boundary", issue = "93743")]
    #[inline]
    pub fn ceil_char_boundary(&self, index: usize) -> usize {
        if index > self.len() {
            slice_error_fail(self, index, index)
        } else {
            let upper_bound = Ord::min(index + 4, self.len());
            self.as_bytes()[index..upper_bound]
                .iter()
                .position(|b| b.is_utf8_char_boundary())
                .map_or(upper_bound, |pos| pos + index)
        }
    }

    /// Converts a string slice to a byte slice. <br>将字符串切片转换为字节切片。<br>
    /// To convert the byte slice back into a string slice, use the [`from_utf8`] function. <br>要将字节切片切回为字符串切片，请使用 [`from_utf8`] 函数。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.39.0")]
    #[must_use]
    #[inline(always)]
    #[allow(unused_attributes)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: const sound because we transmute two types with the same layout <br>常量声音，因为我们转换了两种具有相同布局的类型<br>
        unsafe { mem::transmute(self) }
    }

    /// Converts a mutable string slice to a mutable byte slice. <br>将可变字符串切片转换为可变字节切片。<br>
    ///
    /// # Safety
    ///
    /// The caller must ensure that the content of the slice is valid UTF-8 before the borrow ends and the underlying `str` is used. <br>调用者必须确保在借用结束和使用底层 `str` 之前，切片的内容是有效的 UTF-8。<br>
    ///
    ///
    /// Use of a `str` whose contents are not valid UTF-8 is undefined behavior. <br>使用内容无效的 `str` UTF-8 是未定义的行为。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[must_use]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: the cast from `&str` to `&[u8]` is safe since `str` has the same layout as `&[u8]` (only libstd can make this guarantee). <br>从 `&str` 到 `&[u8]` 的转换是安全的，因为 `str` 具有与 `&[u8]` 相同的布局 (只有 libstd 可以提供此保证)。<br>
        //
        // The pointer dereference is safe since it comes from a mutable reference which is guaranteed to be valid for writes. <br>指针解引用是安全的，因为它来自变量引用，该变量对写操作有效。<br>
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Converts a string slice to a raw pointer. <br>将字符串切片转换为裸指针。<br>
    ///
    /// As string slices are a slice of bytes, the raw pointer points to a [`u8`]. <br>由于字符串切片是字节的切片，所以裸指针指向 [`u8`]。<br>
    /// This pointer will be pointing to the first byte of the string slice. <br>该指针将指向字符串切片的第一个字节。<br>
    ///
    /// The caller must ensure that the returned pointer is never written to. <br>调用者必须确保返回的指针永远不会被写入。<br>
    /// If you need to mutate the contents of the string slice, use [`as_mut_ptr`]. <br>如果需要更改字符串切片的内容，请使用 [`as_mut_ptr`]。<br>
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[must_use]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converts a mutable string slice to a raw pointer. <br>将可变字符串切片转换为裸指针。<br>
    ///
    /// As string slices are a slice of bytes, the raw pointer points to a [`u8`]. <br>由于字符串切片是字节的切片，所以裸指针指向 [`u8`]。<br>
    /// This pointer will be pointing to the first byte of the string slice. <br>该指针将指向字符串切片的第一个字节。<br>
    ///
    /// It is your responsibility to make sure that the string slice only gets modified in a way that it remains valid UTF-8. <br>您有责任确保仅以有效的 UTF-8 方式修改字符串切片。<br>
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[must_use]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Returns a subslice of `str`. <br>返回 `str` 的子切片。<br>
    ///
    /// This is the non-panicking alternative to indexing the `str`. <br>这是索引 `str` 的非紧急选择。<br>
    /// Returns [`None`] whenever equivalent indexing operation would panic. <br>每当等效的索引操作将为 panic 时，将返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indices not on UTF-8 sequence boundaries <br>索引不在 UTF-8 序列边界上<br>
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // out of bounds <br>越界<br>
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const fn get<I: ~const SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Returns a mutable subslice of `str`. <br>返回 `str` 的可变子切片。<br>
    ///
    /// This is the non-panicking alternative to indexing the `str`. <br>这是索引 `str` 的非紧急选择。<br>
    /// Returns [`None`] whenever equivalent indexing operation would panic. <br>每当等效的索引操作将为 panic 时，将返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // correct length <br>正确的长度<br>
    /// assert!(v.get_mut(0..5).is_some());
    /// // out of bounds <br>越界<br>
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const fn get_mut<I: ~const SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Returns an unchecked subslice of `str`. <br>返回未经检查的 `str` 子切片。<br>
    ///
    /// This is the unchecked alternative to indexing the `str`. <br>这是索引 `str` 的未经检查的替代方法。<br>
    ///
    /// # Safety
    ///
    /// Callers of this function are responsible that these preconditions are satisfied: <br>此函数的调用者有责任满足以下先决条件：<br>
    ///
    /// * The starting index must not exceed the ending index; <br>起始索引不得超过结束索引；<br>
    /// * Indexes must be within bounds of the original slice; <br>索引必须在原始切片的范围内；<br>
    /// * Indexes must lie on UTF-8 sequence boundaries. <br>索引必须位于 UTF-8 序列边界上。<br>
    ///
    /// Failing that, the returned string slice may reference invalid memory or violate the invariants communicated by the `str` type. <br>否则，返回的字符串切片可能会引用无效的内存或违反 `str` 类型传达的不变量。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const unsafe fn get_unchecked<I: ~const SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked`; <br>调用者必须维护 `get_unchecked` 的安全保证；<br>
        // the slice is dereferenceable because `self` is a safe reference. <br>切片是可解引用的，因为 `self` 是一个安全的引用。<br>
        // The returned pointer is safe because impls of `SliceIndex` have to guarantee that it is. <br>返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。<br>
        unsafe { &*i.get_unchecked(self) }
    }

    /// Returns a mutable, unchecked subslice of `str`. <br>返回 `str` 的可变，未经检查的子切片。<br>
    ///
    /// This is the unchecked alternative to indexing the `str`. <br>这是索引 `str` 的未经检查的替代方法。<br>
    ///
    /// # Safety
    ///
    /// Callers of this function are responsible that these preconditions are satisfied: <br>此函数的调用者有责任满足以下先决条件：<br>
    ///
    /// * The starting index must not exceed the ending index; <br>起始索引不得超过结束索引；<br>
    /// * Indexes must be within bounds of the original slice; <br>索引必须在原始切片的范围内；<br>
    /// * Indexes must lie on UTF-8 sequence boundaries. <br>索引必须位于 UTF-8 序列边界上。<br>
    ///
    /// Failing that, the returned string slice may reference invalid memory or violate the invariants communicated by the `str` type. <br>否则，返回的字符串切片可能会引用无效的内存或违反 `str` 类型传达的不变量。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const unsafe fn get_unchecked_mut<I: ~const SliceIndex<str>>(
        &mut self,
        i: I,
    ) -> &mut I::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked_mut`; <br>调用者必须维护 `get_unchecked_mut` 的安全保证；<br>
        // the slice is dereferenceable because `self` is a safe reference. <br>切片是可解引用的，因为 `self` 是一个安全的引用。<br>
        // The returned pointer is safe because impls of `SliceIndex` have to guarantee that it is. <br>返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。<br>
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Creates a string slice from another string slice, bypassing safety checks. <br>从另一个字符串切片中创建一个字符串切片，从而绕过安全检查。<br>
    ///
    /// This is generally not recommended, use with caution! <br>通常不建议这样做，请谨慎使用！<br> For a safe alternative see [`str`] and [`Index`]. <br>有关安全的替代方法，请参见 [`str`] 和 [`Index`]。<br>
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// This new slice goes from `begin` to `end`, including `begin` but excluding `end`. <br>此新切片从 `begin` 到 `end`，包括 `begin` 但不包括 `end`。<br>
    ///
    /// To get a mutable string slice instead, see the [`slice_mut_unchecked`] method. <br>要获取可变字符串切片，请参见 [`slice_mut_unchecked`] 方法。<br>
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Callers of this function are responsible that three preconditions are satisfied: <br>此函数的调用者有责任满足三个先决条件：<br>
    ///
    /// * `begin` must not exceed `end`. <br>`begin` 不得超过 `end`。<br>
    /// * `begin` and `end` must be byte positions within the string slice. <br>`begin` 和 `end` 必须是字符串切片内的字节位置。<br>
    /// * `begin` and `end` must lie on UTF-8 sequence boundaries. <br>`begin` 和 `end` 必须位于 UTF-8 序列边界上。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.29.0", note = "use `get_unchecked(begin..end)` instead")]
    #[must_use]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked`; <br>调用者必须维护 `get_unchecked` 的安全保证；<br>
        // the slice is dereferenceable because `self` is a safe reference. <br>切片是可解引用的，因为 `self` 是一个安全的引用。<br>
        // The returned pointer is safe because impls of `SliceIndex` have to guarantee that it is. <br>返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。<br>
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Creates a string slice from another string slice, bypassing safety checks. <br>从另一个字符串切片中创建一个字符串切片，从而绕过安全检查。<br>
    /// This is generally not recommended, use with caution! <br>通常不建议这样做，请谨慎使用！<br> For a safe alternative see [`str`] and [`IndexMut`]. <br>有关安全的替代方案，请参见 [`str`] 和 [`IndexMut`]。<br>
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// This new slice goes from `begin` to `end`, including `begin` but excluding `end`. <br>此新切片从 `begin` 到 `end`，包括 `begin` 但不包括 `end`。<br>
    ///
    /// To get an immutable string slice instead, see the [`slice_unchecked`] method. <br>要获取不可变的字符串切片，请参见 [`slice_unchecked`] 方法。<br>
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Callers of this function are responsible that three preconditions are satisfied: <br>此函数的调用者有责任满足三个先决条件：<br>
    ///
    /// * `begin` must not exceed `end`. <br>`begin` 不得超过 `end`。<br>
    /// * `begin` and `end` must be byte positions within the string slice. <br>`begin` 和 `end` 必须是字符串切片内的字节位置。<br>
    /// * `begin` and `end` must lie on UTF-8 sequence boundaries. <br>`begin` 和 `end` 必须位于 UTF-8 序列边界上。<br>
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[deprecated(since = "1.29.0", note = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked_mut`; <br>调用者必须维护 `get_unchecked_mut` 的安全保证；<br>
        // the slice is dereferenceable because `self` is a safe reference. <br>切片是可解引用的，因为 `self` 是一个安全的引用。<br>
        // The returned pointer is safe because impls of `SliceIndex` have to guarantee that it is. <br>返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。<br>
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divide one string slice into two at an index. <br>在索引处将一个字符串切片分成两个。<br>
    ///
    /// The argument, `mid`, should be a byte offset from the start of the string. <br>参数 `mid` 应该是字符串开头的字节偏移量。<br>
    /// It must also be on the boundary of a UTF-8 code point. <br>它也必须在 UTF-8 代码点的边界上。<br>
    ///
    /// The two slices returned go from the start of the string slice to `mid`, and from `mid` to the end of the string slice. <br>返回的两个切片从字符串切片的开头到 `mid`，从 `mid` 到字符串切片的结尾。<br>
    ///
    /// To get mutable string slices instead, see the [`split_at_mut`] method. <br>要获取可变字符串切片，请参见 [`split_at_mut`] 方法。<br>
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics if `mid` is not on a UTF-8 code point boundary, or if it is past the end of the last code point of the string slice. <br>如果 `mid` 不在 UTF-8 代码点边界上，或者它超过了字符串切片的最后一个代码点的末尾，就会出现 panics。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary checks that the index is in [0, .len()] <br>is_char_boundary 检查索引是否在 [0, .len()] 中<br>
        if self.is_char_boundary(mid) {
            // SAFETY: just checked that `mid` is on a char boundary. <br>刚刚检查 `mid` 是否在 char 边界上。<br>
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divide one mutable string slice into two at an index. <br>在索引处将一个可变字符串切片切成两部分。<br>
    ///
    /// The argument, `mid`, should be a byte offset from the start of the string. <br>参数 `mid` 应该是字符串开头的字节偏移量。<br>
    /// It must also be on the boundary of a UTF-8 code point. <br>它也必须在 UTF-8 代码点的边界上。<br>
    ///
    /// The two slices returned go from the start of the string slice to `mid`, and from `mid` to the end of the string slice. <br>返回的两个切片从字符串切片的开头到 `mid`，从 `mid` 到字符串切片的结尾。<br>
    ///
    /// To get immutable string slices instead, see the [`split_at`] method. <br>要获取不可变的字符串切片，请参见 [`split_at`] 方法。<br>
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics if `mid` is not on a UTF-8 code point boundary, or if it is past the end of the last code point of the string slice. <br>如果 `mid` 不在 UTF-8 代码点边界上，或者它超过了字符串切片的最后一个代码点的末尾，就会出现 panics。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary checks that the index is in [0, .len()] <br>is_char_boundary 检查索引是否在 [0, .len()] 中<br>
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: just checked that `mid` is on a char boundary. <br>刚刚检查 `mid` 是否在 char 边界上。<br>
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Returns an iterator over the [`char`]s of a string slice. <br>返回字符串切片的 [`char`] 上的迭代器。<br>
    ///
    /// As a string slice consists of valid UTF-8, we can iterate through a string slice by [`char`]. <br>由于字符串切片由有效的 UTF-8 组成，因此我们可以通过 [`char`] 遍历字符串切片。<br>
    /// This method returns such an iterator. <br>此方法返回这样的迭代器。<br>
    ///
    /// It's important to remember that [`char`] represents a Unicode Scalar Value, and might not match your idea of what a 'character' is. <br>请务必记住，[`char`] 表示 Unicode 标量值，可能与您对 'character' 的概念不符。<br>
    ///
    /// Iteration over grapheme clusters may be what you actually want. <br>实际需要的是在字形簇上进行迭代。<br>
    /// This functionality is not provided by Rust's standard library, check crates.io instead. <br>Rust 的标准库未提供此功能，请检查 crates.io。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Remember, [`char`]s might not match your intuition about characters: <br>请记住，[`char`] 可能与您对字符的直觉不符：<br>
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // not 'y̆' <br>不是 'y̆'<br>
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Returns an iterator over the [`char`]s of a string slice, and their positions. <br>返回字符串切片的 [`char`] 及其位置上的迭代器。<br>
    ///
    /// As a string slice consists of valid UTF-8, we can iterate through a string slice by [`char`]. <br>由于字符串切片由有效的 UTF-8 组成，因此我们可以通过 [`char`] 遍历字符串切片。<br>
    /// This method returns an iterator of both these [`char`]s, as well as their byte positions. <br>这个方法返回这两个 [`char`] 以及它们的字节位置的迭代器。<br>
    ///
    /// The iterator yields tuples. <br>迭代器产生元组。<br> The position is first, the [`char`] is second. <br>位置是第一，[`char`] 是第二。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Remember, [`char`]s might not match your intuition about characters: <br>请记住，[`char`] 可能与您对字符的直觉不符：<br>
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // not (0, 'y̆') <br>不是 (0，'y̆')<br>
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // note the 3 here - the last character took up two bytes <br>注意这里的 3 - 最后一个字符占用了两个字节<br>
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// An iterator over the bytes of a string slice. <br>在字符串切片的字节上进行迭代的迭代器。<br>
    ///
    /// As a string slice consists of a sequence of bytes, we can iterate through a string slice by byte. <br>由于字符串切片由字节序列组成，因此我们可以逐字节遍历字符串切片。<br>
    /// This method returns such an iterator. <br>此方法返回这样的迭代器。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Splits a string slice by whitespace. <br>用空格分割字符串切片。<br>
    ///
    /// The iterator returned will return string slices that are sub-slices of the original string slice, separated by any amount of whitespace. <br>返回的迭代器将返回作为原始字符串切片的子切片的字符串切片，并以任意数量的空格分隔。<br>
    ///
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`. <br>'Whitespace' 是根据 Unicode 派生核心属性 `White_Space` 的条款定义的。<br>
    /// If you only want to split on ASCII whitespace instead, use [`split_ascii_whitespace`]. <br>如果只想在 ASCII 空格上分割，请使用 [`split_ascii_whitespace`]。<br>
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// All kinds of whitespace are considered: <br>考虑所有类型的空白：<br>
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[must_use = "this returns the split string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[cfg_attr(not(test), rustc_diagnostic_item = "str_split_whitespace")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Splits a string slice by ASCII whitespace. <br>用 ASCII 空格分割字符串切片。<br>
    ///
    /// The iterator returned will return string slices that are sub-slices of the original string slice, separated by any amount of ASCII whitespace. <br>返回的迭代器将返回作为原始字符串切片的子切片的字符串切片，并以任意数量的 ASCII 空格分隔。<br>
    ///
    ///
    /// To split by Unicode `Whitespace` instead, use [`split_whitespace`]. <br>要改为按 Unicode `Whitespace` 进行拆分，请使用 [`split_whitespace`]。<br>
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// All kinds of ASCII whitespace are considered: <br>考虑所有类型的 ASCII 空白：<br>
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[must_use = "this returns the split string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// An iterator over the lines of a string, as string slices. <br>在字符串的各行上进行迭代的迭代器，作为字符串切片。<br>
    ///
    /// Lines are ended with either a newline (`\n`) or a carriage return with a line feed (`\r\n`). <br>行以换行符 (`\n`) 结束，或者以换行回车符 (`\r\n`) 结束。<br>
    ///
    /// The final line ending is optional. <br>最后一行的结尾是可选的。<br>
    /// A string that ends with a final line ending will return the same lines as an otherwise identical string without a final line ending. <br>以最后一行结尾的字符串将返回与没有其他最后一行结尾的相同字符串相同的行。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// The final line ending isn't required: <br>不需要最后一行：<br>
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// An iterator over the lines of a string. <br>字符串行上的迭代器。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.4.0", note = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Returns an iterator of `u16` over the string encoded as UTF-16. <br>在编码为 UTF-16 的字符串上返回 `u16` 的迭代器。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[must_use = "this returns the encoded string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Returns `true` if the given pattern matches a sub-slice of this string slice. <br>如果给定的模式与该字符串切片的子切片匹配，则返回 `true`。<br>
    ///
    /// Returns `false` if it does not. <br>如果不是，则返回 `false`。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Returns `true` if the given pattern matches a prefix of this string slice. <br>如果给定的模式与此字符串切片的前缀匹配，则返回 `true`。<br>
    ///
    /// Returns `false` if it does not. <br>如果不是，则返回 `false`。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Returns `true` if the given pattern matches a suffix of this string slice. <br>如果给定的模式与该字符串切片的后缀匹配，则返回 `true`。<br>
    ///
    /// Returns `false` if it does not. <br>如果不是，则返回 `false`。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Returns the byte index of the first character of this string slice that matches the pattern. <br>返回此字符串切片中与模式匹配的第一个字符的字节索引。<br>
    ///
    /// Returns [`None`] if the pattern doesn't match. <br>如果模式不匹配，则返回 [`None`]。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// More complex patterns using point-free style and closures: <br>使用无点样式和闭包的更复杂的模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Not finding the pattern: <br>找不到模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Returns the byte index for the first character of the last match of the pattern in this string slice. <br>返回此字符串切片中模式的最后一个匹配项的第一个字符的字节索引。<br>
    ///
    /// Returns [`None`] if the pattern doesn't match. <br>如果模式不匹配，则返回 [`None`]。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// More complex patterns with closures: <br>闭包的更复杂模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Not finding the pattern: <br>找不到模式：<br>
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// An iterator over substrings of this string slice, separated by characters matched by a pattern. <br>在此字符串切片的子字符串上进行迭代的迭代器，该子字符串由模式匹配的字符分隔。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will be a [`DoubleEndedIterator`] if the pattern allows a reverse search and forward/reverse search yields the same elements. <br>如果模式允许反向搜索且 forward/reverse 搜索产生相同的元素，则返回的迭代器将为 [`DoubleEndedIterator`]。<br>
    /// This is true for, e.g., [`char`], but not for `&str`. <br>例如，对于 [`char`]，这是正确的，但对于 `&str`，则不是。<br>
    ///
    /// If the pattern allows a reverse search but its results might differ from a forward search, the [`rsplit`] method can be used. <br>如果模式允许反向搜索，但其结果可能与正向搜索不同，则可以使用 [`rsplit`] 方法。<br>
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// If the pattern is a slice of chars, split on each occurrence of any of the characters: <br>如果模式是一片字符，请在每次出现任何字符时进行分割：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// If a string contains multiple contiguous separators, you will end up with empty strings in the output: <br>如果一个字符串包含多个连续的分隔符，您将在输出中得到空字符串：<br>
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Contiguous separators are separated by the empty string. <br>连续的分隔符由空字符串分隔。<br>
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separators at the start or end of a string are neighbored by empty strings. <br>字符串开头或结尾的分隔符与空字符串相邻。<br>
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// When the empty string is used as a separator, it separates every character in the string, along with the beginning and end of the string. <br>当空字符串用作分隔符时，它将字符串中的每个字符以及字符串的开头和结尾分隔开。<br>
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Contiguous separators can lead to possibly surprising behavior when whitespace is used as the separator. <br>当使用空格作为分隔符时，连续的分隔符可能会导致令人惊讶的行为。<br> This code is correct: <br>这段代码是正确的：<br>
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// It does _not_ give you: <br>它确实不会给您：<br>
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Use [`split_whitespace`] for this behavior. <br>为此行为使用 [`split_whitespace`]。<br>
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// An iterator over substrings of this string slice, separated by characters matched by a pattern. <br>在此字符串切片的子字符串上进行迭代的迭代器，该子字符串由模式匹配的字符分隔。<br>
    /// Differs from the iterator produced by `split` in that `split_inclusive` leaves the matched part as the terminator of the substring. <br>与 `split` 产生的迭代器的不同之处在于 `split_inclusive` 将匹配的部分保留为子字符串的终止符。<br>
    ///
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// If the last element of the string is matched, that element will be considered the terminator of the preceding substring. <br>如果字符串的最后一个元素匹配，则该元素将被视为前一个子字符串的终止符。<br>
    /// That substring will be the last item returned by the iterator. <br>该子字符串将是迭代器返回的最后一个项。<br>
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// An iterator over substrings of the given string slice, separated by characters matched by a pattern and yielded in reverse order. <br>给定字符串切片的子字符串上的迭代器，该迭代器由与模式匹配的字符分隔，并以相反的顺序产生。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator requires that the pattern supports a reverse search, and it will be a [`DoubleEndedIterator`] if a forward/reverse search yields the same elements. <br>返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索产生相同的元素，它将是 [`DoubleEndedIterator`]。<br>
    ///
    ///
    /// For iterating from the front, the [`split`] method can be used. <br>为了从正面进行迭代，可以使用 [`split`] 方法。<br>
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// An iterator over substrings of the given string slice, separated by characters matched by a pattern. <br>给定字符串切片的子字符串上的迭代器，该子字符串由模式匹配的字符分隔。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalent to [`split`], except that the trailing substring is skipped if empty. <br>等效于 [`split`]，不同之处在于尾随的子字符串为空时将被跳过。<br>
    ///
    /// [`split`]: str::split
    ///
    /// This method can be used for string data that is _terminated_, rather than _separated_ by a pattern. <br>此方法可用于 _terminated_ 的字符串数据，而不是用于模式的 _separated_ 的字符串数据。<br>
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will be a [`DoubleEndedIterator`] if the pattern allows a reverse search and forward/reverse search yields the same elements. <br>如果模式允许反向搜索且 forward/reverse 搜索产生相同的元素，则返回的迭代器将为 [`DoubleEndedIterator`]。<br>
    /// This is true for, e.g., [`char`], but not for `&str`. <br>例如，对于 [`char`]，这是正确的，但对于 `&str`，则不是。<br>
    ///
    /// If the pattern allows a reverse search but its results might differ from a forward search, the [`rsplit_terminator`] method can be used. <br>如果模式允许反向搜索，但其结果可能与正向搜索不同，则可以使用 [`rsplit_terminator`] 方法。<br>
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    ///
    /// let v: Vec<&str> = "A.B:C.D".split_terminator(&['.', ':'][..]).collect();
    /// assert_eq!(v, ["A", "B", "C", "D"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// An iterator over substrings of `self`, separated by characters matched by a pattern and yielded in reverse order. <br>`self` 子字符串上的迭代器，该迭代器由与模式匹配的字符分隔，并以相反的顺序产生。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalent to [`split`], except that the trailing substring is skipped if empty. <br>等效于 [`split`]，不同之处在于尾随的子字符串为空时将被跳过。<br>
    ///
    /// [`split`]: str::split
    ///
    /// This method can be used for string data that is _terminated_, rather than _separated_ by a pattern. <br>此方法可用于 _terminated_ 的字符串数据，而不是用于模式的 _separated_ 的字符串数据。<br>
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator requires that the pattern supports a reverse search, and it will be double ended if a forward/reverse search yields the same elements. <br>返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索产生相同的元素，则它将是双头模式。<br>
    ///
    ///
    /// For iterating from the front, the [`split_terminator`] method can be used. <br>为了从正面进行迭代，可以使用 [`split_terminator`] 方法。<br>
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    ///
    /// let v: Vec<&str> = "A.B:C.D".rsplit_terminator(&['.', ':'][..]).collect();
    /// assert_eq!(v, ["D", "C", "B", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// An iterator over substrings of the given string slice, separated by a pattern, restricted to returning at most `n` items. <br>给定字符串切片的子字符串上的迭代器 (由模式分隔)，仅限于返回最多 `n` 项。<br>
    ///
    /// If `n` substrings are returned, the last substring (the `n`th substring) will contain the remainder of the string. <br>如果返回 `n` 子字符串，则最后一个子字符串 (第 n 个子字符串) 将包含字符串的其余部分。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will not be double ended, because it is not efficient to support. <br>返回的迭代器不会是双头的，因为支持效率不高。<br>
    ///
    /// If the pattern allows a reverse search, the [`rsplitn`] method can be used. <br>如果模式允许反向搜索，则可以使用 [`rsplitn`] 方法。<br>
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An iterator over substrings of this string slice, separated by a pattern, starting from the end of the string, restricted to returning at most `n` items. <br>从字符串的末尾开始，在此字符串切片的子字符串上进行迭代的迭代器，由模式分隔，限制为最多返回 `n` 项。<br>
    ///
    ///
    /// If `n` substrings are returned, the last substring (the `n`th substring) will contain the remainder of the string. <br>如果返回 `n` 子字符串，则最后一个子字符串 (第 n 个子字符串) 将包含字符串的其余部分。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will not be double ended, because it is not efficient to support. <br>返回的迭代器不会是双头的，因为支持效率不高。<br>
    ///
    /// For splitting from the front, the [`splitn`] method can be used. <br>要从正面拆分，可以使用 [`splitn`] 方法。<br>
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Splits the string on the first occurrence of the specified delimiter and returns prefix before delimiter and suffix after delimiter. <br>在第一次出现指定分隔符时拆分字符串，并在分隔符之前返回前缀，在分隔符之后返回后缀。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=".split_once('='), Some(("cfg", "")));
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        // SAFETY: `Searcher` is known to return valid indices. <br>已知 `Searcher` 返回有效索引。<br>
        unsafe { Some((self.get_unchecked(..start), self.get_unchecked(end..))) }
    }

    /// Splits the string on the last occurrence of the specified delimiter and returns prefix before delimiter and suffix after delimiter. <br>在最后一次出现指定分隔符时分割字符串，并在分隔符之前返回前缀，在分隔符之后返回后缀。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        // SAFETY: `Searcher` is known to return valid indices. <br>已知 `Searcher` 返回有效索引。<br>
        unsafe { Some((self.get_unchecked(..start), self.get_unchecked(end..))) }
    }

    /// An iterator over the disjoint matches of a pattern within the given string slice. <br>给定字符串切片中某个模式的不相交匹配的迭代器。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will be a [`DoubleEndedIterator`] if the pattern allows a reverse search and forward/reverse search yields the same elements. <br>如果模式允许反向搜索且 forward/reverse 搜索产生相同的元素，则返回的迭代器将为 [`DoubleEndedIterator`]。<br>
    /// This is true for, e.g., [`char`], but not for `&str`. <br>例如，对于 [`char`]，这是正确的，但对于 `&str`，则不是。<br>
    ///
    /// If the pattern allows a reverse search but its results might differ from a forward search, the [`rmatches`] method can be used. <br>如果模式允许反向搜索，但其结果可能与正向搜索不同，则可以使用 [`rmatches`] 方法。<br>
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// An iterator over the disjoint matches of a pattern within this string slice, yielded in reverse order. <br>在此字符串切片中某个模式的不相交匹配项上进行迭代的迭代器，其生成顺序相反。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator requires that the pattern supports a reverse search, and it will be a [`DoubleEndedIterator`] if a forward/reverse search yields the same elements. <br>返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索产生相同的元素，它将是 [`DoubleEndedIterator`]。<br>
    ///
    ///
    /// For iterating from the front, the [`matches`] method can be used. <br>为了从正面进行迭代，可以使用 [`matches`] 方法。<br>
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// An iterator over the disjoint matches of a pattern within this string slice as well as the index that the match starts at. <br>对该字符串切片中某个模式的不相交匹配以及该匹配开始处的索引的迭代器。<br>
    ///
    /// For matches of `pat` within `self` that overlap, only the indices corresponding to the first match are returned. <br>对于 `self` 中重叠的 `pat` 匹配项，仅返回与第一个匹配项对应的索引。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator will be a [`DoubleEndedIterator`] if the pattern allows a reverse search and forward/reverse search yields the same elements. <br>如果模式允许反向搜索且 forward/reverse 搜索产生相同的元素，则返回的迭代器将为 [`DoubleEndedIterator`]。<br>
    /// This is true for, e.g., [`char`], but not for `&str`. <br>例如，对于 [`char`]，这是正确的，但对于 `&str`，则不是。<br>
    ///
    /// If the pattern allows a reverse search but its results might differ from a forward search, the [`rmatch_indices`] method can be used. <br>如果模式允许反向搜索，但其结果可能与正向搜索不同，则可以使用 [`rmatch_indices`] 方法。<br>
    ///
    /// [`rmatch_indices`]: str::rmatch_indices
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // only the first `aba` <br>只有第一个 `aba`<br>
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// An iterator over the disjoint matches of a pattern within `self`, yielded in reverse order along with the index of the match. <br>`self` 中某个模式的不相交匹配项上的迭代器，以与匹配项索引相反的顺序产生。<br>
    ///
    /// For matches of `pat` within `self` that overlap, only the indices corresponding to the last match are returned. <br>对于 `self` 中的 `pat` 重叠的匹配项，仅返回与最后一个匹配项对应的索引。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator behavior <br>迭代器行为<br>
    ///
    /// The returned iterator requires that the pattern supports a reverse search, and it will be a [`DoubleEndedIterator`] if a forward/reverse search yields the same elements. <br>返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索产生相同的元素，它将是 [`DoubleEndedIterator`]。<br>
    ///
    ///
    /// For iterating from the front, the [`match_indices`] method can be used. <br>为了从正面进行迭代，可以使用 [`match_indices`] 方法。<br>
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // only the last `aba` <br>只有最后的 `aba`<br>
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Returns a string slice with leading and trailing whitespace removed. <br>返回除去前导和尾随空格的字符串切片。<br>
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`, which includes newlines. <br>'Whitespace' 是根据 Unicode 派生的核心属性 `White_Space` 的术语定义的，该属性包括换行符。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "\n Hello\tworld\t\n";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg_attr(not(test), rustc_diagnostic_item = "str_trim")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Returns a string slice with leading whitespace removed. <br>返回除去前导空格的字符串切片。<br>
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`, which includes newlines. <br>'Whitespace' 是根据 Unicode 派生的核心属性 `White_Space` 的术语定义的，该属性包括换行符。<br>
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// `start` in this context means the first position of that byte string; <br>`start` 在此上下文中表示该字节字符串的第一个位置；<br> for a left-to-right language like English or Russian, this will be left side, and for right-to-left languages like Arabic or Hebrew, this will be the right side. <br>对于从左到右的语言 (例如英语或俄语)，这将是左侧; 对于从右到左的语言 (例如阿拉伯语或希伯来语)，这将是右侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "\n Hello\tworld\t\n";
    /// assert_eq!("Hello\tworld\t\n", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    #[cfg_attr(not(test), rustc_diagnostic_item = "str_trim_start")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Returns a string slice with trailing whitespace removed. <br>返回除去尾随空格的字符串切片。<br>
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`, which includes newlines. <br>'Whitespace' 是根据 Unicode 派生的核心属性 `White_Space` 的术语定义的，该属性包括换行符。<br>
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// `end` in this context means the last position of that byte string; <br>`end` 在此上下文中表示该字节字符串的最后位置；<br> for a left-to-right language like English or Russian, this will be right side, and for right-to-left languages like Arabic or Hebrew, this will be the left side. <br>对于从左到右的语言 (例如英语或俄语)，这将在右侧; 对于从右到左的语言 (例如阿拉伯语或希伯来语)，将在左侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = "\n Hello\tworld\t\n";
    /// assert_eq!("\n Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    #[cfg_attr(not(test), rustc_diagnostic_item = "str_trim_end")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Returns a string slice with leading whitespace removed. <br>返回除去前导空格的字符串切片。<br>
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`. <br>'Whitespace' 是根据 Unicode 派生核心属性 `White_Space` 的条款定义的。<br>
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// 'Left' in this context means the first position of that byte string; <br>'Left' 在此上下文中表示该字节字符串的第一个位置；<br> for a language like Arabic or Hebrew which are 'right to left' rather than 'left to right', this will be the _right_ side, not the left. <br>对于像阿拉伯语或希伯来语这样从右到左而不是从左到右的语言，这将是右侧，而不是左侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.33.0", note = "superseded by `trim_start`", suggestion = "trim_start")]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Returns a string slice with trailing whitespace removed. <br>返回除去尾随空格的字符串切片。<br>
    ///
    /// 'Whitespace' is defined according to the terms of the Unicode Derived Core Property `White_Space`. <br>'Whitespace' 是根据 Unicode 派生核心属性 `White_Space` 的条款定义的。<br>
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// 'Right' in this context means the last position of that byte string; <br>'Right' 在此上下文中表示该字节字符串的最后位置；<br> for a language like Arabic or Hebrew which are 'right to left' rather than 'left to right', this will be the _left_ side, not the right. <br>对于像阿拉伯语或希伯来语这样从右到左而不是从左到右的语言，这将是左侧，而不是右侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.33.0", note = "superseded by `trim_end`", suggestion = "trim_end")]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Returns a string slice with all prefixes and suffixes that match a pattern repeatedly removed. <br>返回具有与重复删除的模式匹配的所有前缀和后缀的字符串切片。<br>
    ///
    /// The [pattern] can be a [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 [`char`]、[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Remember earliest known match, correct it below if <br>记住最早的已知比匹配，如果出现以下情况，请更正<br>
            // last match is different <br>最后一个匹配不一样<br>
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` is known to return valid indices. <br>已知 `Searcher` 返回有效索引。<br>
        unsafe { self.get_unchecked(i..j) }
    }

    /// Returns a string slice with all prefixes that match a pattern repeatedly removed. <br>返回字符串切片，该字符串切片的所有前缀都与重复删除的模式匹配。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// `start` in this context means the first position of that byte string; <br>`start` 在此上下文中表示该字节字符串的第一个位置；<br> for a left-to-right language like English or Russian, this will be left side, and for right-to-left languages like Arabic or Hebrew, this will be the right side. <br>对于从左到右的语言 (例如英语或俄语)，这将是左侧; 对于从右到左的语言 (例如阿拉伯语或希伯来语)，这将是右侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` is known to return valid indices. <br>已知 `Searcher` 返回有效索引。<br>
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Returns a string slice with the prefix removed. <br>返回删除了前缀的字符串切片。<br>
    ///
    /// If the string starts with the pattern `prefix`, returns substring after the prefix, wrapped in `Some`. <br>如果字符串以模式 `prefix` 开头，则返回前缀在 `Some` 中的子字符串。<br>
    /// Unlike `trim_start_matches`, this method removes the prefix exactly once. <br>与 `trim_start_matches` 不同，此方法只删除一次前缀。<br>
    ///
    /// If the string does not start with `prefix`, returns `None`. <br>如果字符串不是以 `prefix` 开头，则返回 `None`。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Returns a string slice with the suffix removed. <br>返回删除了后缀的字符串切片。<br>
    ///
    /// If the string ends with the pattern `suffix`, returns the substring before the suffix, wrapped in `Some`. <br>如果字符串以模式 `suffix` 结尾，则返回用 `Some` 包装的后缀之前的子字符串。<br>
    /// Unlike `trim_end_matches`, this method removes the suffix exactly once. <br>与 `trim_end_matches` 不同，此方法仅将后缀删除一次。<br>
    ///
    /// If the string does not end with `suffix`, returns `None`. <br>如果字符串不以 `suffix` 结尾，则返回 `None`。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Returns a string slice with all suffixes that match a pattern repeatedly removed. <br>返回一个字符串切片，该字符串具有与重复删除的模式匹配的所有后缀。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// `end` in this context means the last position of that byte string; <br>`end` 在此上下文中表示该字节字符串的最后位置；<br> for a left-to-right language like English or Russian, this will be right side, and for right-to-left languages like Arabic or Hebrew, this will be the left side. <br>对于从左到右的语言 (例如英语或俄语)，这将在右侧; 对于从右到左的语言 (例如阿拉伯语或希伯来语)，将在左侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` is known to return valid indices. <br>已知 `Searcher` 返回有效索引。<br>
        unsafe { self.get_unchecked(0..j) }
    }

    /// Returns a string slice with all prefixes that match a pattern repeatedly removed. <br>返回字符串切片，该字符串切片的所有前缀都与重复删除的模式匹配。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// 'Left' in this context means the first position of that byte string; <br>'Left' 在此上下文中表示该字节字符串的第一个位置；<br> for a language like Arabic or Hebrew which are 'right to left' rather than 'left to right', this will be the _right_ side, not the left. <br>对于像阿拉伯语或希伯来语这样从右到左而不是从左到右的语言，这将是右侧，而不是左侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(
        since = "1.33.0",
        note = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Returns a string slice with all suffixes that match a pattern repeatedly removed. <br>返回一个字符串切片，该字符串具有与重复删除的模式匹配的所有后缀。<br>
    ///
    /// The [pattern] can be a `&str`, [`char`], a slice of [`char`]s, or a function or closure that determines if a character matches. <br>[模式][pattern] 可以是 `&str`，[`char`]，[`char`] 的切片，也可以是确定字符是否匹配的函数或闭包。<br>
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality <br>文字方向性<br>
    ///
    /// A string is a sequence of bytes. <br>字符串是字节序列。<br>
    /// 'Right' in this context means the last position of that byte string; <br>'Right' 在此上下文中表示该字节字符串的最后位置；<br> for a language like Arabic or Hebrew which are 'right to left' rather than 'left to right', this will be the _left_ side, not the right. <br>对于像阿拉伯语或希伯来语这样从右到左而不是从左到右的语言，这将是左侧，而不是右侧。<br>
    ///
    ///
    /// # Examples
    ///
    /// Simple patterns: <br>简单模式：<br>
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// A more complex pattern, using a closure: <br>使用闭包的更复杂的模式：<br>
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(
        since = "1.33.0",
        note = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses this string slice into another type. <br>将此字符串切片解析为另一种类型。<br>
    ///
    /// Because `parse` is so general, it can cause problems with type inference. <br>由于 `parse` 非常通用，因此可能导致类型推断问题。<br>
    /// As such, `parse` is one of the few times you'll see the syntax affectionately known as the 'turbofish': `::<>`. <br>因此，`parse` 是少数几次您会看到被亲切地称为 'turbofish': `::<>` 的语法之一。<br>
    ///
    /// This helps the inference algorithm understand specifically which type you're trying to parse into. <br>这可以帮助推理算法特别了解您要解析为哪种类型。<br>
    ///
    /// `parse` can parse into any type that implements the [`FromStr`] trait. <br>`parse` 可以解析为任何实现 [`FromStr`] trait 的类型。<br>
    ///

    /// # Errors
    ///
    /// Will return [`Err`] if it's not possible to parse this string slice into the desired type. <br>如果无法将此字符串切片解析为所需的类型，则将返回 [`Err`]。<br>
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Basic usage <br>基本用法<br>
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Using the 'turbofish' instead of annotating `four`: <br>使用 'turbofish' 而不是注解 `four`：<br>
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Failing to parse: <br>无法解析：<br>
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Checks if all characters in this string are within the ASCII range. <br>检查此字符串中的所有字符是否都在 ASCII 范围内。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[must_use]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // We can treat each byte as character here: all multibyte characters start with a byte that is not in the ascii range, so we will stop there already. <br>我们可以在这里将每个字节视为字符：所有多字节字符都以一个不在 ascii 范围内的字节开头，因此我们将在此停止。<br>
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Checks that two strings are an ASCII case-insensitive match. <br>检查两个字符串是否为 ASCII 不区分大小写的匹配项。<br>
    ///
    /// Same as `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, but without allocating and copying temporaries. <br>与 `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 相同，但不分配和复制临时文件。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[must_use]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Converts this string to its ASCII upper case equivalent in-place. <br>将此字符串就地转换为其 ASCII 大写等效项。<br>
    ///
    /// ASCII letters 'a' to 'z' are mapped to 'A' to 'Z', but non-ASCII letters are unchanged. <br>ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new uppercased value without modifying the existing one, use [`to_ascii_uppercase()`]. <br>要返回新的大写值而不修改现有值，请使用 [`to_ascii_uppercase()`]。<br>
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAFETY: changing ASCII letters only does not invalidate UTF-8. <br>仅更改 ASCII 字母不会使 UTF-8 无效。<br>
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Converts this string to its ASCII lower case equivalent in-place. <br>将此字符串就地转换为其 ASCII 小写等效项。<br>
    ///
    /// ASCII letters 'A' to 'Z' are mapped to 'a' to 'z', but non-ASCII letters are unchanged. <br>ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new lowercased value without modifying the existing one, use [`to_ascii_lowercase()`]. <br>要返回新的小写值而不修改现有值，请使用 [`to_ascii_lowercase()`]。<br>
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAFETY: changing ASCII letters only does not invalidate UTF-8. <br>仅更改 ASCII 字母不会使 UTF-8 无效。<br>
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Return an iterator that escapes each char in `self` with [`char::escape_debug`]. <br>返回一个迭代器，该迭代器使用 [`char::escape_debug`] 对 `self` 中的每个字符进行转义。<br>
    ///
    ///
    /// Note: only extended grapheme codepoints that begin the string will be escaped. <br>只有以字符串开头的扩展字素代码点将被转义。<br>
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{c}");
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Using `to_string`: <br>使用 `to_string`：<br>
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[must_use = "this returns the escaped string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(EscapeDebugExtArgs::ESCAPE_ALL))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Return an iterator that escapes each char in `self` with [`char::escape_default`]. <br>返回一个迭代器，该迭代器使用 [`char::escape_default`] 对 `self` 中的每个字符进行转义。<br>
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{c}");
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Using `to_string`: <br>使用 `to_string`：<br>
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[must_use = "this returns the escaped string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Return an iterator that escapes each char in `self` with [`char::escape_unicode`]. <br>返回一个迭代器，该迭代器使用 [`char::escape_unicode`] 对 `self` 中的每个字符进行转义。<br>
    ///
    /// # Examples
    ///
    /// As an iterator: <br>作为迭代器：<br>
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{c}");
    /// }
    /// println!();
    /// ```
    ///
    /// Using `println!` directly: <br>直接使用 `println!`：<br>
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    ///
    /// Both are equivalent to: <br>两者都等同于：<br>
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Using `to_string`: <br>使用 `to_string`：<br>
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[must_use = "this returns the escaped string as an iterator, \
                  without modifying the original"]
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl const Default for &str {
    /// Creates an empty str <br>创建一个空的 str<br>
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Creates an empty mutable str <br>创建一个空的可变 str<br>
    #[inline]
    fn default() -> Self {
        // SAFETY: The empty string is valid UTF-8. <br>空字符串是有效的 UTF-8。<br>
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// A nameable, cloneable fn type <br>可命名，可克隆的 fn 类型<br>
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(EscapeDebugExtArgs {
            escape_grapheme_extended: false,
            escape_single_quote: true,
            escape_double_quote: true
        })
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: not safe <br>不安全<br>
        unsafe { from_utf8_unchecked(bytes) }
    };
}
