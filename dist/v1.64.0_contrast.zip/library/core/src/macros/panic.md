Panics the current thread. <br>让当前线程 panics。<br>

This allows a program to terminate immediately and provide feedback to the caller of the program. <br>这允许程序立即终止并向程序的调用者提供反馈。<br>

This macro is the perfect way to assert conditions in example code and in tests. <br>此宏是在示例代码和测试中声明条件的理想方法。<br> `panic!` is closely tied with the `unwrap` method of both [`Option`][ounwrap] and [`Result`][runwrap] enums. <br>`panic!` 与 [`Option`][ounwrap] 和 [`Result`][runwrap] 枚举的 `unwrap` 方法密切相关。<br> Both implementations call `panic!` when they are set to [`None`] or [`Err`] variants. <br>当它们被设置为 [`None`] 或 [`Err`] 变体时，这两个实现都调用了 `panic!`。<br>

When using `panic!()` you can specify a string payload, that is built using the [`format!`] syntax. <br>使用 `panic!()` 时，你可以指定一个字符串有效载荷，它是使用 [`format!`] 语法构建的。<br> That payload is used when injecting the panic into the calling Rust thread, causing the thread to panic entirely. <br>当将 panic 注入到调用的 Rust 线程中时，将使用这个有效载荷，从而导致该线程完全变为 panic。<br>

The behavior of the default `std` hook, i.e. the code that runs directly after the panic is invoked, is to print the message payload to `stderr` along with the file/line/column information of the `panic!()` call. <br>默认 `std` 钩子的行为，即在调用 panic 后直接运行的代码，是将消息，载荷，连同 `panic!()` 调用的 file/line/column 信息一起打印到 `stderr`。<br> You can override the panic hook using [`std::panic::set_hook()`]. <br>您可以使用 [`std::panic::set_hook()`] 覆盖 panic 钩子。<br>
Inside the hook a panic can be accessed as a `&dyn Any + Send`, which contains either a `&str` or `String` for regular `panic!()` invocations. <br>在钩子内部，可以通过 `&dyn Any + Send` 访问 panic，其中包含用于常规 `panic!()` 调用的 `&str` 或 `String`。<br>
To panic with a value of another other type, [`panic_any`] can be used. <br>对于具有其他类型值的 panic，可以使用 [`panic_any`]。<br>

See also the macro [`compile_error!`], for raising errors during compilation. <br>另请参见宏 [`compile_error!`]，以获取编译期间的错误。<br>

# When to use `panic!` vs `Result` <br>何时使用 `panic!` 与 `Result`<br>

The Rust language provides two complementary systems for constructing / representing, reporting, propagating, reacting to, and discarding errors. <br>Rust 语言提供了两个互补的系统来构建、表示、报告、传播、响应和丢弃错误。<br>
These responsibilities are collectively known as "error handling." `panic!` and `Result` are similar in that they are each the primary interface of their respective error handling systems; <br>这些职责统称为 "error handling." `panic!` 和 `Result` 的相似之处在于它们都是各自错误处理系统的主要接口;<br> however, the meaning these interfaces attach to their errors and the responsibilities they fulfill within their respective error handling systems differ. <br>但是，这些接口附加到它们的错误的含义以及它们在各自的错误处理系统中履行的职责是不同的。<br>


The `panic!` macro is used to construct errors that represent a bug that has been detected in your program. <br>`panic!` 宏用于构建代表程序中已检测到的错误的错误。<br> With `panic!` you provide a message that describes the bug and the language then constructs an error with that message, reports it, and propagates it for you. <br>使用 `panic!`，您可以提供描述错误的消息，然后语言会使用该消息构造错误、报告错误并为您传播错误。<br>

`Result` on the other hand is used to wrap other types that represent either the successful result of some computation, `Ok(T)`, or error types that represent an anticipated runtime failure mode of that computation, `Err(E)`. <br>另一方面，`Result` 用于包装其他类型，这些类型代表某些计算的成功结果 `Ok(T)` 或代表该计算的预期运行时失败模式 `Err(E)` 的错误类型。<br>
`Result` is used alongside user defined types which represent the various anticipated runtime failure modes that the associated computation could encounter. <br>`Result` 与代表相关计算可能遇到的各种预期运行时故障模式的用户定义类型一起使用。<br> `Result` must be propagated manually, often with the the help of the `?` operator and `Try` trait, and they must be reported manually, often with the help of the `Error` trait. <br>`Result` 必须手动传播，通常在 `?` 运算符和 `Try` trait 的帮助下，并且必须手动报告，通常在 `Error` trait 的帮助下。<br>

For more detailed information about error handling check out the [book] or the [`std::result`] module docs. <br>有关错误处理的更多详细信息，请切换到 [book] 或 [`std::result`] 模块文档。<br>

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html
[`std::result`]: ../std/result/index.html

# Current implementation <br>当前实现<br>

If the main thread panics it will terminate all your threads and end your program with code `101`. <br>如果主线程为 panics，它将终止您的所有线程并以代码 `101` 结束您的程序。<br>

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```
