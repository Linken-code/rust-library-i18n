// Contains the machinery necessary to print useful `assert!` messages. <br>包含打印有用的 `assert!` 消息所需的机制。<br> Not intended for public usage, not even nightly use-cases. <br>不适合公共使用，甚至不适合夜间用例。<br>
//
// Based on https://github.com/dtolnay/case-studies/tree/master/autoref-specialization.When'specialization' is robust enough (5 years? 10 years? Never?), `Capture` can be specialized to [Printable]. <br>基于 https://github.com/autoref-specialization。当'specialization' 足够健壮时 (5 年? 10 年? 从不? )，`Capture` 可以专门化为 [Printable]。<br>
//
//
//

#![allow(missing_debug_implementations)]
#![doc(hidden)]
#![unstable(feature = "generic_assert_internals", issue = "44838")]

use crate::{
    fmt::{Debug, Formatter},
    marker::PhantomData,
};

// ***** TryCapture - Generic *** <br>TryCapture - 泛型 ***<br>**

/// Marker used by [Capture] <br>[Capture] 使用的标记<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub struct TryCaptureWithoutDebug;

/// Catches an arbitrary `E` and modifies `to` accordingly <br>捕获任意 `E` 并相应地修改 `to`<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub trait TryCaptureGeneric<E, M> {
    /// Similar to [TryCapturePrintable] but generic to any `E`. <br>类似于 [TryCapturePrintable] 但泛型到任何 `E`。<br>
    fn try_capture(&self, to: &mut Capture<E, M>);
}

impl<E> TryCaptureGeneric<E, TryCaptureWithoutDebug> for &Wrapper<&E> {
    #[inline]
    fn try_capture(&self, _: &mut Capture<E, TryCaptureWithoutDebug>) {}
}

impl<E> Debug for Capture<E, TryCaptureWithoutDebug> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), core::fmt::Error> {
        f.write_str("N/A")
    }
}

// ***** TryCapture - Printable *** <br>TryCapture - 可打印 ***<br>**

/// Marker used by [Capture] <br>[Capture] 使用的标记<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub struct TryCaptureWithDebug;

/// Catches an arbitrary `E: Printable` and modifies `to` accordingly <br>捕获任意 `E: Printable` 并相应地修改 `to`<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub trait TryCapturePrintable<E, M> {
    /// Similar as [TryCaptureGeneric] but specialized to any `E: Printable`. <br>与 [TryCaptureGeneric] 类似，但专门用于任何 `E: Printable`。<br>
    fn try_capture(&self, to: &mut Capture<E, M>);
}

impl<E> TryCapturePrintable<E, TryCaptureWithDebug> for Wrapper<&E>
where
    E: Printable,
{
    #[inline]
    fn try_capture(&self, to: &mut Capture<E, TryCaptureWithDebug>) {
        to.elem = Some(*self.0);
    }
}

impl<E> Debug for Capture<E, TryCaptureWithDebug>
where
    E: Printable,
{
    fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), core::fmt::Error> {
        match self.elem {
            None => f.write_str("N/A"),
            Some(ref value) => Debug::fmt(value, f),
        }
    }
}

// ***** Others *** <br>其他 ***<br>**

/// All possible captured `assert!` elements <br>所有可能捕获的 `assert!` 元素<br>
///
/// # Types
///
/// * `E`: **E**lement that is going to be displayed. <br>`E`: 将要显示的元素。<br>
/// * `M`: **M**arker used to differentiate [Capture]s in regards to [Debug]. <br>`M`: 用于区分 [Debug] 的 [Capture] 的标记。<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub struct Capture<E, M> {
    // If None, then `E` does not implements [Printable] or `E` wasn't evaluated (`assert!( ... <br>如果没有，那么 `E` 没有实现 [Printable] 或 `E` 没有被评估 (`assert!(...<br>
    // )` short-circuited).
    //
    // If Some, then `E` implements [Printable] and was evaluated. <br>如果是 Some，则 `E` 实现 [Printable] 并被评估。<br>
    pub elem: Option<E>,
    phantom: PhantomData<M>,
}

impl<M, T> Capture<M, T> {
    #[inline]
    pub const fn new() -> Self {
        Self { elem: None, phantom: PhantomData }
    }
}

/// Necessary for the implementations of `TryCapture*` <br>`TryCapture*` 的实现所必需的<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub struct Wrapper<T>(pub T);

/// Tells which elements can be copied and displayed <br>告诉可以复制和显示哪些元素<br>
#[unstable(feature = "generic_assert_internals", issue = "44838")]
pub trait Printable: Copy + Debug {}

impl<T> Printable for T where T: Copy + Debug {}
