use crate::ops::{ControlFlow, Try};

/// An iterator able to yield elements from both ends. <br>一个能够从两端产生元素的迭代器。<br>
///
/// Something that implements `DoubleEndedIterator` has one extra capability over something that implements [`Iterator`]: the ability to also take `Item`s from the back, as well as the front. <br>实现 `DoubleEndedIterator` 的东西比实现 [`Iterator`] 的东西具有一项额外的功能：既可以从后面也可以从前面获得 `item` 的功能。<br>
///
///
/// It is important to note that both back and forth work on the same range, and do not cross: iteration is over when they meet in the middle. <br>重要的是要注意，来回运动都在相同的范围内，并且不会交叉：当它们在中间相遇时，迭代就结束了。<br>
///
/// In a similar fashion to the [`Iterator`] protocol, once a `DoubleEndedIterator` returns [`None`] from a [`next_back()`], calling it again may or may not ever return [`Some`] again. <br>以与 [`Iterator`] 协议类似的方式，一旦 `DoubleEndedIterator` 从 [`next_back()`] 返回 [`None`]，再次调用它可能会也可能不会再返回 [`Some`]。<br>
/// [`next()`] and [`next_back()`] are interchangeable for this purpose. <br>为此，[`next()`] 和 [`next_back()`] 可以互换。<br>
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "DoubleEndedIterator")]
pub trait DoubleEndedIterator: Iterator {
    /// Removes and returns an element from the end of the iterator. <br>从迭代器的末尾删除并返回一个元素。<br>
    ///
    /// Returns `None` when there are no more elements. <br>没有更多元素时返回 `None`。<br>
    ///
    /// The [trait-level] docs contain more details. <br>[trait-level] 文档包含更多详细信息。<br>
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// The elements yielded by `DoubleEndedIterator`'s methods may differ from the ones yielded by [`Iterator`]'s methods: <br>DoubleEndedIterator 方法产生的元素可能与 [`Iterator`] 方法产生的元素不同：<br>
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Advances the iterator from the back by `n` elements. <br>通过 `n` 元素从后向前推进迭代器。<br>
    ///
    /// `advance_back_by` is the reverse version of [`advance_by`]. <br>`advance_back_by` 是 [`advance_by`] 的反向版本。<br> This method will eagerly skip `n` elements starting from the back by calling [`next_back`] up to `n` times until [`None`] is encountered. <br>该方法将急切地从后面开始跳过 `n` 元素，方法是调用 [`next_back`] 最多 `n` 次，直到遇到 [`None`]。<br>
    ///
    /// `advance_back_by(n)` will return [`Ok(())`] if the iterator successfully advances by `n` elements, or [`Err(k)`] if [`None`] is encountered, where `k` is the number of elements the iterator is advanced by before running out of elements (i.e. <br>如果迭代器成功推进 `n` 个元素，则 `advance_back_by(n)` 将返回 [`Ok(())`]，如果遇到 [`None`]，则返回 [`Err(k)`]，其中 `k` 是迭代器在用完元素之前推进的元素数 (即<br>
    /// the length of the iterator). <br>迭代器的长度)。<br>
    /// Note that `k` is always less than `n`. <br>请注意，`k` 始终小于 `n`。<br>
    ///
    /// Calling `advance_back_by(0)` can do meaningful work, for example [`Flatten`] can advance its outer iterator until it finds an inner iterator that is not empty, which then often allows it to return a more accurate `size_hint()` than in its initial state. <br>调用 `advance_back_by(0)` 可以做有意义的工作，例如 [`Flatten`] 可以推进它的外部迭代器，直到它找到一个不为空的内部迭代器，然后通常允许它返回一个比初始状态更准确的 `size_hint()`。<br>
    ///
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`Flatten`]: crate::iter::Flatten
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // only `&3` was skipped <br>仅跳过 `&3`<br>
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Returns the `n`th element from the end of the iterator. <br>从迭代器的末尾返回第 n 个元素。<br>
    ///
    /// This is essentially the reversed version of [`Iterator::nth()`]. <br>这实际上是 [`Iterator::nth()`] 的反向版本。<br>
    /// Although like most indexing operations, the count starts from zero, so `nth_back(0)` returns the first value from the end, `nth_back(1)` the second, and so on. <br>尽管像大多数索引操作一样，计数从零开始，所以 `nth_back(0)` 从末尾返回第一个值，`nth_back(1)` 从第二个开始返回，依此类推。<br>
    ///
    ///
    /// Note that all elements between the end and the returned element will be consumed, including the returned element. <br>请注意，将消耗 end 和返回元素之间的所有元素，包括返回元素。<br>
    /// This also means that calling `nth_back(0)` multiple times on the same iterator will return different elements. <br>这也意味着在同一迭代器上多次调用 `nth_back(0)` 将返回不同的元素。<br>
    ///
    /// `nth_back()` will return [`None`] if `n` is greater than or equal to the length of the iterator. <br>如果 `n` 大于或等于迭代器的长度，则 `nth_back()` 将返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Calling `nth_back()` multiple times doesn't rewind the iterator: <br>多次调用 `nth_back()` 不会回退迭代器：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Returning `None` if there are less than `n + 1` elements: <br>如果少于 `n + 1` 个元素，则返回 `None`：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// This is the reverse version of [`Iterator::try_fold()`]: it takes elements starting from the back of the iterator. <br>这是 [`Iterator::try_fold()`] 的反向版本：它从迭代器的后面开始接收元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Because it short-circuited, the remaining elements are still available through the iterator. <br>由于发生短路，因此其余元素仍可通过迭代器使用。<br>
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Output = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator method that reduces the iterator's elements to a single, final value, starting from the back. <br>一种迭代器方法，从后面开始，将迭代器的元素减少为单个最终值。<br>
    ///
    /// This is the reverse version of [`Iterator::fold()`]: it takes elements starting from the back of the iterator. <br>这是 [`Iterator::fold()`] 的反向版本：它从迭代器的后面开始接收元素。<br>
    ///
    /// `rfold()` takes two arguments: an initial value, and a closure with two arguments: an 'accumulator', and an element. <br>`rfold()` 有两个参数：一个初始值，一个闭包，有两个参数：一个 'accumulator' 和一个元素。<br>
    /// The closure returns the value that the accumulator should have for the next iteration. <br>闭包返回累加器在下一次迭代中应具有的值。<br>
    ///
    /// The initial value is the value the accumulator will have on the first call. <br>初始值是累加器在第一次调用时将具有的值。<br>
    ///
    /// After applying this closure to every element of the iterator, `rfold()` returns the accumulator. <br>在将此闭包应用于迭代器的每个元素之后，`rfold()` 返回累加器。<br>
    ///
    /// This operation is sometimes called 'reduce' or 'inject'. <br>该操作有时称为 'reduce' 或 'inject'。<br>
    ///
    /// Folding is useful whenever you have a collection of something, and want to produce a single value from it. <br>当您拥有某个集合，并且希望从中产生单个值时，`fold` 非常有用。<br>
    ///
    /// Note: `rfold()` combines elements in a *right-associative* fashion. <br>`rfold()` 以*右关联*方式组合元素。<br>
    /// For associative operators like `+`, the order the elements are combined in is not important, but for non-associative operators like `-` the order will affect the final result. <br>对于像 `+` 这样的关联性，元素组合的顺序并不重要，但对于像 `-` 这样的非关联性，顺序会影响最终结果。<br>
    ///
    /// For a *left-associative* version of `rfold()`, see [`Iterator::fold()`]. <br>对于 `rfold()` 的*左关联*版本，请参见 [`Iterator::fold()`]。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // the sum of all of the elements of a <br>a 的所有元素的总和<br>
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// This example demonstrates the right-associative nature of `rfold()`: <br>这个例子演示了 `rfold()` 的右结合性质：<br>
    /// it builds a string, starting with an initial value and continuing with each element from the back until the front: <br>它构建一个字符串，从一个初始值开始，从后面到前面的每个元素继续：<br>
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({x} + {acc})")
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "foldr")]
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Searches for an element of an iterator from the back that satisfies a predicate. <br>从后面搜索满足谓词的迭代器的元素。<br>
    ///
    /// `rfind()` takes a closure that returns `true` or `false`. <br>`rfind()` 接受一个返回 `true` 或 `false` 的闭包。<br>
    /// It applies this closure to each element of the iterator, starting at the end, and if any of them return `true`, then `rfind()` returns [`Some(element)`]. <br>它将这个闭包应用到迭代器的每个元素 (从末尾开始)，如果其中任何一个返回 `true`，则 `rfind()` 返回 [`Some(element)`]。<br>
    /// If they all return `false`, it returns [`None`]. <br>如果它们都返回 `false`，则返回 [`None`]。<br>
    ///
    /// `rfind()` is short-circuiting; <br>`rfind()` 是短路的；<br> in other words, it will stop processing as soon as the closure returns `true`. <br>换句话说，一旦闭包返回 `true`，它将立即停止处理。<br>
    ///
    /// Because `rfind()` takes a reference, and many iterators iterate over references, this leads to a possibly confusing situation where the argument is a double reference. <br>由于 `rfind()` 接受 quot，并且许多迭代器迭代 quot，因此导致参数为双 quot 的情况可能令人困惑。<br>
    ///
    /// You can see this effect in the examples below, with `&&x`. <br>在 `&&x` 的以下示例中，您可以看到这种效果。<br>
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopping at the first `true`: <br>在第一个 `true` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
