use crate::iter::{FusedIterator, TrustedLen};

/// Creates an iterator that yields an element exactly once. <br>创建一个迭代器，该迭代器只生成一次元素。<br>
///
/// This is commonly used to adapt a single value into a [`chain()`] of other kinds of iteration. <br>这通常用于将单个值适配到其他类型的迭代的 [`chain()`] 中。<br>
/// Maybe you have an iterator that covers almost everything, but you need an extra special case. <br>也许您有一个涵盖几乎所有内容的迭代器，但是您需要一个额外的特殊情况。<br>
/// Maybe you have a function which works on iterators, but you only need to process one value. <br>也许您有一个可在迭代器上使用的函数，但只需要处理一个值即可。<br>
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::iter;
///
/// // one is the loneliest number <br>一个是最孤独的数字<br>
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // just one, that's all we get <br>只是一个，这就是我们得到的<br>
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining together with another iterator. <br>与另一个迭代器链接在一起。<br>
/// Let's say that we want to iterate over each file of the `.foo` directory, but also a configuration file, <br>假设我们要遍历 `.foo` 目录的每个文件，还要遍历一个配置文件，<br>
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // we need to convert from an iterator of DirEntry-s to an iterator of PathBufs, so we use map <br>我们需要将 DirEntry-s 的迭代器转换为 PathBufs 的迭代器，因此我们使用 map<br>
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // now, our iterator just for our config file <br>现在，我们的迭代器仅用于我们的配置文件<br>
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // chain the two iterators together into one big iterator <br>将两个迭代器链接到一个大迭代器中<br>
/// let files = dirs.chain(config);
///
/// // this will give us all of the files in .foo as well as .foorc <br>这将为我们提供 .foo 和 .foorc 中的所有文件<br>
/// for f in files {
///     println!("{f:?}");
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// An iterator that yields an element exactly once. <br>一个仅产生一次元素的迭代器。<br>
///
/// This `struct` is created by the [`once()`] function. <br>该 `struct` 由 [`once()`] 函数创建。<br> See its documentation for more. <br>有关更多信息，请参见其文档。<br>
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}
