//! Character conversions. <br>字符转换。<br>

use crate::char::TryFromCharError;
use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

/// Converts a `u32` to a `char`. <br>将 `u32` 转换为 `char`。<br> See [`char::from_u32`]. <br>请参见 [`char::from_u32`]。<br>
#[must_use]
#[inline]
pub(super) const fn from_u32(i: u32) -> Option<char> {
    // FIXME: once Result::ok is const fn, use it here <br>一旦 Result::ok 是 const fn，就在这里使用它<br>
    match char_try_from_u32(i) {
        Ok(c) => Some(c),
        Err(_) => None,
    }
}

/// Converts a `u32` to a `char`, ignoring validity. <br>将 `u32` 转换为 `char`，而忽略有效性。<br> See [`char::from_u32_unchecked`]. <br>请参见 [`char::from_u32_unchecked`]。<br>
#[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
#[inline]
#[must_use]
pub(super) const unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: the caller must guarantee that `i` is a valid char value. <br>调用者必须保证 `i` 是有效的 char 值。<br>
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u32 {
    /// Converts a [`char`] into a [`u32`]. <br>将 [`char`] 转换为 [`u32`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u64 {
    /// Converts a [`char`] into a [`u64`]. <br>将 [`char`] 转换为 [`u64`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The char is casted to the value of the code point, then zero-extended to 64 bit. <br>字符强制转换为代码点的值，然后零扩展为 64 位。<br>
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] <br>请参见 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]<br>
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u128 {
    /// Converts a [`char`] into a [`u128`]. <br>将 [`char`] 转换为 [`u128`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The char is casted to the value of the code point, then zero-extended to 128 bit. <br>字符强制转换为代码点的值，然后零扩展为 128 位。<br>
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] <br>请参见 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]<br>
        c as u128
    }
}

/// Map `char` with code point in U+0000..=U+00FF to byte in 0x00..=0xFF with same value, failing if the code point is greater than U+00FF. <br>将 U+0000..=U+00FF 中代码点的 `char` 映射到 0x00..=0xFF 中具有相同值的字节，如果代码点大于 U+00FF 则失败。<br>
///
///
/// See [`impl From<u8> for char`](char#impl-From<u8>-for-char) for details on the encoding. <br>有关编码的详细信息，请参见 [`impl From<u8> for char`](char#impl-From<u8>-for-char)。<br>
#[stable(feature = "u8_from_char", since = "1.59.0")]
impl TryFrom<char> for u8 {
    type Error = TryFromCharError;

    #[inline]
    fn try_from(c: char) -> Result<u8, Self::Error> {
        u8::try_from(u32::from(c)).map_err(|_| TryFromCharError(()))
    }
}

/// Maps a byte in 0x00..=0xFF to a `char` whose code point has the same value, in U+0000..=U+00FF. <br>将 0x00..=0xFF 中的字节映射到 `char`，该 `char` 的代码点具有相同的值，即 U+0000..=U+00FF。<br>
///
/// Unicode is designed such that this effectively decodes bytes with the character encoding that IANA calls ISO-8859-1. <br>Unicode 的设计使其可以使用 IANA 称为 ISO-8859-1 的字符编码有效地解码字节。<br>
/// This encoding is compatible with ASCII. <br>此编码与 ASCII 兼容。<br>
///
/// Note that this is different from ISO/IEC 8859-1 a.k.a. <br>请注意，这与 ISO/IEC 8859-1 又名不同<br>
/// ISO 8859-1 (with one less hyphen), which leaves some "blanks", byte values that are not assigned to any character. <br>ISO 8859-1 (连字符少一个)，它留下了一些 "blanks" 字节值，这些值未分配给任何字符。<br>
/// ISO-8859-1 (the IANA one) assigns them to the C0 and C1 control codes. <br>ISO-8859-1 (属于 IANA) 将它们分配给 C0 和 C1 控制代码。<br>
///
/// Note that this is *also* different from Windows-1252 a.k.a. <br>请注意，这也与 Windows-1252 也不同<br>
/// code page 1252, which is a superset ISO/IEC 8859-1 that assigns some (not all!) blanks to punctuation and various Latin characters. <br>代码页 1252，它是 ISO/IEC 8859-1 的超集，它为标点符号和各种拉丁字符分配了一些 (不是全部) 空格。<br>
///
/// To confuse things further, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, and `windows-1252` are all aliases for a superset of Windows-1252 that fills the remaining blanks with corresponding C0 and C1 control codes. <br>为了进一步混淆，[在 Web 上](https://encoding.spec.whatwg.org/) `ascii`，`iso-8859-1` 和 `windows-1252` 都是 Windows-1252 超集的别名，该超集用相应的 C0 和 C1 控制代码填充了其余的空白。<br>
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<u8> for char {
    /// Converts a [`u8`] into a [`char`]. <br>将 [`u8`] 转换为 [`char`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// An error which can be returned when parsing a char. <br>解析 char 时可以返回的错误。<br>
///
/// This `struct` is created when using the [`char::from_str`] method. <br>此 `struct` 是在使用 [`char::from_str`] 方法时创建的。<br>
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[inline]
const fn char_try_from_u32(i: u32) -> Result<char, CharTryFromError> {
    // This is an optimized version of the check (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF), which can also be written as i >= 0x110000 || (i >= 0xD800 && i < 0xE000). <br>这是检查的优化版本 (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF)，也可以写成 i >= 0x110000 || (i >= 0xD800 && i < 0xE000)。<br>
    //
    // The XOR with 0xD800 permutes the ranges such that 0xD800..0xE000 is mapped to 0x0000..0x0800, while keeping all the high bits outside 0xFFFF the same. <br>与 0xD800 的 XOR 置换范围，使 0xD800..0xE000 映射到 0x0000..0x0800，同时保持 0xFFFF 之外的所有高位相同。<br>
    // In particular, numbers >= 0x110000 stay in this range. <br>特别是，numbers >= 0x110000 停留在此范围内。<br>
    //
    // Subtracting 0x800 causes 0x0000..0x0800 to wrap, meaning that a single unsigned comparison against 0x110000 - 0x800 will detect both the wrapped surrogate range as well as the numbers originally larger than 0x110000. <br>减去 0x800 会导致 0x0000..0x0800 进行包装，这意味着针对 0x110000 - 0x800 的单个无符号比较将检测包装的代理范围以及最初大于 0x110000 的数字。<br>
    //
    //
    //
    //
    //
    //
    //
    if (i ^ 0xD800).wrapping_sub(0x800) >= 0x110000 - 0x800 {
        Err(CharTryFromError(()))
    } else {
        // SAFETY: checked that it's a legal unicode value <br>检查这是合法的 unicode 值<br>
        Ok(unsafe { transmute(i) })
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        char_try_from_u32(i)
    }
}

/// The error type returned when a conversion from [`prim@u32`] to [`prim@char`] fails. <br>[`prim@u32`] 到 [`prim@char`] 转换失败时返回的错误类型。<br>
///
/// This `struct` is created by the [`char::try_from<u32>`](char#impl-TryFrom<u32>-for-char) method. <br>这个 `struct` 是由 [`char::try_from<u32>`](char#impl-TryFrom<u32>-for-char) 方法创建的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Converts a digit in the given radix to a `char`. <br>将给定基数中的数字转换为 `char`。<br> See [`char::from_digit`]. <br>请参见 [`char::from_digit`]。<br>
#[inline]
#[must_use]
pub(super) const fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}
