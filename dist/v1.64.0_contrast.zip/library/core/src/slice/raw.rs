//! Free functions to create `&[T]` and `&mut [T]`. <br>创建 `&[T]` 和 `&mut [T]` 的 free 函数。<br>

use crate::array;
use crate::intrinsics::{assert_unsafe_precondition, is_aligned_and_not_null};
use crate::ops::Range;
use crate::ptr;

/// Forms a slice from a pointer and a length. <br>根据指针和长度形成切片。<br>
///
/// The `len` argument is the number of **elements**, not the number of bytes. <br>`len` 参数是 **元素** 的数量，而不是字节数。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `data` must be [valid] for reads for `len * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>对于 `len * mem::size_of::<T>()` 多个字节的读取，`data` 必须是 [valid]，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br> See [below](#incorrect-usage) for an example incorrectly not taking this into account. <br>请参见 [下文](#incorrect-usage) 了解一个没有考虑到这一点的错误示例。<br>
///     * `data` must be non-null and aligned even for zero-length slices. <br>即使对于零长度切片，`data` 也必须非空且对齐。<br>
///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
///
/// * `data` must point to `len` consecutive properly initialized values of type `T`. <br>`data` 必须指向 `len` 类型的 `T` 类型的连续正确初始化值。<br>
///
/// * The memory referenced by the returned slice must not be mutated for the duration of lifetime `'a`, except inside an `UnsafeCell`. <br>返回的切片引用的内存在生命周期 `'a` 期间不得更改，除非在 `UnsafeCell` 内部。<br>
///
/// * The total size `len * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `len * mem::size_of::<T>()` 必须不大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// # Caveat
///
/// The lifetime for the returned slice is inferred from its usage. <br>从使用中可以推断出返回切片的生命周期。<br>
/// To prevent accidental misuse, it's suggested to tie the lifetime to whichever source lifetime is safe in the context, such as by providing a helper function taking the lifetime of a host value for the slice, or by explicit annotation. <br>为防止意外滥用，建议将生命周期与生命周期中任何安全的来源联系起来，例如通过提供一个辅助函数，获取切片的宿主值的生命周期，或通过明确的注解法。<br>
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifest a slice for a single element <br>显示单个元素的切片<br>
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Incorrect usage <br>用法不正确<br>
///
/// The following `join_slices` function is **unsound** <br>下面的 `join_slices` 函数是不健全的<br> ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // The assertion above ensures `fst` and `snd` are contiguous, but they might still be contained within _different allocated objects_, in which case creating this slice is undefined behavior. <br>上面的断言确保 `fst` 和 `snd` 是连续的，但是它们仍可能包含在 _different allocated objects_ 中，在这种情况下，创建此切片是未定义的行为。<br>
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` and `b` are different allocated objects... <br>`a` 和 `b` 是不同的分配对象...<br>
///     let a = 42;
///     let b = 27;
///     // ... which may nevertheless be laid out contiguously in memory: | a | b | <br>但这可能会连续地放在内存中：一个 | b |<br>
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_stable(feature = "const_slice_from_raw_parts", since = "1.64.0")]
#[must_use]
pub const unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    // SAFETY: the caller must uphold the safety contract for `from_raw_parts`. <br>调用者必须遵守 `from_raw_parts` 的安全保证。<br>
    unsafe {
        assert_unsafe_precondition!(
            is_aligned_and_not_null(data)
                && crate::mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize
        );
        &*ptr::slice_from_raw_parts(data, len)
    }
}

/// Performs the same functionality as [`from_raw_parts`], except that a mutable slice is returned. <br>执行与 [`from_raw_parts`] 相同的功能，除了返回可变切片。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `data` must be [valid] for both reads and writes for `len * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>对于 `len * mem::size_of::<T>()` 多个字节的读取和写入，`data` 必须是 [valid]，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
///     * `data` must be non-null and aligned even for zero-length slices. <br>即使对于零长度切片，`data` 也必须非空且对齐。<br>
///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
///
///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
///
/// * `data` must point to `len` consecutive properly initialized values of type `T`. <br>`data` 必须指向 `len` 类型的 `T` 类型的连续正确初始化值。<br>
///
/// * The memory referenced by the returned slice must not be accessed through any other pointer (not derived from the return value) for the duration of lifetime `'a`. <br>在生命周期 `'a` 的持续时间内，不得通过任何其他指针 (不是从返回值派生) 访问返回的切片引用的内存。<br>
///   Both read and write accesses are forbidden. <br>读取和写入访问均被禁止。<br>
///
/// * The total size `len * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `len * mem::size_of::<T>()` 必须不大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts_mut", issue = "67456")]
#[must_use]
pub const unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    // SAFETY: the caller must uphold the safety contract for `from_raw_parts_mut`. <br>调用者必须遵守 `from_raw_parts_mut` 的安全保证。<br>
    unsafe {
        assert_unsafe_precondition!(
            is_aligned_and_not_null(data)
                && crate::mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize
        );
        &mut *ptr::slice_from_raw_parts_mut(data, len)
    }
}

/// Converts a reference to T into a slice of length 1 (without copying). <br>将引用转换为 T 转换为长度为 1 的切片 (不进行复制)。<br>
#[stable(feature = "from_ref", since = "1.28.0")]
#[rustc_const_stable(feature = "const_slice_from_ref_shared", since = "1.63.0")]
#[must_use]
pub const fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converts a reference to T into a slice of length 1 (without copying). <br>将引用转换为 T 转换为长度为 1 的切片 (不进行复制)。<br>
#[stable(feature = "from_ref", since = "1.28.0")]
#[rustc_const_unstable(feature = "const_slice_from_ref", issue = "90206")]
#[must_use]
pub const fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}

/// Forms a slice from a pointer range. <br>从指针范围形成一个切片。<br>
///
/// This function is useful for interacting with foreign interfaces which use two pointers to refer to a range of elements in memory, as is common in C++. <br>此函数对于与外部接口进行交互很有用，该外部接口使用两个指针来引用内存中的一系列元素，这在 C++ 中很常见。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * The `start` pointer of the range must be a [valid] and properly aligned pointer to the first element of a slice. <br>范围的 `start` 指针必须是 [valid] 并正确对齐指向切片的第一个元素的指针。<br>
///
/// * The `end` pointer must be a [valid] and properly aligned pointer to *one past* the last element, such that the offset from the end to the start pointer is the length of the slice. <br>`end` 指针必须是 [valid] 且正确对齐的指针，指向*一个过去*最后一个元素，这样从末尾到起始指针的偏移量就是切片的长度。<br>
///
/// * The range must contain `N` consecutive properly initialized values of type `T`: <br>范围必须包含 `N` 类型 `T` 的连续正确初始化值:<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
///
/// * The memory referenced by the returned slice must not be mutated for the duration of lifetime `'a`, except inside an `UnsafeCell`. <br>返回的切片引用的内存在生命周期 `'a` 期间不得更改，除非在 `UnsafeCell` 内部。<br>
///
/// * The total length of the range must be no larger than `isize::MAX`. <br>范围的总长度不得大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// Note that a range created from [`slice::as_ptr_range`] fulfills these requirements. <br>请注意，从 [`slice::as_ptr_range`] 创建的范围满足这些要求。<br>
///
/// # Caveat
///
/// The lifetime for the returned slice is inferred from its usage. <br>从使用中可以推断出返回切片的生命周期。<br>
/// To prevent accidental misuse, it's suggested to tie the lifetime to whichever source lifetime is safe in the context, such as by providing a helper function taking the lifetime of a host value for the slice, or by explicit annotation. <br>为防止意外滥用，建议将生命周期与生命周期中任何安全的来源联系起来，例如通过提供一个辅助函数，获取切片的宿主值的生命周期，或通过明确的注解法。<br>
///
///
/// # Examples
///
/// ```
/// #![feature(slice_from_ptr_range)]
///
/// use core::slice;
///
/// let x = [1, 2, 3];
/// let range = x.as_ptr_range();
///
/// unsafe {
///     assert_eq!(slice::from_ptr_range(range), &x);
/// }
/// ```
///
/// [valid]: ptr#safety
///
///
///
///
///
///
///
///
#[unstable(feature = "slice_from_ptr_range", issue = "89792")]
#[rustc_const_unstable(feature = "const_slice_from_ptr_range", issue = "89792")]
pub const unsafe fn from_ptr_range<'a, T>(range: Range<*const T>) -> &'a [T] {
    // SAFETY: the caller must uphold the safety contract for `from_ptr_range`. <br>调用者必须维护 `from_ptr_range` 的安全保证。<br>
    unsafe { from_raw_parts(range.start, range.end.sub_ptr(range.start)) }
}

/// Performs the same functionality as [`from_ptr_range`], except that a mutable slice is returned. <br>执行与 [`from_ptr_range`] 相同的功能，除了返回一个不合法的切片。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * The `start` pointer of the range must be a [valid] and properly aligned pointer to the first element of a slice. <br>范围的 `start` 指针必须是 [valid] 并正确对齐指向切片的第一个元素的指针。<br>
///
/// * The `end` pointer must be a [valid] and properly aligned pointer to *one past* the last element, such that the offset from the end to the start pointer is the length of the slice. <br>`end` 指针必须是 [valid] 且正确对齐的指针，指向*一个过去*最后一个元素，这样从末尾到起始指针的偏移量就是切片的长度。<br>
///
///
/// * The range must contain `N` consecutive properly initialized values of type `T`: <br>范围必须包含 `N` 类型 `T` 的连续正确初始化值:<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
///
/// * The memory referenced by the returned slice must not be accessed through any other pointer (not derived from the return value) for the duration of lifetime `'a`. <br>在生命周期 `'a` 的持续时间内，不得通过任何其他指针 (不是从返回值派生) 访问返回的切片引用的内存。<br>
///   Both read and write accesses are forbidden. <br>读取和写入访问均被禁止。<br>
///
/// * The total length of the range must be no larger than `isize::MAX`. <br>范围的总长度不得大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// Note that a range created from [`slice::as_mut_ptr_range`] fulfills these requirements. <br>请注意，从 [`slice::as_mut_ptr_range`] 创建的范围满足这些要求。<br>
///
/// # Examples
///
/// ```
/// #![feature(slice_from_ptr_range)]
///
/// use core::slice;
///
/// let mut x = [1, 2, 3];
/// let range = x.as_mut_ptr_range();
///
/// unsafe {
///     assert_eq!(slice::from_mut_ptr_range(range), &mut [1, 2, 3]);
/// }
/// ```
///
/// [valid]: ptr#safety
///
///
///
///
#[unstable(feature = "slice_from_ptr_range", issue = "89792")]
#[rustc_const_unstable(feature = "const_slice_from_mut_ptr_range", issue = "89792")]
pub const unsafe fn from_mut_ptr_range<'a, T>(range: Range<*mut T>) -> &'a mut [T] {
    // SAFETY: the caller must uphold the safety contract for `from_mut_ptr_range`. <br>调用者必须维护 `from_mut_ptr_range` 的安全保证。<br>
    unsafe { from_raw_parts_mut(range.start, range.end.sub_ptr(range.start)) }
}
