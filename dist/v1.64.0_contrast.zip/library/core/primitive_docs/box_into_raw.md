../std/boxed/struct.Box.html#method.into_raw
