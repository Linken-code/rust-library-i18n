#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-safe reference-counting pointers. <br>线程安全的引用计数指针。<br>
//!
//! See the [`Arc<T>`][Arc] documentation for more details. <br>有关更多详细信息，请参见 [`Arc<T>`][Arc] 文档。<br>

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
#[cfg(not(no_global_oom_handling))]
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
#[cfg(not(no_global_oom_handling))]
use core::mem::size_of_val;
use core::mem::{self, align_of_val_raw};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::panic::{RefUnwindSafe, UnwindSafe};
use core::pin::Pin;
use core::ptr::{self, NonNull};
#[cfg(not(no_global_oom_handling))]
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release};

#[cfg(not(no_global_oom_handling))]
use crate::alloc::handle_alloc_error;
#[cfg(not(no_global_oom_handling))]
use crate::alloc::{box_free, WriteCloneIntoRaw};
use crate::alloc::{AllocError, Allocator, Global, Layout};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
#[cfg(not(no_global_oom_handling))]
use crate::string::String;
#[cfg(not(no_global_oom_handling))]
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// A soft limit on the amount of references that may be made to an `Arc`. <br>对 `Arc` 的引用数量的软限制。<br>
///
/// Going above this limit will abort your program (although not necessarily) at _exactly_ `MAX_REFCOUNT + 1` references. <br>超过此限制将在 _exactly_ `MAX_REFCOUNT + 1` 引用处终止程序 (尽管不一定)。<br>
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer does not support memory fences. <br>ThreadSanitizer 不支持内存栅栏。<br>
// To avoid false positive reports in Arc / Weak implementation use atomic loads for synchronization instead. <br>为避免在 Arc/Weak 实现中出现误报，请使用原子负载进行同步。<br>
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// A thread-safe reference-counting pointer. <br>线程安全的引用计数指针。<br> 'Arc' stands for 'Atomically Reference Counted'. <br>`Arc` 代表原子引用计数。<br>
///
/// The type `Arc<T>` provides shared ownership of a value of type `T`, allocated in the heap. <br>`Arc<T>` 类型提供了在堆中分配的 `T` 类型值的共享所有权。<br> Invoking [`clone`][clone] on `Arc` produces a new `Arc` instance, which points to the same allocation on the heap as the source `Arc`, while increasing a reference count. <br>在 `Arc` 上调用 [`clone`][clone] 会生成一个新的 `Arc` 实例，该实例指向堆上与源 `Arc` 相同的分配，同时增加了引用计数。<br>
/// When the last `Arc` pointer to a given allocation is destroyed, the value stored in that allocation (often referred to as "inner value") is also dropped. <br>当指向给定分配的最后一个 `Arc` 指针被销毁时，存储在该分配中的值 (通常称为 "内部值") 也将被丢弃。<br>
///
/// Shared references in Rust disallow mutation by default, and `Arc` is no exception: you cannot generally obtain a mutable reference to something inside an `Arc`. <br>默认情况下，Rust 中的共享引用不允许可变的，`Arc` 也不例外：您通常无法获得 `Arc` 内部内容的可变引用。<br> If you need to mutate through an `Arc`, use [`Mutex`][mutex], [`RwLock`][rwlock], or one of the [`Atomic`][atomic] types. <br>如果需要通过 `Arc` 进行可变的，请使用 [`Mutex`][mutex]，[`RwLock`][rwlock] 或 [`Atomic`][atomic] 类型之一。<br>
///
/// ## Thread Safety <br>线程安全<br>
///
/// Unlike [`Rc<T>`], `Arc<T>` uses atomic operations for its reference counting. <br>与 [`Rc<T>`] 不同，`Arc<T>` 使用原子操作进行引用计数。<br> This means that it is thread-safe. <br>这意味着它是线程安全的。<br> The disadvantage is that atomic operations are more expensive than ordinary memory accesses. <br>缺点是原子操作比普通的内存访问更昂贵。<br> If you are not sharing reference-counted allocations between threads, consider using [`Rc<T>`] for lower overhead. <br>如果您不共享线程之间的引用计数分配，请考虑使用 [`Rc<T>`] 来降低开销。<br>
/// [`Rc<T>`] is a safe default, because the compiler will catch any attempt to send an [`Rc<T>`] between threads. <br>[`Rc<T>`] 是一个安全的默认值，因为编译器会捕获在线程之间发送 [`Rc<T>`] 的任何尝试。<br>
/// However, a library might choose `Arc<T>` in order to give library consumers more flexibility. <br>但是，一个库可能会选择 `Arc<T>`，以便为库的消费者提供更大的灵活性。<br>
///
/// `Arc<T>` will implement [`Send`] and [`Sync`] as long as the `T` implements [`Send`] and [`Sync`]. <br>只要 `T` 实现 [`Send`] 和 [`Sync`]，`Arc<T>` 就会实现 [`Send`] 和 [`Sync`]。<br>
/// Why can't you put a non-thread-safe type `T` in an `Arc<T>` to make it thread-safe? <br>为什么不能在 `Arc<T>` 中放置非线程安全类型 `T` 使其成为线程安全的？<br> This may be a bit counter-intuitive at first: after all, isn't the point of `Arc<T>` thread safety? <br>起初这可能有点违反直觉：毕竟，`Arc<T>` 的重点不就是线程安全吗？<br> The key is this: `Arc<T>` makes it thread safe to have multiple ownership of the same data, but it  doesn't add thread safety to its data. <br>关键在于: `Arc<T>` 使具有同一数据的多个所有权成为线程安全的，但并未为其数据增加线程安全。<br>
///
/// Consider <code>Arc<[RefCell\<T>]></code>. <br>考虑 <code>Arc<[RefCell\<T>]></code>。<br>
/// [`RefCell<T>`] isn't [`Sync`], and if `Arc<T>` was always [`Send`], <code>Arc<[RefCell\<T>]></code> would be as well. <br>[`RefCell<T>`] 不是 [`Sync`]，如果 `Arc<T>` 总是 [`Send`]，那么 <code>Arc<[RefCell\<T>]></code> 也是。<br>
/// But then we'd have a problem: <br>但是然后我们会遇到一个问题：<br>
/// [`RefCell<T>`] is not thread safe; <br>[`RefCell<T>`] 不是线程安全的；<br> it keeps track of the borrowing count using non-atomic operations. <br>它使用非原子操作来跟踪借用计数。<br>
///
/// In the end, this means that you may need to pair `Arc<T>` with some sort of [`std::sync`] type, usually [`Mutex<T>`][mutex]. <br>最后，这意味着您可能需要将 `Arc<T>` 与某种 [`std::sync`] 类型 (通常为 [`Mutex<T>`][mutex]) 配对。<br>
///
/// ## Breaking cycles with `Weak` <br>`Weak` 的中断循环<br>
///
/// The [`downgrade`][downgrade] method can be used to create a non-owning [`Weak`] pointer. <br>[`downgrade`][downgrade] 方法可用于创建非所有者 [`Weak`] 指针。<br> A [`Weak`] pointer can be [`upgrade`][upgrade]d to an `Arc`, but this will return [`None`] if the value stored in the allocation has already been dropped. <br>[`Weak`] 指针可以 [`upgrade`][upgrade] 为 `Arc`，但如果存储在分配中的值已经被丢弃，这将返回 [`None`]。<br>
/// In other words, `Weak` pointers do not keep the value inside the allocation alive; <br>换句话说，`Weak` 指针不会使分配内部的值保持活动状态。<br> however, they *do* keep the allocation (the backing store for the value) alive. <br>然而，它们确实使分配（值的后备存储）保持活动状态。<br>
///
/// A cycle between `Arc` pointers will never be deallocated. <br>`Arc` 指针之间的循环将永远不会被释放。<br>
/// For this reason, [`Weak`] is used to break cycles. <br>因此，[`Weak`] 用于中断循环。<br> For example, a tree could have strong `Arc` pointers from parent nodes to children, and [`Weak`] pointers from children back to their parents. <br>例如，一棵树可能具有从父节点到子节点的强 `Arc` 指针，以及从子节点返回到其父节点的 [`Weak`] 指针。<br>
///
/// # Cloning references <br>克隆引用<br>
///
/// Creating a new reference from an existing reference-counted pointer is done using the `Clone` trait implemented for [`Arc<T>`][Arc] and [`Weak<T>`][Weak]. <br>使用为 [`Arc<T>`][Arc] 和 [`Weak<T>`][Weak] 实现的 `Clone` trait 从现有的引用计数指针创建新的引用。<br>
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // The two syntaxes below are equivalent. <br>以下两种语法是等效的。<br>
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, and foo are all Arcs that point to the same memory location <br>a、b 和 foo 都是指向同一内存位置的 Arc<br>
/// ```
///
/// ## `Deref` behavior <br>`Deref` 行为<br>
///
/// `Arc<T>` automatically dereferences to `T` (via the [`Deref`][deref] trait), so you can call `T`'s methods on a value of type `Arc<T>`. <br>`Arc<T>` 自动取消对 `T` 的引用 (通过 [`Deref`][deref] trait)，因此您可以在类型为 `Arc<T>` 的值上调用 `T` 的方法。<br> To avoid name clashes with `T`'s methods, the methods of `Arc<T>` itself are associated functions, called using [fully qualified syntax]: <br>为了避免与 `T` 的方法名称冲突，`Arc<T>` 本身的方法是关联函数，使用 [完全限定语法][fully qualified syntax] 调用：<br>
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// let my_weak = Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`'s implementations of traits like `Clone` may also be called using fully qualified syntax. <br>`Arc<T>` 也可以使用完全限定语法来调用诸如 `Clone` 之类的 traits 实现。<br>
/// Some people prefer to use fully qualified syntax, while others prefer using method-call syntax. <br>有些人喜欢使用完全限定的语法，而另一些人则喜欢使用方法调用语法。<br>
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Method-call syntax <br>方法调用语法<br>
/// let arc2 = arc.clone();
/// // Fully qualified syntax <br>完全限定的语法<br>
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] does not auto-dereference to `T`, because the inner value may have already been dropped. <br>[`Weak<T>`][Weak] 不会自动解引用到 `T`，因为内部值可能已经被丢弃了。<br>
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [RefCell\<T>]: core::cell::RefCell
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Sharing some immutable data between threads: <br>在线程之间共享一些不可变数据：<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Note that we **do not** run these tests here. <br>请注意，我们 **不要** 在此处运行这些测试。<br>
// The windows builders get super unhappy if a thread outlives the main thread and then exits at the same time (something deadlocks) so we just avoid this entirely by not running these tests. <br>如果某个线程超过主线程，然后同时退出 (发生死锁)，则 windows 构建器会感到非常不满意，因此我们只是通过不运行这些测试来完全避免这种情况。<br>
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{five:?}");
///     });
/// }
/// ```
///
/// Sharing a mutable [`AtomicUsize`]: <br>共享可变的 [`AtomicUsize`]：<br>
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize "sync::atomic::AtomicUsize"
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{v:?}");
///     });
/// }
/// ```
///
/// See the [`rc` documentation][rc_examples] for more examples of reference counting in general. <br>有关更多一般引用计数示例，请参见 [`rc` 文档][rc_examples]。<br>
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[stable(feature = "catch_unwind", since = "1.9.0")]
impl<T: RefUnwindSafe + ?Sized> UnwindSafe for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    unsafe fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` is a version of [`Arc`] that holds a non-owning reference to the managed allocation. <br>`Weak` 是 [`Arc`] 的一个版本，它持有对托管分配的非所有权引用。<br>
/// The allocation is accessed by calling [`upgrade`] on the `Weak` pointer, which returns an <code>[Option]<[Arc]\<T>></code>. <br>通过在 `Weak` 指针上调用 [`upgrade`] 来访问分配，它返回一个 <code>[Option]<[Arc]\<T>></code>。<br>
///
/// Since a `Weak` reference does not count towards ownership, it will not prevent the value stored in the allocation from being dropped, and `Weak` itself makes no guarantees about the value still being present. <br>由于 `Weak` 引用不计入所有权，因此它不会防止存储在分配中的值被丢弃，并且 `Weak` 本身不保证该值仍然存在。<br>
///
/// Thus it may return [`None`] when [`upgrade`]d. <br>因此，当 [`upgrade`] 时，它可能返回 [`None`]。<br>
/// Note however that a `Weak` reference *does* prevent the allocation itself (the backing store) from being deallocated. <br>但是请注意，`Weak` 引用 *确实* 会阻止分配本身 (后备存储) 被释放。<br>
///
/// A `Weak` pointer is useful for keeping a temporary reference to the allocation managed by [`Arc`] without preventing its inner value from being dropped. <br>`Weak` 指针可用于保持对 [`Arc`] 管理的分配的临时引用，而又不会阻止其内部值被丢弃。<br>
/// It is also used to prevent circular references between [`Arc`] pointers, since mutual owning references would never allow either [`Arc`] to be dropped. <br>它也用于防止 [`Arc`] 指针之间的循环引用，因为相互拥有引用将永远不允许丢弃 [`Arc`]。<br>
/// For example, a tree could have strong [`Arc`] pointers from parent nodes to children, and `Weak` pointers from children back to their parents. <br>例如，一棵树可以具有从父节点到子节点的强 [`Arc`] 指针，以及从子节点到其父节点的 `Weak` 指针。<br>
///
/// The typical way to obtain a `Weak` pointer is to call [`Arc::downgrade`]. <br>获取 `Weak` 指针的典型方法是调用 [`Arc::downgrade`]。<br>
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // This is a `NonNull` to allow optimizing the size of this type in enums, but it is not necessarily a valid pointer. <br>这是一个 `NonNull`，允许在枚举中优化此类型的大小，但它不一定是有效的指针。<br>
    //
    // `Weak::new` sets this to `usize::MAX` so that it doesn’t need to allocate space on the heap. <br>`Weak::new` 将它设置为 `usize::MAX`，这样它就不需要在堆上分配空间。<br>
    // That's not a value a real pointer will ever have because RcBox has alignment at least 2. <br>这不是真正的指针所具有的值，因为 RcBox 的对齐方式至少为 2。<br>
    // This is only possible when `T: Sized`; <br>仅当 `T: Sized` 时才有可能。<br> unsized `T` never dangle. <br>未定义大小的 `T` 永远不会悬垂。<br>
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// This is repr(C) to future-proof against possible field-reordering, which would interfere with otherwise safe [into|from]_raw() of transmutable inner types. <br>这是 repr(C) 为了防止未来可能的字段重新排序，否则可能会干扰可安全转换的内部类型的 _raw () 的安全性。<br>
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // the value usize::MAX acts as a sentinel for temporarily "locking" the ability to upgrade weak pointers or downgrade strong ones; <br>值 usize::MAX 充当临时 "locking" 升级弱指针或降级强指针的能力的标记。<br> this is used to avoid races in `make_mut` and `get_mut`. <br>这用于避免在 `make_mut` 和 `get_mut` 中发生争夺。<br>
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Constructs a new `Arc<T>`. <br>创建一个新的 `Arc<T>`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Start the weak pointer count as 1 which is the weak pointer that's held by all the strong pointers (kinda), see std/rc.rs for more info <br>将弱指针计数开始为 1，这是所有强指针 (kinda) 所持有的弱指针，有关更多信息，请参见 std/rc.rs。<br>
        //
        let x: Box<_> = Box::new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        });
        unsafe { Self::from_inner(Box::leak(x).into()) }
    }

    /// Constructs a new `Arc<T>` while giving you a `Weak<T>` to the allocation, to allow you to construct a `T` which holds a weak pointer to itself. <br>创建一个新的 `Arc<T>`，同时给您一个分配的 `Weak<T>`，以允许您创建一个 `T`，它持有一个指向自身的弱指针。<br>
    ///
    /// Generally, a structure circularly referencing itself, either directly or indirectly, should not hold a strong reference to itself to prevent a memory leak. <br>通常，直接或间接循环引用自身的结构体不应该对自身持有强引用以防止内存泄漏。<br>
    /// Using this function, you get access to the weak pointer during the initialization of `T`, before the `Arc<T>` is created, such that you can clone and store it inside the `T`. <br>使用这个函数，您可以在 `T` 的初始化过程中，在 `Arc<T>` 创建之前访问弱指针，这样您就可以将它克隆并存储在 `T` 中。<br>
    ///
    /// `new_cyclic` first allocates the managed allocation for the `Arc<T>`, then calls your closure, giving it a `Weak<T>` to this allocation, and only afterwards completes the construction of the `Arc<T>` by placing the `T` returned from your closure into the allocation. <br>`new_cyclic` 先给 `Arc<T>` 分配托管分配，然后调用您的闭包，给这个分配一个 `Weak<T>`，然后再把您的闭包返回的 `T` 放入分配中，完成 `Arc<T>` 的构建。<br>
    ///
    ///
    /// Since the new `Arc<T>` is not fully-constructed until `Arc<T>::new_cyclic` returns, calling [`upgrade`] on the weak reference inside your closure will fail and result in a `None` value. <br>由于新的 `Arc<T>` 在 `Arc<T>::new_cyclic` 返回之前尚未完全构造，因此在闭包内的弱引用上调用 [`upgrade`] 将失败并导致 `None` 值。<br>
    ///
    /// # Panics
    ///
    /// If `data_fn` panics, the panic is propagated to the caller, and the temporary [`Weak<T>`] is dropped normally. <br>如果 `data_fn` 发生 panic，panic 会传播给调用者，而临时的 [`Weak<T>`] 会被正常丢弃。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # #![allow(dead_code)]
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Gadget {
    ///     me: Weak<Gadget>,
    /// }
    ///
    /// impl Gadget {
    ///     /// Construct a reference counted Gadget. <br>创建一个引用计数的 Gadget。<br>
    ///     fn new() -> Arc<Self> {
    ///         // `me` is a `Weak<Gadget>` pointing at the new allocation of the `Arc` we're constructing. <br>`me` 是指向我们正在构建的 `Arc` 的新分配的 `Weak<Gadget>`。<br>
    /////
    ///         Arc::new_cyclic(|me| {
    ///             // Create the actual struct here. <br>在此处创建实际的结构体。<br>
    ///             Gadget { me: me.clone() }
    ///         })
    ///     }
    ///
    ///     /// Return a reference counted pointer to Self. <br>返回一个指向 Self 的引用计数指针。<br>
    ///     fn me(&self) -> Arc<Self> {
    ///         self.me.upgrade().unwrap()
    ///     }
    /// }
    /// ```
    /// [`upgrade`]: Weak::upgrade
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "arc_new_cyclic", since = "1.60.0")]
    pub fn new_cyclic<F>(data_fn: F) -> Arc<T>
    where
        F: FnOnce(&Weak<T>) -> T,
    {
        // Construct the inner in the "uninitialized" state with a single weak reference. <br>在未初始化状态下用一个弱引用建造内部。<br>
        //
        let uninit_ptr: NonNull<_> = Box::leak(Box::new(ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        }))
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // It's important we don't give up ownership of the weak pointer, or else the memory might be freed by the time `data_fn` returns. <br>重要的是我们不要放弃弱指针的所有权，否则在 `data_fn` 返回时可能会释放内存。<br>
        // If we really wanted to pass ownership, we could create an additional weak pointer for ourselves, but this would result in additional updates to the weak reference count which might not be necessary otherwise. <br>如果我们真的想传递所有权，则可以为我们自己创建一个额外的弱指针，但这将导致对弱引用计数的其他更新，否则可能没有必要。<br>
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Now we can properly initialize the inner value and turn our weak reference into a strong reference. <br>现在我们可以正确地初始化内部值，并将我们的弱引用变成强引用。<br>
        //
        let strong = unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // The above write to the data field must be visible to any threads which observe a non-zero strong count. <br>上面对数据字段的写操作对于任何观察到非零强引用计数的线程都必须可见。<br>
            // Therefore we need at least "Release" ordering in order to synchronize with the `compare_exchange_weak` in `Weak::upgrade`. <br>因此，我们至少需要 "Release" 排序才能与 `Weak::upgrade` 中的 `compare_exchange_weak` 同步。<br>
            //
            // "Acquire" ordering is not required. <br>无需排序 "Acquire"。<br>
            // When considering the possible behaviours of `data_fn` we only need to look at what it could do with a reference to a non-upgradeable `Weak`: <br>考虑 `data_fn` 的可能行为时，我们只需要看一下对不可升级的 `Weak` 的引用可以做什么：<br>
            //
            // - It can *clone* the `Weak`, increasing the weak reference count. <br>它可以克隆 `Weak`，从而增加弱引用计数。<br>
            // - It can drop those clones, decreasing the weak reference count (but never to zero). <br>它可以丢弃这些克隆，从而减少弱引用计数 (但永远不会为零)。<br>
            //
            // These side effects do not impact us in any way, and no other side effects are possible with safe code alone. <br>这些副作用不会以任何方式影响我们，仅凭安全代码就不可能有其他副作用。<br>
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");

            Arc::from_inner(init_ptr)
        };

        // Strong references should collectively own a shared weak reference, so don't run the destructor for our old weak reference. <br>强引用应该共同拥有一个共享的弱引用，所以不要为我们的旧弱引用运行析构函数。<br>
        //
        mem::forget(weak);
        strong
    }

    /// Constructs a new `Arc` with uninitialized contents. <br>创建一个具有未初始化内容的新 `Arc`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Arc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constructs a new `Arc` with uninitialized contents, with the memory being filled with `0` bytes. <br>创建一个具有未初始化内容的新 `Arc`，并用 `0` 字节填充内存。<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constructs a new `Pin<Arc<T>>`. <br>创建一个新的 `Pin<Arc<T>>`。<br>
    /// If `T` does not implement `Unpin`, then `data` will be pinned in memory and unable to be moved. <br>如果 `T` 未实现 `Unpin`，则 `data` 将被固定在内存中并且无法移动。<br>
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "pin", since = "1.33.0")]
    #[must_use]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Constructs a new `Pin<Arc<T>>`, return an error if allocation fails. <br>创建一个新的 `Pin<Arc<T>>`，如果分配失败则返回错误。<br>
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_pin(data: T) -> Result<Pin<Arc<T>>, AllocError> {
        unsafe { Ok(Pin::new_unchecked(Arc::try_new(data)?)) }
    }

    /// Constructs a new `Arc<T>`, returning an error if allocation fails. <br>创建一个新的 `Arc<T>`，如果分配失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Start the weak pointer count as 1 which is the weak pointer that's held by all the strong pointers (kinda), see std/rc.rs for more info <br>将弱指针计数开始为 1，这是所有强指针 (kinda) 所持有的弱指针，有关更多信息，请参见 std/rc.rs。<br>
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        unsafe { Ok(Self::from_inner(Box::leak(x).into())) }
    }

    /// Constructs a new `Arc` with uninitialized contents, returning an error if allocation fails. <br>构造具有未初始化内容的新 `Arc`，如果分配失败，则返回错误。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Arc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constructs a new `Arc` with uninitialized contents, with the memory being filled with `0` bytes, returning an error if allocation fails. <br>创建一个具有未初始化内容的新 `Arc`，并用 `0` 字节填充内存，如果分配失败，则返回错误。<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Returns the inner value, if the `Arc` has exactly one strong reference. <br>如果 `Arc` 正好有一个强引用，则返回内部值。<br>
    ///
    /// Otherwise, an [`Err`] is returned with the same `Arc` that was passed in. <br>否则，返回的 [`Err`] 将与传入的 `Arc` 相同。<br>
    ///
    ///
    /// This will succeed even if there are outstanding weak references. <br>即使存在突出的弱引用，此操作也将成功。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Make a weak pointer to clean up the implicit strong-weak reference <br>做出弱指针以清除隐式的强 - 弱引用<br>
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Constructs a new atomically reference-counted slice with uninitialized contents. <br>创建一个具有未初始化内容的新原子引用计数切片。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// let data = Arc::get_mut(&mut values).unwrap();
    /// data[0].write(1);
    /// data[1].write(2);
    /// data[2].write(3);
    ///
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Constructs a new atomically reference-counted slice with uninitialized contents, with the memory being filled with `0` bytes. <br>创建一个具有未初始化内容的新原子引用计数切片，内存中填充 `0` 字节。<br>
    ///
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage of this method. <br>有关正确和不正确使用此方法的示例，请参见 [`MaybeUninit::zeroed`][zeroed]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converts to `Arc<T>`. <br>转换为 `Arc<T>`。<br>
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`], it is up to the caller to guarantee that the inner value really is in an initialized state. <br>与 [`MaybeUninit::assume_init`] 一样，由调用者负责确保内部值确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes immediate undefined behavior. <br>在内容尚未完全初始化时调用此方法会立即导致未定义的行为。<br>
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// Arc::get_mut(&mut five).unwrap().write(5);
    ///
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        unsafe { Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast()) }
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converts to `Arc<[T]>`. <br>转换为 `Arc<[T]>`。<br>
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`], it is up to the caller to guarantee that the inner value really is in an initialized state. <br>与 [`MaybeUninit::assume_init`] 一样，由调用者负责确保内部值确实处于初始化状态。<br>
    ///
    /// Calling this when the content is not yet fully initialized causes immediate undefined behavior. <br>在内容尚未完全初始化时调用此方法会立即导致未定义的行为。<br>
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// // Deferred initialization: <br>延迟初始化：<br>
    /// let data = Arc::get_mut(&mut values).unwrap();
    /// data[0].write(1);
    /// data[1].write(2);
    /// data[2].write(3);
    ///
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consumes the `Arc`, returning the wrapped pointer. <br>消耗 `Arc`，返回包装的指针。<br>
    ///
    /// To avoid a memory leak the pointer must be converted back to an `Arc` using [`Arc::from_raw`]. <br>为避免内存泄漏，必须使用 [`Arc::from_raw`] 将指针转换回 `Arc`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[must_use = "losing the pointer will leak memory"]
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Provides a raw pointer to the data. <br>为数据提供裸指针。<br>
    ///
    /// The counts are not affected in any way and the `Arc` is not consumed. <br>计数不会受到任何影响，并且不会消耗 `Arc`。<br>
    /// The pointer is valid for as long as there are strong counts in the `Arc`. <br>只要 `Arc` 中有大量计数，指针就有效。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[must_use]
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: This cannot go through Deref::deref or RcBoxPtr::inner because this is required to retain raw/mut provenance such that e.g. <br>这不能通过 Deref::deref 或 RcBoxPtr::inner，因为这是保留 raw/mut 出处所必需的，例如<br>
        // `get_mut` can write through the pointer after the Rc is recovered through `from_raw`. <br>通过 `from_raw` 恢复 Rc 后，`get_mut` 可以通过指针写入。<br>
        //
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Constructs an `Arc<T>` from a raw pointer. <br>从裸指针构造 `Arc<T>`。<br>
    ///
    /// The raw pointer must have been previously returned by a call to [`Arc<U>::into_raw`][into_raw] where `U` must have the same size and alignment as `T`. <br>裸指针必须事先由调用返回到 [`Arc<U>::into_raw`][into_raw]，其中 `U` 的大小和对齐方式必须与 `T` 相同。<br>
    /// This is trivially true if `U` is `T`. <br>如果 `U` 是 `T`，这是很简单的。<br>
    /// Note that if `U` is not `T` but has the same size and alignment, this is basically like transmuting references of different types. <br>请注意，如果 `U` 不是 `T`，但是具有相同的大小和对齐方式，则基本上就像对不同类型的引用进行转换一样。<br>
    /// See [`mem::transmute`][transmute] for more information on what restrictions apply in this case. <br>有关在这种情况下适用的限制的更多信息，请参见 [`mem::transmute`][transmute]。<br>
    ///
    /// The user of `from_raw` has to make sure a specific value of `T` is only dropped once. <br>`from_raw` 的用户必须确保 `T` 的特定值仅被丢弃一次。<br>
    ///
    /// This function is unsafe because improper use may lead to memory unsafety, even if the returned `Arc<T>` is never accessed. <br>此函数不安全，因为使用不当可能会导致内存不安全，即使从未访问返回的 `Arc<T>` 也是如此。<br>
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Convert back to an `Arc` to prevent leak. <br>转换回 `Arc` 以防止泄漏。<br>
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Further calls to `Arc::from_raw(x_ptr)` would be memory-unsafe. <br>进一步调用 `Arc::from_raw(x_ptr)` 将导致内存不安全。<br>
    /// }
    ///
    /// // The memory was freed when `x` went out of scope above, so `x_ptr` is now dangling! <br>当 `x` 超出上面的作用域时，其内存将被释放，所以 `x_ptr` 现在悬垂了！<br>
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Reverse the offset to find the original ArcInner. <br>反转偏移量以找到原始的 ArcInner。<br>
            let arc_ptr = ptr.byte_sub(offset) as *mut ArcInner<T>;

            Self::from_ptr(arc_ptr)
        }
    }

    /// Creates a new [`Weak`] pointer to this allocation. <br>创建一个指向该分配的新 [`Weak`] 指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[must_use = "this returns a new `Weak` pointer, \
                  without modifying the original `Arc`"]
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // This Relaxed is OK because we're checking the value in the CAS below. <br>可以使用 `Relaxed`，因为我们正在检查以下 CAS 中的值。<br>
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // check if the weak counter is currently "locked"; <br>检查弱引用计数当前是否为 "locked"；<br> if so, spin. <br>如果是这样，spin。<br>
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: this code currently ignores the possibility of overflow into usize::MAX; <br>该代码当前忽略了溢出到 usize::MAX 的可能性；<br> in general both Rc and Arc need to be adjusted to deal with overflow. <br>通常，Rc 和 Arc 都需要进行调整以应对溢出。<br>
            //
            //

            // Unlike with Clone(), we need this to be an Acquire read to synchronize with the write coming from `is_unique`, so that the events prior to that write happen before this read. <br>与 Clone() 不同，我们需要将其作为 Acquire 读取，以与来自 `is_unique` 的写入同步，以便该写入之前的事件在此读取之前发生。<br>
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Make sure we do not create a dangling Weak <br>确保我们不会创建悬垂的 Weak<br>
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Gets the number of [`Weak`] pointers to this allocation. <br>获取指向该分配的 [`Weak`] 指针的数量。<br>
    ///
    /// # Safety
    ///
    /// This method by itself is safe, but using it correctly requires extra care. <br>此方法本身是安全的，但正确使用它需要格外小心。<br>
    /// Another thread can change the weak count at any time, including potentially between calling this method and acting on the result. <br>另一个线程可以随时更改弱引用计数，包括潜在地在调用此方法与对结果进行操作之间。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // This assertion is deterministic because we haven't shared the `Arc` or `Weak` between threads. <br>此断言是确定性的，因为我们尚未在线程之间共享 `Arc` 或 `Weak`。<br>
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(Acquire);
        // If the weak count is currently locked, the value of the count was 0 just before taking the lock. <br>如果弱引用计数当前处于锁定状态，则在进行锁定之前，该计数的值为 0。<br>
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Gets the number of strong (`Arc`) pointers to this allocation. <br>获取指向此分配的强 (`Arc`) 指针的数量。<br>
    ///
    /// # Safety
    ///
    /// This method by itself is safe, but using it correctly requires extra care. <br>此方法本身是安全的，但正确使用它需要格外小心。<br>
    /// Another thread can change the strong count at any time, including potentially between calling this method and acting on the result. <br>另一个线程可以随时更改强引用计数，包括潜在地在调用此方法与对结果进行操作之间。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // This assertion is deterministic because we haven't shared the `Arc` between threads. <br>此断言是确定性的，因为我们尚未在线程之间共享 `Arc`。<br>
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(Acquire)
    }

    /// Increments the strong reference count on the `Arc<T>` associated with the provided pointer by one. <br>与提供的指针关联的 `Arc<T>` 上的强引用计数加 1。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have been obtained through `Arc::into_raw`, and the associated `Arc` instance must be valid (i.e. <br>指针必须已经通过 `Arc::into_raw` 获得，并且关联的 `Arc` 实例必须有效 (即<br>
    /// the strong count must be at least 1) for the duration of this method. <br>在此方法的持续时间内，强引用计数必须至少为 1)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // This assertion is deterministic because we haven't shared the `Arc` between threads. <br>此断言是确定性的，因为我们尚未在线程之间共享 `Arc`。<br>
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Retain Arc, but don't touch refcount by wrapping in ManuallyDrop <br>保留 Arc，但不要通过包装在 ManuallyDrop 中来接触引用计数<br>
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Now increase refcount, but don't drop new refcount either <br>现在增加引用计数，但也不要丢弃新的引用计数<br>
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrements the strong reference count on the `Arc<T>` associated with the provided pointer by one. <br>将与提供的指针关联的 `Arc<T>` 上的强引用计数减 1。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have been obtained through `Arc::into_raw`, and the associated `Arc` instance must be valid (i.e. <br>指针必须已经通过 `Arc::into_raw` 获得，并且关联的 `Arc` 实例必须有效 (即<br>
    /// the strong count must be at least 1) when invoking this method. <br>调用此方法时，强引用计数必须至少为 1)。<br>
    /// This method can be used to release the final `Arc` and backing storage, but **should not** be called after the final `Arc` has been released. <br>此方法可用于释放最终的 `Arc` 和后备存储，但不应在最终的 `Arc` 释放后调用。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Those assertions are deterministic because we haven't shared the `Arc` between threads. <br>这些断言是确定性的，因为我们尚未在线程之间共享 `Arc`。<br>
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // This unsafety is ok because while this arc is alive we're guaranteed that the inner pointer is valid. <br>这种不安全的做法是可以的，因为当此 Arc 处于活动状态时，我们可以保证内部指针是有效的。<br>
        // Furthermore, we know that the `ArcInner` structure itself is `Sync` because the inner data is `Sync` as well, so we're ok loaning out an immutable pointer to these contents. <br>此外，我们知道 `ArcInner` 结构体本身就是 `Sync`，因为内部数据也是 `Sync`，所以我们可以借用一个不可变的指针指向这些内容。<br>
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non-inlined part of `drop`. <br>`drop` 的非内联部分。<br>
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Destroy the data at this time, even though we must not free the box allocation itself (there might still be weak pointers lying around). <br>此时的数据，即使我们不能释放 box 分配本身 (可能仍然存在弱指针)。<br>
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Drop the weak ref collectively held by all strong references <br>丢弃所有强引用共同持有的弱引用<br>
        drop(Weak { ptr: self.ptr });
    }

    /// Returns `true` if the two `Arc`s point to the same allocation (in a vein similar to [`ptr::eq`]). <br>如果两个 Arc 指向相同的分配 (类似于 [`ptr::eq`])，则返回 `true`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq "ptr::eq"
    #[inline]
    #[must_use]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Allocates an `ArcInner<T>` with sufficient space for a possibly-unsized inner value where the value has the layout provided. <br>为 `ArcInner<T>` 分配足够的空间，以容纳可能未定义大小的内部值，其中该值具有提供的布局。<br>
    ///
    /// The function `mem_to_arcinner` is called with the data pointer and must return back a (potentially fat)-pointer for the `ArcInner<T>`. <br>函数 `mem_to_arcinner` 用数据指针调用，并且必须返回 `ArcInner<T>` 的 (可能是胖的) 指针。<br>
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculate layout using the given value layout. <br>使用给定的值布局计算布局。<br>
        // Previously, layout was calculated on the expression `&*(ptr as *const ArcInner<T>)`, but this created a misaligned reference (see #54908). <br>以前，在表达式 `&*(ptr as *const ArcInner<T>)` 上计算布局，但是这会产生未对齐的引用 (请参见 #54908)。<br>
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allocates an `ArcInner<T>` with sufficient space for a possibly-unsized inner value where the value has the layout provided, returning an error if allocation fails. <br>为 `ArcInner<T>` 分配足够的空间，以容纳可能未定义大小的内部值 (该值具有提供的布局)，如果分配失败，则返回错误。<br>
    ///
    ///
    /// The function `mem_to_arcinner` is called with the data pointer and must return back a (potentially fat)-pointer for the `ArcInner<T>`. <br>函数 `mem_to_arcinner` 用数据指针调用，并且必须返回 `ArcInner<T>` 的 (可能是胖的) 指针。<br>
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculate layout using the given value layout. <br>使用给定的值布局计算布局。<br>
        // Previously, layout was calculated on the expression `&*(ptr as *const ArcInner<T>)`, but this created a misaligned reference (see #54908). <br>以前，在表达式 `&*(ptr as *const ArcInner<T>)` 上计算布局，但是这会产生未对齐的引用 (请参见 #54908)。<br>
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialize the ArcInner <br>初始化 ArcInner<br>
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Allocates an `ArcInner<T>` with sufficient space for an unsized inner value. <br>为 `ArcInner<T>` 分配足够的空间以容纳未定义大小的内部值。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Allocate for the `ArcInner<T>` using the given value. <br>使用给定的值分配 `ArcInner<T>`。<br>
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| mem.with_metadata_of(ptr as *mut ArcInner<T>),
            )
        }
    }

    #[cfg(not(no_global_oom_handling))]
    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copy value as bytes <br>将值复制为字节<br>
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Free the allocation without dropping its contents <br>释放分配而不丢弃其内容<br>
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Allocates an `ArcInner<[T]>` with the given length. <br>用给定的长度分配 `ArcInner<[T]>`。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copy elements from slice into newly allocated Arc<\[T\]> <br>将切片中的元素复制到新分配的 Arc<\[T\]> 中<br>
    ///
    /// Unsafe because the caller must either take ownership or bind `T: Copy`. <br>不安全，因为调用者必须拥有所有权或绑定 `T: Copy`。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Constructs an `Arc<[T]>` from an iterator known to be of a certain size. <br>从已知为一定大小的迭代器构造 `Arc<[T]>`。<br>
    ///
    /// Behavior is undefined should the size be wrong. <br>如果大小错误，则行为是未定义的。<br>
    #[cfg(not(no_global_oom_handling))]
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic guard while cloning T elements. <br>在克隆 T 元素时 panic 守卫。<br>
        // In the event of a panic, elements that have been written into the new ArcInner will be dropped, then the memory freed. <br>如果出现 panic，将丢弃已写入新 ArcInner 的元素，然后释放内存。<br>
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer to first element <br>指向第一个元素的指针<br>
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // All clear. <br>全部清空。<br> Forget the guard so it doesn't free the new ArcInner. <br>忘记守卫，这样它就不会释放新的 ArcInner。<br>
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait used for `From<&[T]>`. <br>用于 `From<&[T]>` 使用的专业化 trait。<br>
#[cfg(not(no_global_oom_handling))]
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

#[cfg(not(no_global_oom_handling))]
impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

#[cfg(not(no_global_oom_handling))]
impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Makes a clone of the `Arc` pointer. <br>克隆 `Arc` 指针。<br>
    ///
    /// This creates another pointer to the same allocation, increasing the strong reference count. <br>这将创建另一个指向相同分配的指针，从而增加了强引用计数。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Using a relaxed ordering is alright here, as knowledge of the original reference prevents other threads from erroneously deleting the object. <br>这里可以使用宽松的排序，因为了解原始引用可以防止其他线程错误地删除对象。<br>
        //
        // As explained in the [Boost documentation][1], Increasing the reference counter can always be done with memory_order_relaxed: New references to an object can only be formed from an existing reference, and passing an existing reference from one thread to another must already provide any required synchronization. <br>如 [Boost 文档][1] 中所述，可以始终通过 memory_order_relaxed 来完成增加引用计数器的操作：对对象的新引用只能由现有引用形成，并且将现有引用从一个线程传递到另一个线程必须已经提供了所需的同步。<br>
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // However we need to guard against massive refcounts in case someone is `mem::forget`ing Arcs. <br>但是，，我们需要防止大量的引用计数，以防有人 `mem::forget` 了 Arc。<br>
        // If we don't do this the count can overflow and users will use-after free. <br>如果我们不这样做，那么计数可能会溢出，并且用户将随心所欲的使用。<br>
        // This branch will never be taken in any realistic program. <br>在任何实际程序中都不会采用此分支。<br>
        // We abort because such a program is incredibly degenerate, and we don't care to support it. <br>我们终止是因为这样的程序简直令人难以置信的退化，并且我们不在乎支持它。<br>
        //
        // This check is not 100% water-proof: we error when the refcount grows beyond `isize::MAX`. <br>此检查并非 100% 防水: 当引用计数超过 `isize::MAX` 时，我们会出错。<br>
        // But we do that check *after* having done the increment, so there is a chance here that the worst already happened and we actually do overflow the `usize` counter. <br>但是我们在完成增量之后 * 进行检查，所以这里有可能最坏的情况已经发生，我们实际上确实溢出了 `usize` 计数器。<br>
        //
        // However, that requires the counter to grow from `isize::MAX` to `usize::MAX` between the increment above and the `abort` below, which seems exceedingly unlikely. <br>但是，这需要计数器在上面的增量和下面的 `abort` 之间从 `isize::MAX` 增长到 `usize::MAX`，这似乎极不可能。<br>
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        unsafe { Self::from_inner(self.ptr) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Makes a mutable reference into the given `Arc`. <br>对给定的 `Arc` 进行可变引用。<br>
    ///
    /// If there are other `Arc` pointers to the same allocation, then `make_mut` will [`clone`] the inner value to a new allocation to ensure unique ownership. <br>如果有其他 `Arc` 指针指向同一分配，则 `make_mut` 会将内部值 [`clone`] 到新分配以确保唯一的所有权。<br>
    /// This is also referred to as clone-on-write. <br>这也称为写时克隆。<br>
    ///
    /// However, if there are no other `Arc` pointers to this allocation, but some [`Weak`] pointers, then the [`Weak`] pointers will be dissociated and the inner value will not be cloned. <br>但是，如果没有其他 `Arc` 指针指向这个分配，而是一些 [`Weak`] 指针，那么 [`Weak`] 指针将被分离，内部值不会被克隆。<br>
    ///
    ///
    /// See also [`get_mut`], which will fail rather than cloning the inner value or dissociating [`Weak`] pointers. <br>另请参见 [`get_mut`]，它将失败而不是克隆内部值或分离 [`Weak`] 指针。<br>
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Won't clone anything <br>不会克隆任何东西<br>
    /// let mut other_data = Arc::clone(&data); // Won't clone inner data <br>不会克隆内部数据<br>
    /// *Arc::make_mut(&mut data) += 1;         // Clones inner data <br>克隆内部数据<br>
    /// *Arc::make_mut(&mut data) += 1;         // Won't clone anything <br>不会克隆任何东西<br>
    /// *Arc::make_mut(&mut other_data) *= 2;   // Won't clone anything <br>不会克隆任何东西<br>
    ///
    /// // Now `data` and `other_data` point to different allocations. <br>现在，`data` 和 `other_data` 指向不同的分配。<br>
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pointers will be dissociated: <br>[`Weak`] 指针将被分离:<br>
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(75);
    /// let weak = Arc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Arc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Note that we hold both a strong reference and a weak reference. <br>请注意，我们同时拥有强引用和弱引用。<br>
        // Thus, releasing our strong reference only will not, by itself, cause the memory to be deallocated. <br>因此，仅释放我们强大的引用本身不会导致内存被释放。<br>
        //
        // Use Acquire to ensure that we see any writes to `weak` that happen before release writes (i.e., decrements) to `strong`. <br>使用 Acquire 来确保我们看到在发行版对 `strong` 进行写入 (即递减) 之前发生的对 `weak` 的写入。<br>
        // Since we hold a weak count, there's no chance the ArcInner itself could be deallocated. <br>由于数量不多，因此 ArcInner 本身不可能被释放。<br>
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Another strong pointer exists, so we must clone. <br>存在另一个强大的指针，因此我们必须进行克隆。<br>
            // Pre-allocate memory to allow writing the cloned value directly. <br>预分配内存以允许直接写入克隆的值。<br>
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxed suffices in the above because this is fundamentally an optimization: we are always racing with weak pointers being dropped. <br>上面的 relaxed 足以满足需要，因为这从根本上来说是一种优化：我们总是在与被丢弃的弱指针赛跑。<br>
            // Worst case, we end up allocated a new Arc unnecessarily. <br>最坏的情况是，我们最终不必要地分配了新的 Arc。<br>
            //

            // We removed the last strong ref, but there are additional weak refs remaining. <br>我们删除了最后一个强引用，但还剩下其他弱引用。<br>
            // We'll move the contents to a new Arc, and invalidate the other weak refs. <br>我们将内容移动到新的 Arc，并使其他弱引用无效。<br>
            //

            // Note that it is not possible for the read of `weak` to yield usize::MAX (i.e., locked), since the weak count can only be locked by a thread with a strong reference. <br>请注意，读取 `weak` 不可能产生 usize::MAX (即已锁定)，因为弱引用计数只能由带有强引用的线程锁定。<br>
            //
            //

            // Materialize our own implicit weak pointer, so that it can clean up the ArcInner as needed. <br>实现我们自己的隐式弱指针，以便可以根据需要清理 ArcInner。<br>
            //
            let _weak = Weak { ptr: this.ptr };

            // Can just steal the data, all that's left is Weaks <br>只能窃取数据，剩下的就是 Weaks<br>
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // We were the sole reference of either kind; <br>我们是任何一种形式的唯一引用。<br> bump back up the strong ref count. <br>增加强引用计数。<br>
            //
            this.inner().strong.store(1, Release);
        }

        // As with `get_mut()`, the unsafety is ok because our reference was either unique to begin with, or became one upon cloning the contents. <br>与 `get_mut()` 一样，这种不安全性也是可以的，因为我们的引用一开始是唯一的，或者在克隆内容时成为一体。<br>
        //
        unsafe { Self::get_mut_unchecked(this) }
    }

    /// If we have the only reference to `T` then unwrap it. <br>如果我们有 `T` 的唯一引用，那就打开它。<br> Otherwise, clone `T` and return the clone. <br>否则，克隆 `T` 并返回克隆。<br>
    ///
    /// Assuming `arc_t` is of type `Arc<T>`, this function is functionally equivalent to `(*arc_t).clone()`, but will avoid cloning the inner value where possible. <br>假设 `arc_t` 是 `Arc<T>` 类型，这个函数在功能上等同于 `(*arc_t).clone()`，但会尽可能避免克隆内部值。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_unwrap_or_clone)]
    /// # use std::{ptr, sync::Arc};
    /// let inner = String::from("test");
    /// let ptr = inner.as_ptr();
    ///
    /// let arc = Arc::new(inner);
    /// let inner = Arc::unwrap_or_clone(arc);
    /// // The inner value was not cloned <br>内部值没有被克隆<br>
    /// assert!(ptr::eq(ptr, inner.as_ptr()));
    ///
    /// let arc = Arc::new(inner);
    /// let arc2 = arc.clone();
    /// let inner = Arc::unwrap_or_clone(arc);
    /// // Because there were 2 references, we had to clone the inner value. <br>因为有两个引用，我们不得不克隆内部值。<br>
    /// assert!(!ptr::eq(ptr, inner.as_ptr()));
    /// // `arc2` is the last reference, so when we unwrap it we get back the original `String`. <br>`arc2` 是最后一个引用，所以当我们展开它时，我们会得到原来的 `String`。<br>
    /////
    /// let inner = Arc::unwrap_or_clone(arc2);
    /// assert!(ptr::eq(ptr, inner.as_ptr()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "arc_unwrap_or_clone", issue = "93610")]
    pub fn unwrap_or_clone(this: Self) -> T {
        Arc::try_unwrap(this).unwrap_or_else(|arc| (*arc).clone())
    }
}

impl<T: ?Sized> Arc<T> {
    /// Returns a mutable reference into the given `Arc`, if there are no other `Arc` or [`Weak`] pointers to the same allocation. <br>如果没有其他 `Arc` 或 [`Weak`] 指向相同分配的指针，则返回给定 `Arc` 的可变引用。<br>
    ///
    ///
    /// Returns [`None`] otherwise, because it is not safe to mutate a shared value. <br>否则返回 [`None`]，因为更改共享值并不安全。<br>
    ///
    /// See also [`make_mut`][make_mut], which will [`clone`][clone] the inner value when there are other `Arc` pointers. <br>另见 [`make_mut`][make_mut]，当有其他 `Arc` 指针时，它将 [`clone`][clone] 内部值。<br>
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // This unsafety is ok because we're guaranteed that the pointer returned is the *only* pointer that will ever be returned to T. <br>这种不安全性是可以的，因为我们保证返回的指针是将永远返回到 T 的 *only* 指针。<br>
            // Our reference count is guaranteed to be 1 at this point, and we required the Arc itself to be `mut`, so we're returning the only possible reference to the inner data. <br>此时，我们的引数保证为 1，并且我们要求 Arc 本身为 `mut`，因此我们将唯一可能的引数返回给内部数据。<br>
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Returns a mutable reference into the given `Arc`, without any check. <br>将变量引用返回给定的 `Arc`，而不进行任何检查。<br>
    ///
    /// See also [`get_mut`], which is safe and does appropriate checks. <br>另请参见 [`get_mut`]，它是安全的并且进行适当的检查。<br>
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Any other `Arc` or [`Weak`] pointers to the same allocation must not be dereferenced for the duration of the returned borrow. <br>在返回的借用期间，不得解引用其他指向相同分配的 `Arc` 或 [`Weak`] 指针。<br>
    ///
    /// This is trivially the case if no such pointers exist, for example immediately after `Arc::new`. <br>如果不存在这样的指针 (例如紧接在 `Arc::new` 之后)，则情况很简单。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // We are careful to *not* create a reference covering the "count" fields, as this would alias with concurrent access to the reference counts (e.g. <br>我们非常小心 *不要* 创建一个覆盖 "count" 字段的引用，因为这会导致对引用计数的并发访问 (例如<br>
        // by `Weak`). <br>由 `Weak`)。<br>
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determine whether this is the unique reference (including weak refs) to the underlying data. <br>确定这是否是底层数据的唯一引用 (包括弱引用)。<br>
    ///
    ///
    /// Note that this requires locking the weak ref count. <br>请注意，这需要锁定弱引用计数。<br>
    fn is_unique(&mut self) -> bool {
        // lock the weak pointer count if we appear to be the sole weak pointer holder. <br>如果我们似乎是唯一的弱指针持有者，则锁定弱指针计数。<br>
        //
        // The acquire label here ensures a happens-before relationship with any writes to `strong` (in particular in `Weak::upgrade`) prior to decrements of the `weak` count (via `Weak::drop`, which uses release). <br>在这里，获取标签可确保在 `weak` 计数递减之前 (通过使用释放的 `Weak::drop`) 与对 `strong` (特别是 `Weak::upgrade`) 的任何写操作发生事前关联。<br>
        // If the upgraded weak ref was never dropped, the CAS here will fail so we do not care to synchronize. <br>如果升级后的弱引用从未被丢弃，这里的 CAS 将失败，所以我们不关心同步。<br>
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // This needs to be an `Acquire` to synchronize with the decrement of the `strong` counter in `drop` -- the only access that happens when any but the last reference is being dropped. <br>它必须是 `Acquire`，才能与 `drop` 中 `strong` 计数器的减量同步 - 唯一的访问是在丢弃最后一个引用以外的任何内容时发生的。<br>
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // The release write here synchronizes with a read in `downgrade`, effectively preventing the above read of `strong` from happening after the write. <br>此处的释放写入与 `downgrade` 中的读取同步，从而有效防止了 `strong` 的上述读取在写入后发生。<br>
            //
            //
            self.inner().weak.store(1, Release); // release the lock <br>释放锁<br>
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Drops the `Arc`. <br>丢弃 `Arc`。<br>
    ///
    /// This will decrement the strong reference count. <br>这将减少强引用计数。<br>
    /// If the strong reference count reaches zero then the only other references (if any) are [`Weak`], so we `drop` the inner value. <br>如果强引用计数达到零，那么唯一的其他引用 (如果有) 是 [`Weak`]，因此我们将 `drop` 作为内部值。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Doesn't print anything <br>不打印任何东西<br>
    /// drop(foo2);   // Prints "dropped!" <br>打印 "dropped!"<br>
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Because `fetch_sub` is already atomic, we do not need to synchronize with other threads unless we are going to delete the object. <br>因为 `fetch_sub` 已经是原子的，所以除非要删除对象，否则不需要与其他线程同步。<br>
        // This same logic applies to the below `fetch_sub` to the `weak` count. <br>此逻辑适用于以下 `fetch_sub` 至 `weak` 计数。<br>
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // This fence is needed to prevent reordering of use of the data and deletion of the data. <br>需要使用该栅栏来防止对数据使用进行重新排序和删除数据。<br>
        // Because it is marked `Release`, the decreasing of the reference count synchronizes with this `Acquire` fence. <br>因为标记为 `Release`，引用计数的减少与这个 `Acquire` 栅栏同步。<br>
        // This means that use of the data happens before decreasing the reference count, which happens before this fence, which happens before the deletion of the data. <br>这意味着数据的使用发生在减少引用计数之前，这发生在此栅栏之前，发生在删除数据之前。<br>
        //
        // As explained in the [Boost documentation][1], <br>如 [Boost 文档][1] 中所述，<br>
        //
        // > It is important to enforce any possible access to the object in one <br>在一个对象中强制执行对对象的任何可能的访问很重要<br>
        // > thread (through an existing reference) to *happen before* deleting <br>*删除之前将线程 (通过现有引用) 连接到* happen<br>
        // > the object in a different thread. <br>该对象位于另一个线程中。<br> This is achieved by a "release" <br>这是通过 "release" 实现的<br>
        // > operation after dropping a reference (any access to the object <br>丢弃引用 (对对象的任何访问权限) 后的操作<br>
        // > through this reference must obviously happened before), and an <br>通过此引用显然必须发生在之前)，并且<br>
        // > "acquire" operation before deleting the object. <br>删除对象前的 "acquire" 操作。<br>
        //
        // In particular, while the contents of an Arc are usually immutable, it's possible to have interior writes to something like a Mutex<T>. <br>特别是，虽然 Arc 的内容通常是不可变的，但可以对 Mutex<T> 之类的内容进行内部写入。<br>
        // Since a Mutex is not acquired when it is deleted, we can't rely on its synchronization logic to make writes in thread A visible to a destructor running in thread B. <br>由于在删除互斥锁时未获得互斥锁，因此我们不能依靠其同步逻辑使线程 A 中的析构函数看到线程 A 中的写入。<br>
        //
        //
        // Also note that the Acquire fence here could probably be replaced with an Acquire load, which could improve performance in highly-contended situations. <br>还要注意，这里的 Acquire 栅栏可能会被 Acquire 负载所取代，这可以提高在激烈竞争的情况下的性能。<br> See [2]. <br>请参见 [2]。<br>
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    /// Attempt to downcast the `Arc<dyn Any + Send + Sync>` to a concrete type. <br>尝试将 `Arc<dyn Any + Send + Sync>` 转换为具体类型。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync,
    {
        if (*self).is::<T>() {
            unsafe {
                let ptr = self.ptr.cast::<ArcInner<T>>();
                mem::forget(self);
                Ok(Arc::from_inner(ptr))
            }
        } else {
            Err(self)
        }
    }

    /// Downcasts the `Arc<dyn Any + Send + Sync>` to a concrete type. <br>将 `Arc<dyn Any + Send + Sync>` 向下转换为具体类型。<br>
    ///
    /// For a safe alternative see [`downcast`]. <br>有关安全的替代方案，请参见 [`downcast`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// let x: Arc<dyn Any + Send + Sync> = Arc::new(1_usize);
    ///
    /// unsafe {
    ///     assert_eq!(*x.downcast_unchecked::<usize>(), 1);
    /// }
    /// ```
    ///
    /// # Safety
    ///
    /// The contained value must be of type `T`. <br>包含的值必须是 `T` 类型。<br>
    /// Calling this method with the incorrect type is *undefined behavior*. <br>使用不正确的类型调用此方法是 *未定义的行为*。<br>
    ///
    ///
    /// [`downcast`]: Self::downcast
    #[inline]
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    pub unsafe fn downcast_unchecked<T>(self) -> Arc<T>
    where
        T: Any + Send + Sync,
    {
        unsafe {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Arc::from_inner(ptr)
        }
    }
}

impl<T> Weak<T> {
    /// Constructs a new `Weak<T>`, without allocating any memory. <br>创建一个新的 `Weak<T>`，而不分配任何内存。<br>
    /// Calling [`upgrade`] on the return value always gives [`None`]. <br>在返回值上调用 [`upgrade`] 总是得到 [`None`]。<br>
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    #[rustc_const_unstable(feature = "const_weak_new", issue = "95091", reason = "recently added")]
    #[must_use]
    pub const fn new() -> Weak<T> {
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr::invalid_mut::<ArcInner<T>>(usize::MAX)) } }
    }
}

/// Helper type to allow accessing the reference counts without making any assertions about the data field. <br>帮助程序类型，允许访问引用计数而无需对数据字段进行任何声明。<br>
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Returns a raw pointer to the object `T` pointed to by this `Weak<T>`. <br>返回对此 `Weak<T>` 指向的对象 `T` 的裸指针。<br>
    ///
    /// The pointer is valid only if there are some strong references. <br>该指针仅在有一些强引用时才有效。<br>
    /// The pointer may be dangling, unaligned or even [`null`] otherwise. <br>指针可能是悬垂的，未对齐的，甚至是 [`null`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Both point to the same object <br>两者都指向同一个对象<br>
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // The strong here keeps it alive, so we can still access the object. <br>这里的强项使它保持活动状态，因此我们仍然可以访问该对象。<br>
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // But not any more. <br>但是没有更多了。<br>
    /// // We can do weak.as_ptr(), but accessing the pointer would lead to undefined behaviour. <br>我们可以执行 weak.as_ptr()，但是访问指针将导致未定义的行为。<br>
    /// // assert_eq!("hello", unsafe { &*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null "ptr::null"
    #[must_use]
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // If the pointer is dangling, we return the sentinel directly. <br>如果指针悬垂，我们将直接返回哨兵。<br>
            // This cannot be a valid payload address, as the payload is at least as aligned as ArcInner (usize). <br>这不能是有效的有效载荷地址，因为有效载荷至少与 ArcInner (usize) 对齐。<br>
            ptr as *const T
        } else {
            // SAFETY: if is_dangling returns false, then the pointer is dereferenceable. <br>如果 is_dangling 返回 false，则该指针是可解引用的。<br>
            // The payload may be dropped at this point, and we have to maintain provenance, so use raw pointer manipulation. <br>有效载荷可能会在此时被丢弃，所以我们必须维护出处，因此请使用裸指针操作。<br>
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consumes the `Weak<T>` and turns it into a raw pointer. <br>消耗 `Weak<T>` 并将其转换为裸指针。<br>
    ///
    /// This converts the weak pointer into a raw pointer, while still preserving the ownership of one weak reference (the weak count is not modified by this operation). <br>这会将弱指针转换为裸指针，同时仍保留一个弱引用的所有权 (此操作不会修改弱引用计数)。<br>
    /// It can be turned back into the `Weak<T>` with [`from_raw`]. <br>可以将其转换回带有 [`from_raw`] 的 `Weak<T>`。<br>
    ///
    /// The same restrictions of accessing the target of the pointer as with [`as_ptr`] apply. <br>与 [`as_ptr`] 一样，访问指针目标的限制也适用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converts a raw pointer previously created by [`into_raw`] back into `Weak<T>`. <br>将先前由 [`into_raw`] 创建的裸指针转换回 `Weak<T>`。<br>
    ///
    /// This can be used to safely get a strong reference (by calling [`upgrade`] later) or to deallocate the weak count by dropping the `Weak<T>`. <br>这可以用于安全地获得强引用 (稍后调用 [`upgrade`]) 或通过丢弃 `Weak<T>` 来分配弱引用计数。<br>
    ///
    /// It takes ownership of one weak reference (with the exception of pointers created by [`new`], as these don't own anything; the method still works on them). <br>它拥有一个弱引用的所有权 (由 [`new`] 创建的指针除外，因为它们不拥有任何东西; 该方法仍适用于它们)。<br>
    ///
    /// # Safety
    ///
    /// The pointer must have originated from the [`into_raw`] and must still own its potential weak reference. <br>指针必须起源于 [`into_raw`]，并且仍然必须拥有其潜在的弱引用。<br>
    ///
    /// It is allowed for the strong count to be 0 at the time of calling this. <br>调用时允许强引用计数为 0。<br>
    /// Nevertheless, this takes ownership of one weak reference currently represented as a raw pointer (the weak count is not modified by this operation) and therefore it must be paired with a previous call to [`into_raw`]. <br>不过，这需要当前表示为裸指针的弱引用的所有权 (该操作不会修改弱引用计数)，因此必须与 [`into_raw`] 的先前调用配对。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement the last weak count. <br>减少最后一个弱引用计数。<br>
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // See Weak::as_ptr for context on how the input pointer is derived. <br>有关如何派生输入指针的上下文，请参见 Weak::as_ptr。<br>

        let ptr = if is_dangling(ptr as *mut T) {
            // This is a dangling Weak. <br>这是悬垂的 Weak。<br>
            ptr as *mut ArcInner<T>
        } else {
            // Otherwise, we're guaranteed the pointer came from a nondangling Weak. <br>否则，我们保证指针来自无悬挂的弱。<br>
            // SAFETY: data_offset is safe to call, as ptr references a real (potentially dropped) T. <br>data_offset 可以安全调用，因为 ptr 引用了一个真实的 (可能已丢弃) 的 T。<br>
            let offset = unsafe { data_offset(ptr) };
            // Thus, we reverse the offset to get the whole RcBox. <br>因此，我们反转偏移量以获得整个 RcBox。<br>
            // SAFETY: the pointer originated from a Weak, so this offset is safe. <br>指针源自 Weak，因此此偏移量是安全的。<br>
            unsafe { ptr.byte_sub(offset) as *mut ArcInner<T> }
        };

        // SAFETY: we now have recovered the original Weak pointer, so can create the Weak. <br>我们现在已经恢复了原始的弱指针，因此可以创建弱指针。<br>
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Attempts to upgrade the `Weak` pointer to an [`Arc`], delaying dropping of the inner value if successful. <br>尝试将 `Weak` 指针升级到 [`Arc`]，如果成功，则延迟内部值的丢弃。<br>
    ///
    ///
    /// Returns [`None`] if the inner value has since been dropped. <br>如果内部值已经被丢弃，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destroy all strong pointers. <br>销毁所有强指针。<br>
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[must_use = "this returns a new `Arc`, \
                  without modifying the original weak pointer"]
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // We use a CAS loop to increment the strong count instead of a fetch_add as this function should never take the reference count from zero to one. <br>我们使用 CAS 循环而不是 fetch_add 来增加强引用计数，因为此函数绝不应该将引用计数从零变为一。<br>
        //
        //
        let inner = self.inner()?;

        // Relaxed load because any write of 0 that we can observe leaves the field in a permanently zero state (so a "stale" read of 0 is fine), and any other value is confirmed via the CAS below. <br>放宽负载，因为我们可以观察到的任何写入 0 都使该字段处于永久零状态 (因此 "stale" 读取为 0 很好)，并且可以通过下面的 CAS 确认其他任何值。<br>
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // See comments in `Arc::clone` for why we do this (for `mem::forget`). <br>请参见 `Arc::clone` 中的注释以了解执行此操作的原因 (对于 `mem::forget`)。<br>
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed is fine for the failure case because we don't have any expectations about the new state. <br>对于失败案例，放宽是可以的，因为我们对新状态没有任何期望。<br>
            // Acquire is necessary for the success case to synchronise with `Arc::new_cyclic`, when the inner value can be initialized after `Weak` references have already been created. <br>如果可以在创建 `Weak` 引用后初始化内部值，则成功案例需要与 `Arc::new_cyclic` 同步进行获取。<br>
            // In that case, we expect to observe the fully initialized value. <br>在这种情况下，我们希望观察到完全初始化的值。<br>
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(unsafe { Arc::from_inner(self.ptr) }), // null checked above <br>在上面检查为空<br>
                Err(old) => n = old,
            }
        }
    }

    /// Gets the number of strong (`Arc`) pointers pointing to this allocation. <br>获取指向该分配的强 (`Arc`) 指针的数量。<br>
    ///
    /// If `self` was created using [`Weak::new`], this will return 0. <br>如果 `self` 是使用 [`Weak::new`] 创建的，则将返回 0。<br>
    #[must_use]
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(Acquire) } else { 0 }
    }

    /// Gets an approximation of the number of `Weak` pointers pointing to this allocation. <br>获取指向该分配的 `Weak` 指针的数量的近似值。<br>
    ///
    /// If `self` was created using [`Weak::new`], or if there are no remaining strong pointers, this will return 0. <br>如果 `self` 是使用 [`Weak::new`] 创建的，或者没有剩余的强指针，则它将返回 0。<br>
    ///
    /// # Accuracy
    ///
    /// Due to implementation details, the returned value can be off by 1 in either direction when other threads are manipulating any `Arc`s or `Weak`s pointing to the same allocation. <br>由于实现细节，当其他线程正在操作任何指向相同分配的 `Arc` 或 `Weak` 时，返回值可以在任一方向上关闭 1。<br>
    ///
    ///
    ///
    ///
    #[must_use]
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(Acquire);
                let strong = inner.strong.load(Acquire);
                if strong == 0 {
                    0
                } else {
                    // Since we observed that there was at least one strong pointer after reading the weak count, we know that the implicit weak reference (present whenever any strong references are alive) was still around when we observed the weak count, and can therefore safely subtract it. <br>由于我们在读取弱引用计数后观察到至少有一个强指针，因此我们知道在观察弱引用计数时隐含的弱引用 (在任何强引用活着时都存在) 仍然存在，因此可以安全地减去它。<br>
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Returns `None` when the pointer is dangling and there is no allocated `ArcInner`, (i.e., when this `Weak` was created by `Weak::new`). <br>当指针悬垂并且没有分配的 `ArcInner` 时 (即，当 `Weak` 由 `Weak::new` 创建时)，返回 `None`。<br>
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // We are careful to *not* create a reference covering the "data" field, as the field may be mutated concurrently (for example, if the last `Arc` is dropped, the data field will be dropped in-place). <br>我们小心 *不要* 创建引用 "data" 字段的引用，因为该字段可能会同时发生可变的 (例如，如果最后一个 `Arc` 被丢弃，则数据字段将被原地丢弃)。<br>
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returns `true` if the two `Weak`s point to the same allocation (similar to [`ptr::eq`]), or if both don't point to any allocation (because they were created with `Weak::new()`). <br>如果两个 `Weak' 指向相同的分配 (类似于 [`ptr::eq`])，或者两个都不指向任何分配 (因为它们是用 `Weak::new()` 创建的)，则返回 `true`。<br>
    ///
    ///
    /// # Notes
    ///
    /// Since this compares pointers it means that `Weak::new()` will equal each other, even though they don't point to any allocation. <br>由于这将比较指针，这意味着 `Weak::new()` 将彼此相等，即使它们不指向任何分配。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparing `Weak::new`. <br>比较 `Weak::new`。<br>
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq "ptr::eq"
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Makes a clone of the `Weak` pointer that points to the same allocation. <br>克隆 `Weak` 指针，该指针指向相同的分配。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // See comments in Arc::clone() for why this is relaxed. <br>请参阅 Arc::clone() 中的注释，以了解放宽此限制的原因。<br>
        // This can use a fetch_add (ignoring the lock) because the weak count is only locked where are *no other* weak pointers in existence. <br>这可以使用 fetch_add (忽略锁定)，因为弱引用计数仅在存在 *no 其他* 弱指针的地方被锁定。<br>
        //
        // (So we can't be running this code in that case). <br>(因此，在这种情况下，我们无法运行此代码)。<br>
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // See comments in Arc::clone() for why we do this (for mem::forget). <br>有关为何执行此操作 (对于 mem::forget)，请参见 Arc::clone () 中的注释。<br>
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constructs a new `Weak<T>`, without allocating memory. <br>创建一个新的 `Weak<T>`，而不分配内存。<br>
    /// Calling [`upgrade`] on the return value always gives [`None`]. <br>在返回值上调用 [`upgrade`] 总是得到 [`None`]。<br>
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Weak<T> {
    /// Drops the `Weak` pointer. <br>丢弃 `Weak` 指针。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Doesn't print anything <br>不打印任何东西<br>
    /// drop(foo);        // Prints "dropped!" <br>打印 "dropped!"<br>
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // If we find out that we were the last weak pointer, then its time to deallocate the data entirely. <br>如果我们发现自己是最后一个弱指针，那么它就该完全释放数据了。<br> See the discussion in Arc::drop() about the memory orderings <br>参见 Arc::drop () 中有关内存顺序的讨论。<br>
        //
        // It's not necessary to check for the locked state here, because the weak count can only be locked if there was precisely one weak ref, meaning that drop could only subsequently run ON that remaining weak ref, which can only happen after the lock is released. <br>这里没有必要检查锁定状态，因为弱引用计数只能在恰好有一个弱引用的情况下才被锁定，这意味着丢弃只能随后在剩余的弱引用上运行，这只能在释放锁定之后发生。<br>
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// We're doing this specialization here, and not as a more general optimization on `&T`, because it would otherwise add a cost to all equality checks on refs. <br>我们在这里进行这种专门化，而不是对 `&T` 进行更一般的优化，因为否则会增加对引用的所有相等性检查的成本。<br>
/// We assume that `Arc`s are used to store large values, that are slow to clone, but also heavy to check for equality, causing this cost to pay off more easily. <br>我们假设使用 Arc 来存储较大的值，克隆的速度较慢，但用于检查相等性的值较大，从而使此成本更容易得到回报。<br>
///
/// It's also more likely to have two `Arc` clones, that point to the same value, than two `&T`s. <br>与两个 `&T` 相比，它更有可能具有两个指向相同值的 `Arc` 克隆。<br>
///
/// We can only do this when `T: Eq` as a `PartialEq` might be deliberately irreflexive. <br>仅当 `T: Eq` 作为 `PartialEq` 可能是故意的非反射时，我们才能这样做。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Equality for two `Arc`s. <br>两个 `Arc` 的相等性。<br>
    ///
    /// Two `Arc`s are equal if their inner values are equal, even if they are stored in different allocation. <br>即使两个 `Arc` 的内部值相等，即使它们存储在不同的分配中，它们也相等。<br>
    ///
    /// If `T` also implements `Eq` (implying reflexivity of equality), two `Arc`s that point to the same allocation are always equal. <br>如果 `T` 还实现了 `Eq` (暗示相等的反射性)，则指向同一分配的两个 Arc 总是相等的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Inequality for two `Arc`s. <br>两个 `Arc` 的不等式。<br>
    ///
    /// Two `Arc`s are unequal if their inner values are unequal. <br>如果两个 `Arc` 的内部值不相等，则它们是不相等的。<br>
    ///
    /// If `T` also implements `Eq` (implying reflexivity of equality), two `Arc`s that point to the same value are never unequal. <br>如果 `T` 还实现了 `Eq` (暗示相等性的反射性)，则指向相同值的两个 `Arc' 永远不会相等。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Partial comparison for two `Arc`s. <br>两个 `Arc` 的部分比较。<br>
    ///
    /// The two are compared by calling `partial_cmp()` on their inner values. <br>通过调用 `partial_cmp()` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Less-than comparison for two `Arc`s. <br>小于两个 Arc 的比较。<br>
    ///
    /// The two are compared by calling `<` on their inner values. <br>通过调用 `<` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Less than or equal to' comparison for two `Arc`s. <br>两个 `Arc` 的小于或等于比较。<br>
    ///
    /// The two are compared by calling `<=` on their inner values. <br>通过调用 `<=` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Greater-than comparison for two `Arc`s. <br>大于两个 `Arc` 的比较。<br>
    ///
    /// The two are compared by calling `>` on their inner values. <br>通过调用 `>` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Greater than or equal to' comparison for two `Arc`s. <br>两个 `Arc` 的大于或等于比较。<br>
    ///
    /// The two are compared by calling `>=` on their inner values. <br>通过调用 `>=` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparison for two `Arc`s. <br>两个 `Arc` 的比较。<br>
    ///
    /// The two are compared by calling `cmp()` on their inner values. <br>通过调用 `cmp()` 的内部值来比较两者。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Creates a new `Arc<T>`, with the `Default` value for `T`. <br>用 `T` 的 `Default` 值创建一个新的 `Arc<T>`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    /// Converts a `T` into an `Arc<T>` <br>将 `T` 转换为 `Arc<T>`<br>
    ///
    /// The conversion moves the value into a newly allocated `Arc`. <br>转换将值移动到新分配的 `Arc` 中。<br>
    /// It is equivalent to calling `Arc::new(t)`. <br>相当于调用 `Arc::new(t)`。<br>
    ///
    /// # Example
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let x = 5;
    /// let arc = Arc::new(5);
    ///
    /// assert_eq!(Arc::from(x), arc);
    /// ```
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Allocate a reference-counted slice and fill it by cloning `v`'s items. <br>分配一个引用计数的切片，并通过克隆 `v` 的项来填充它。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Allocate a reference-counted `str` and copy `v` into it. <br>分配一个引用计数的 `str` 并将 `v` 复制到其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Allocate a reference-counted `str` and copy `v` into it. <br>分配一个引用计数的 `str` 并将 `v` 复制到其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Move a boxed object to a new, reference-counted allocation. <br>将 boxed 对象移动到新的引用计数分配。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Allocate a reference-counted slice and move `v`'s items into it. <br>分配一个引用计数的切片，并将 `v` 的项移入其中。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Allow the Vec to free its memory, but not destroy its contents <br>允许 Vec 释放其内存，但不销毁其内容<br>
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    /// Create an atomically reference-counted pointer from a clone-on-write pointer by copying its content. <br>通过复制其内容，从写时克隆指针创建一个原子引用计数指针。<br>
    ///
    ///
    /// # Example
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// # use std::borrow::Cow;
    /// let cow: Cow<str> = Cow::Borrowed("eggplant");
    /// let shared: Arc<str> = Arc::from(cow);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "shared_from_str", since = "1.62.0")]
impl From<Arc<str>> for Arc<[u8]> {
    /// Converts an atomically reference-counted string slice into a byte slice. <br>将原子引用计数的字符串切片转换为字节切片。<br>
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let string: Arc<str> = Arc::from("eggplant");
    /// let bytes: Arc<[u8]> = Arc::from(string);
    /// assert_eq!("eggplant".as_bytes(), bytes.as_ref());
    /// ```
    #[inline]
    fn from(rc: Arc<str>) -> Self {
        // SAFETY: `str` has the same layout as `[u8]`. <br>`str` 与 `[u8]` 具有相同的布局。<br>
        unsafe { Arc::from_raw(Arc::into_raw(rc) as *const [u8]) }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Takes each element in the `Iterator` and collects it into an `Arc<[T]>`. <br>获取 `Iterator` 中的每个元素，并将其收集到 `Arc<[T]>` 中。<br>
    ///
    /// # Performance characteristics <br>性能特点<br>
    ///
    /// ## The general case <br>一般情况<br>
    ///
    /// In the general case, collecting into `Arc<[T]>` is done by first collecting into a `Vec<T>`. <br>在一般情况下，首先要收集到 `Vec<T>` 中来收集到 `Arc<[T]>` 中。<br> That is, when writing the following: <br>也就是说，编写以下内容时：<br>
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// this behaves as if we wrote: <br>这就像我们写的那样：<br>
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // The first set of allocations happens here. <br>第一组分配在此处发生。<br>
    ///     .into(); // A second allocation for `Arc<[T]>` happens here. <br>`Arc<[T]>` 的第二个分配在此处进行。<br>
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// This will allocate as many times as needed for constructing the `Vec<T>` and then it will allocate once for turning the `Vec<T>` into the `Arc<[T]>`. <br>这将分配构造 `Vec<T>` 所需的次数，然后分配一次，以将 `Vec<T>` 转换为 `Arc<[T]>`。<br>
    ///
    ///
    /// ## Iterators of known length <br>已知长度的迭代器<br>
    ///
    /// When your `Iterator` implements `TrustedLen` and is of an exact size, a single allocation will be made for the `Arc<[T]>`. <br>当您的 `Iterator` 实现 `TrustedLen` 且大小正确时，将为 `Arc<[T]>` 进行一次分配。<br> For example: <br>例如：<br>
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Just a single allocation happens here. <br>这里只进行一次分配。<br>
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait used for collecting into `Arc<[T]>`. <br>专门的 trait 用于收集到 `Arc<[T]>` 中。<br>
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

#[cfg(not(no_global_oom_handling))]
impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

#[cfg(not(no_global_oom_handling))]
impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // This is the case for a `TrustedLen` iterator. <br>`TrustedLen` 迭代器就是这种情况。<br>
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: We need to ensure that the iterator has an exact length and we have. <br>我们需要确保迭代器有一个精确的长度，并且我们有。<br>
                Arc::from_iter_exact(self, low)
            }
        } else {
            // TrustedLen contract guarantees that `upper_bound == `None` implies an iterator length exceeding `usize::MAX`. <br>TrustedLen 契约保证 `upper_bound == `None` 意味着迭代器长度超过 `usize::MAX`。<br>
            //
            // The default implementation would collect into a vec which would panic. <br>默认实现将收集到一个 vec 中，这将是 panic。<br>
            // Thus we panic here immediately without invoking `Vec` code. <br>因此，我们立即在此处 panic 而不调用 `Vec` 代码。<br>
            panic!("capacity overflow");
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Get the offset within an `ArcInner` for the payload behind a pointer. <br>获取指针后面有效载荷的 `ArcInner` 内的偏移量。<br>
///
/// # Safety
///
/// The pointer must point to (and have valid metadata for) a previously valid instance of T, but the T is allowed to be dropped. <br>指针必须指向 T 的先前有效实例 (并具有有效的元数据)，但是允许丢弃 T。<br>
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> usize {
    // Align the unsized value to the end of the ArcInner. <br>将未定义大小的值与 ArcInner 的末端对齐。<br>
    // Because RcBox is repr(C), it will always be the last field in memory. <br>由于 RcBox 是 repr(C)，因此它将始终是内存中的最后一个字段。<br>
    // SAFETY: since the only unsized types possible are slices, trait objects, and extern types, the input safety requirement is currently enough to satisfy the requirements of align_of_val_raw; <br>由于唯一可能的未定义大小类型是切片，trait 对象和外部类型，因此当前输入的安全要求足以满足 align_of_val_raw 的要求；<br> this is an implementation detail of the language that must not be relied upon outside of std. <br>这是 std 之外不得依赖的语言的实现细节。<br>
    //
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> usize {
    let layout = Layout::new::<ArcInner<()>>();
    layout.size() + layout.padding_needed_for(align)
}
