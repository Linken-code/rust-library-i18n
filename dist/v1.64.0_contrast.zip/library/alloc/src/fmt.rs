//! Utilities for formatting and printing `String`s. <br>用于格式化和打印 `String`s 的实用工具。<br>
//!
//! This module contains the runtime support for the [`format!`] syntax extension. <br>该模块包含对 [`format!`] 语法扩展的运行时支持。<br>
//! This macro is implemented in the compiler to emit calls to this module in order to format arguments at runtime into strings. <br>该宏在编译器中实现，以发出对该模块的调用，以便在运行时将参数格式化为字符串。<br>
//!
//! # Usage
//!
//! The [`format!`] macro is intended to be familiar to those coming from C's `printf`/`fprintf` functions or Python's `str.format` function. <br>[`format!`] 宏旨在使那些使用 C 的 `printf`/`fprintf` 函数或 Python 的 `str.format` 函数的用户熟悉。<br>
//!
//! Some examples of the [`format!`] extension are: <br>[`format!`] 扩展的一些示例是：<br>
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! let people = "Rustaceans";
//! format!("Hello {people}!");       // => "Hello Rustaceans!"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" with leading zeros <br>带前导零的 "0042"<br>
//! format!("{:#?}", (100, 200));     // => "(
//!                                   // 100,
//!                                   //       200, )"
//!                                   //
//! ```
//!
//! From these, you can see that the first argument is a format string. <br>从这些中，您可以看到第一个参数是格式字符串。<br> It is required by the compiler for this to be a string literal; <br>编译器要求它是字符串字面量；<br> it cannot be a variable passed in (in order to perform validity checking). <br>它不能是传入的变量 (以执行有效性检查)。<br>
//! The compiler will then parse the format string and determine if the list of arguments provided is suitable to pass to this format string. <br>然后，编译器将解析格式字符串，并确定所提供的参数列表是否适合传递给该格式字符串。<br>
//!
//! To convert a single value to a string, use the [`to_string`] method. <br>要将单个值转换为字符串，请使用 [`to_string`] 方法。<br> This will use the [`Display`] formatting trait. <br>这将使用 [`Display`] 格式 trait。<br>
//!
//! ## Positional parameters <br>位置参数<br>
//!
//! Each formatting argument is allowed to specify which value argument it's referencing, and if omitted it is assumed to be "the next argument". <br>每个格式化参数都可以指定它引用的值参数，如果省略，则假定它是 "下一个参数"。<br>
//! For example, the format string `{} {} {}` would take three parameters, and they would be formatted in the same order as they're given. <br>例如，格式字符串 `{} {} {}` 将带有三个参数，并且将按照给定的顺序对其进行格式化。<br>
//! The format string `{2} {1} {0}`, however, would format arguments in reverse order. <br>但是，格式字符串 `{2} {1} {0}` 将以相反的顺序格式化参数。<br>
//!
//! Things can get a little tricky once you start intermingling the two types of positional specifiers. <br>一旦开始将两种类型的位置说明符混合在一起，事情就会变得有些棘手。<br> The "next argument" specifier can be thought of as an iterator over the argument. <br>可以将 "下一个参数" 说明符可以看作是参数的迭代器。<br>
//! Each time a "next argument" specifier is seen, the iterator advances. <br>每次看到 "下一个参数" 说明符时，迭代器都会前进。<br> This leads to behavior like this: <br>这会导致这样的行为：<br>
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! The internal iterator over the argument has not been advanced by the time the first `{}` is seen, so it prints the first argument. <br>看到第一个 `{}` 时，尚未对参数进行内部迭代，因此它将打印第一个参数。<br> Then upon reaching the second `{}`, the iterator has advanced forward to the second argument. <br>然后，在到达第二个 `{}` 时，迭代器已前进到第二个参数。<br>
//! Essentially, parameters that explicitly name their argument do not affect parameters that do not name an argument in terms of positional specifiers. <br>本质上，在位置说明符方面，明确命名其参数的参数不会影响未命名参数的参数。<br>
//!
//! A format string is required to use all of its arguments, otherwise it is a compile-time error. <br>必须使用格式字符串才能使用其所有参数，否则将导致编译时错误。<br> You may refer to the same argument more than once in the format string. <br>您可能在格式字符串中多次引用同一参数。<br>
//!
//! ## Named parameters <br>命名参数<br>
//!
//! Rust itself does not have a Python-like equivalent of named parameters to a function, but the [`format!`] macro is a syntax extension that allows it to leverage named parameters. <br>Rust 本身不具有类似于 Python 的等效于函数的命名参数，但是 [`format!`] 宏是一种语法扩展，允许它利用命名参数。<br>
//! Named parameters are listed at the end of the argument list and have the syntax: <br>命名参数列在参数列表的末尾，并具有以下语法：<br>
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! For example, the following [`format!`] expressions all use named arguments: <br>例如，以下 [`format!`] 表达式都使用命名参数:<br>
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! If a named parameter does not appear in the argument list, `format!` will reference a variable with that name in the current scope. <br>如果命名参数没有出现在参数列表中，`format!` 将引用当前作用域中的同名变量。<br>
//!
//! ```
//! let argument = 2 + 2;
//! format!("{argument}");   // => "4"
//!
//! fn make_string(a: u32, b: &str) -> String {
//!     format!("{b} {a}")
//! }
//! make_string(927, "label"); // => "label 927"
//! ```
//!
//! It is not valid to put positional parameters (those without names) after arguments that have names. <br>在具有名称的参数之后放置位置参数 (那些没有名称的参数) 是无效的。<br> Like with positional parameters, it is not valid to provide named parameters that are unused by the format string. <br>与位置参数一样，提供格式字符串未使用的命名参数也是无效的。<br>
//!
//! # Formatting Parameters <br>格式化参数<br>
//!
//! Each argument being formatted can be transformed by a number of formatting parameters (corresponding to `format_spec` in [the syntax](#syntax)). <br>每个要格式化的参数都可以通过许多格式化参数进行转换 (对应于 [语法](#syntax)) 中的 `format_spec`。<br> These parameters affect the string representation of what's being formatted. <br>这些参数会影响所格式化内容的字符串表示形式。<br>
//!
//! ## Width
//!
//! ```
//! // All of these print "Hello x    !" <br>所有这些打印 "Hello x !"<br>
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! let width = 5;
//! println!("Hello {:width$}!", "x");
//! ```
//!
//! This is a parameter for the "minimum width" that the format should take up. <br>这是格式应使用的 "最小宽度" 的参数。<br>
//! If the value's string does not fill up this many characters, then the padding specified by fill/alignment will be used to take up the required space (see below). <br>如果值的字符串不能填满这么多字符，则 fill/alignment 指定的填充将用于占用所需的空间 (请参见下文)。<br>
//!
//! The value for the width can also be provided as a [`usize`] in the list of parameters by adding a postfix `$`, indicating that the second argument is a [`usize`] specifying the width. <br>通过添加后缀 `$` (表示第二个参数是指定宽度的 [`usize`])，也可以在参数列表中以 [`usize`] 的形式提供宽度值。<br>
//!
//! Referring to an argument with the dollar syntax does not affect the "next argument" counter, so it's usually a good idea to refer to arguments by position, or use named arguments. <br>使用 Dollar 语法引用参数不会影响 "下一个参数" 计数器，因此按位置引用参数或使用命名参数通常是一个好主意。<br>
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! The optional fill character and alignment is provided normally in conjunction with the [`width`](#width) parameter. <br>可选的填充字符和对齐方式通常与 [`width`](#width) 参数一起提供。<br> It must be defined before `width`, right after the `:`. <br>必须在 `width` 之前，`:` 之后定义。<br>
//! This indicates that if the value being formatted is smaller than `width` some extra characters will be printed around it. <br>这表示如果要格式化的值小于 `width`，则将在其周围打印一些额外的字符。<br>
//! Filling comes in the following variants for different alignments: <br>对于不同的对齐方式，填充有以下变体：<br>
//!
//! * `[fill]<` - the argument is left-aligned in `width` columns <br>`[fill]<` - 参数在 `width` 列中左对齐<br>
//! * `[fill]^` - the argument is center-aligned in `width` columns <br>`[fill]^` - 参数在 `width` 列中居中对齐<br>
//! * `[fill]>` - the argument is right-aligned in `width` columns <br>`[fill]>` - 参数在 `width` 列中右对齐<br>
//!
//! The default [fill/alignment](#fillalignment) for non-numerics is a space and left-aligned. <br>非数字的默认 [fill/alignment](#fillalignment) 是空格，并且左对齐。<br> The default for numeric formatters is also a space character but with right-alignment. <br>数字格式器的默认值也是空格字符，但带有右对齐。<br>
//! If the `0` flag (see below) is specified for numerics, then the implicit fill character is `0`. <br>如果为数字指定了 `0` 标志 (见下文)，则隐式填充字符为 `0`。<br>
//!
//! Note that alignment might not be implemented by some types. <br>请注意，某些类型可能不会实现对齐。<br> In particular, it is not generally implemented for the `Debug` trait. <br>特别是，对于 `Debug` trait，通常不会实现该功能。<br>
//! A good way to ensure padding is applied is to format your input, then pad this resulting string to obtain your output: <br>确保应用填充的一种好方法是格式化输入，然后填充此结果字符串以获得输出：<br>
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello   Some("hi")   !"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! These are all flags altering the behavior of the formatter. <br>这些都是更改格式化程序行为的标志。<br>
//!
//! * `+` - This is intended for numeric types and indicates that the sign should always be printed. <br>`+` - 这适用于数字类型并指示应始终打印符号。<br> Positive signs are never printed by default, and the negative sign is only printed by default for signed values. <br>默认情况下从不打印正号，默认情况下仅对有符号值打印负号。<br>
//!         This flag indicates that the correct sign (`+` or `-`) should always be printed. <br>该标志指示应始终打印正确的符号 (`+` 或 `-`)。<br>
//! * `-` - Currently not used <br>`-` - 当前未使用<br>
//! * `#` - This flag indicates that the "alternate" form of printing should be used. <br>`#` - 此标志表示应使用 "alternate" 打印形式。<br> The alternate forms are: <br>替代形式为：<br>
//!     * `#?` - pretty-print the [`Debug`] formatting (adds linebreaks and indentation) <br>`#?` - 漂亮地打印 [`Debug`] 格式 (添加换行符和缩进)<br>
//!     * `#x` - precedes the argument with a `0x` <br>`#x` - 在参数前面加上 `0x`<br>
//!     * `#X` - precedes the argument with a `0x` <br>`#X` - 在参数前面加上 `0x`<br>
//!     * `#b` - precedes the argument with a `0b` <br>`#b` - 在参数前面加上 `0b`<br>
//!     * `#o` - precedes the argument with a `0o` <br>`#o` - 在参数前面加上 `0o`<br>
//! * `0` - This is used to indicate for integer formats that the padding to `width` should both be done with a `0` character as well as be sign-aware. <br>`0` - 这用于指示对于整数格式，向 `width` 的填充应该使用 `0` 字符，并且是符号感知的。<br>
//! A format like `{:08}` would yield `00000001` for the integer `1`, while the same format would yield `-0000001` for the integer `-1`. <br>像 `{:08}` 这样的格式将为整数 `1` 产生 `00000001`，而相同格式将为整数 `-1` 产生 `-0000001`。<br>
//! Notice that the negative version has one fewer zero than the positive version. <br>请注意，负版本的零比正版本的少零。<br>
//!         Note that padding zeros are always placed after the sign (if any) and before the digits. <br>请注意，填充零总是放在符号 (如果有) 之后和数字之前。<br> When used together with the `#` flag, a similar rule applies: padding zeros are inserted after the prefix but before the digits. <br>当与 `#` 标志一起使用时，将应用类似的规则：在前缀之后但在数字之前插入填充零。<br>
//!         The prefix is included in the total width. <br>前缀包括在总宽度中。<br>
//!
//! ## Precision
//!
//! For non-numeric types, this can be considered a "maximum width". <br>对于非数字类型，可以将其视为 "最大宽度"。<br>
//! If the resulting string is longer than this width, then it is truncated down to this many characters and that truncated value is emitted with proper `fill`, `alignment` and `width` if those parameters are set. <br>如果结果字符串的长度大于此宽度，则将其截断为这么多个字符，并且如果设置了这些参数，则会使用适当的 `fill`，`alignment` 和 `width` 发出该截断的值。<br>
//!
//! For integral types, this is ignored. <br>对于整数类型，这将被忽略。<br>
//!
//! For floating-point types, this indicates how many digits after the decimal point should be printed. <br>对于浮点类型，这指示小数点后应打印多少位。<br>
//!
//! There are three possible ways to specify the desired `precision`: <br>有三种可能的方法来指定所需的 `precision`：<br>
//!
//! 1. An integer `.N`: <br>一个整数 `.N`：<br>
//!
//!    the integer `N` itself is the precision. <br>整数 `N` 本身就是精度。<br>
//!
//! 2. An integer or name followed by dollar sign `.N$`: <br>整数或名称后跟美元符号 `.N$`：<br>
//!
//!    use format *argument* `N` (which must be a `usize`) as the precision. <br>使用格式参数 `N` (必须是 `usize`) 作为精度。<br>
//!
//! 3. An asterisk `.*`: <br>星号 `.*`：<br>
//!
//!    `.*` means that this `{...}` is associated with *two* format inputs rather than one: <br>`.*` 意味着这个 `{...}` 与*两个*格式输入相关联，而不是一个:<br>
//!    - If a format string in the fashion of `{:<spec>.*}` is used, then the first input holds the `usize` precision, and the second holds the value to print. <br>如果使用 `{:<spec>.*}` 格式的字符串，则第一个输入保存 `usize` 精度，第二个输入保存要打印的值。<br>
//!    - If a format string in the fashion of `{<arg>:<spec>.*}` is used, then the `<arg>` part refers to the value to print, and the `precision` is taken like it was specified with an omitted positional parameter (`{}` instead of `{<arg>:}`). <br>如果使用 `{<arg>:<spec>.*}` 格式的字符串，则 `<arg>` 部分指的是要打印的值，并且 `precision` 被视为使用省略的位置参数指定 (`{}` 而不是 `{<arg>:}`)。<br>
//!
//! For example, the following calls all print the same thing `Hello x is 0.01000`: <br>例如，以下所有调用均打印相同的内容 `Hello x is 0.01000`：<br>
//!
//! ```
//! // Hello {arg 0 ("x")} is {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} is {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} is {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg -> arg 0 ("x")} is {second of next two args -> arg 2 (0.01) with precision specified in first of next two args -> arg 1 (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {arg 1 ("x")} is {arg 2 (0.01) with precision specified in next arg -> arg 0 (5)}
//! //
//! println!("Hello {1} is {2:.*}",  5, "x", 0.01);
//!
//! // Hello {next arg -> arg 0 ("x")} is {arg 2 (0.01) with precision specified in next arg -> arg 1 (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg -> arg 0 ("x")} is {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! While these: <br>而这些：<br>
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! print three significantly different things: <br>打印三个明显不同的内容：<br>
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In some programming languages, the behavior of string formatting functions depends on the operating system's locale setting. <br>在某些编程语言中，字符串格式函数的行为取决于操作系统的语言环境设置。<br>
//! The format functions provided by Rust's standard library do not have any concept of locale and will produce the same results on all systems regardless of user configuration. <br>Rust 标准库提供的格式函数没有任何语言环境的概念，并且无论用户配置如何，在所有系统上都会产生相同的结果。<br>
//!
//! For example, the following code will always print `1.5` even if the system locale uses a decimal separator other than a dot. <br>例如，即使系统区域设置使用小数点分隔符 (而不是点)，以下代码也将始终打印 `1.5`。<br>
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! The literal characters `{` and `}` may be included in a string by preceding them with the same character. <br>字面量字符 `{` 和 `}` 可以通过在它们之前添加相同的字符而包含在字符串中。<br> For example, the `{` character is escaped with `{{` and the `}` character is escaped with `}}`. <br>例如，`{` 字符使用 `{{` 进行转义，而 `}` 字符使用 `}}` 进行转义。<br>
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! To summarize, here you can find the full grammar of format strings. <br>总结一下，您可以在这里找到格式字符串的完整语法。<br>
//! The syntax for the formatting language used is drawn from other languages, so it should not be too alien. <br>所用格式语言的语法是从其他语言中提取的，因此不应太陌生。<br> Arguments are formatted with Python-like syntax, meaning that arguments are surrounded by `{}` instead of the C-like `%`. <br>参数使用类似 Python 的语法格式化，这意味着参数被 `{}` 包围，而不是类似 C 的 `%`。<br>
//! The actual grammar for the formatting syntax is: <br>格式化语法的实际语法为：<br>
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] [ ws ] * '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In the above grammar, <br>在上面的语法中，<br>
//! - `text` must not contain any `'{'` or `'}'` characters, <br>`text` 不得包含任何 `'{'` 或 `'}'` 字符，<br>
//! - `ws` is any character for which [`char::is_whitespace`] returns `true`, has no semantic meaning and is completely optional, <br>`ws` 是 [`char::is_whitespace`] 为其返回 `true` 的任何字符，没有语义意义并且是完全可选的，<br>
//! - `integer` is a decimal integer that may contain leading zeroes and <br>`integer` 是一个十进制整数，可以包含前导零和<br>
//! - `identifier` is an `IDENTIFIER_OR_KEYWORD` (not an `IDENTIFIER`) as defined by the [Rust language reference](https://doc.rust-lang.org/reference/identifiers.html). <br>`identifier` 是由 [Rust 语言参考][Rust language reference](https://doc.rust-lang.org/reference/identifiers.html) 定义的 `IDENTIFIER_OR_KEYWORD` (不是 `IDENTIFIER`)。<br>
//!
//! # Formatting traits <br>格式化 traits<br>
//!
//! When requesting that an argument be formatted with a particular type, you are actually requesting that an argument ascribes to a particular trait. <br>当请求使用特定类型的参数格式化时，实际上是在请求将参数归因于特定的 trait。<br>
//! This allows multiple actual types to be formatted via `{:x}` (like [`i8`] as well as [`isize`]). <br>这允许通过 `{:x}` 格式化多种实际类型 (例如 [`i8`] 和 [`isize`])。<br> The current mapping of types to traits is: <br>类型到 traits 的当前映射是：<br>
//!
//! * *nothing* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] with lower-case hexadecimal integers <br>`x?` ⇒ [`Debug`] 带有小写十六进制整数<br>
//! * `X?` ⇒ [`Debug`] with upper-case hexadecimal integers <br>`X?` ⇒ [`Debug`] 带有大写十六进制整数<br>
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! What this means is that any type of argument which implements the [`fmt::Binary`][`Binary`] trait can then be formatted with `{:b}`. <br>这意味着可以使用 `{:b}` 格式化实现 [`fmt::Binary`][`Binary`] trait 的任何类型的参数。<br> Implementations are provided for these traits for a number of primitive types by the standard library as well. <br>标准库还为许多原始类型提供了针对这些 traits 的实现。<br>
//!
//! If no format is specified (as in `{}` or `{:6}`), then the format trait used is the [`Display`] trait. <br>如果未指定格式 (如 `{}` 或 `{:6}`)，则使用的格式 trait 为 [`Display`] trait。<br>
//!
//! When implementing a format trait for your own type, you will have to implement a method of the signature: <br>当为您自己的类型实现格式 trait 时，您将必须实现签名的方法：<br>
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // our custom type <br>我们的自定义类型<br>
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Your type will be passed as `self` by-reference, and then the function should emit output into the Formatter `f` which implements `fmt::Write`. <br>您的类型将作为 `self` 通过引用传递，然后函数应该将输出发送到实现 `fmt::Write` 的格式化程序 `f`。<br>
//! It is up to each format trait implementation to correctly adhere to the requested formatting parameters. <br>正确遵守所请求的格式设置参数，取决于每种格式 trait 的实现。<br>
//! The values of these parameters can be accessed with methods of the [`Formatter`] struct. <br>这些参数的值可以通过 [`Formatter`] 结构体的方法访问。<br> In order to help with this, the [`Formatter`] struct also provides some helper methods. <br>为了解决这个问题，[`Formatter`] 结构体还提供了一些辅助方法。<br>
//!
//! Additionally, the return value of this function is [`fmt::Result`] which is a type alias of <code>[Result]<(), [std::fmt::Error]></code>. <br>此外，该函数的返回值是 [`fmt::Result`]，它是 <code>[Result]<(), [std::fmt::Error]></code> 的类型别名。<br>
//! Formatting implementations should ensure that they propagate errors from the [`Formatter`] (e.g., when calling [`write!`]). <br>格式化实现应确保它们传播来自 [`Formatter`] 的错误 (例如，调用 [`write!`] 时)。<br>
//! However, they should never return errors spuriously. <br>但是，它们绝不能虚假地返回错误。<br>
//! That is, a formatting implementation must and may only return an error if the passed-in [`Formatter`] returns an error. <br>即，格式化实现必须并且仅在传入的 [`Formatter`] 返回错误的情况下才返回错误。<br>
//! This is because, contrary to what the function signature might suggest, string formatting is an infallible operation. <br>这是因为，与函数签名可能暗示的相反，字符串格式是一项可靠的操作。<br>
//! This function only returns a result because writing to the underlying stream might fail and it must provide a way to propagate the fact that an error has occurred back up the stack. <br>该函数仅返回结果，因为写入底层流可能会失败，并且它必须提供一种方法来将已发生错误的事实传播回栈。<br>
//!
//! An example of implementing the formatting traits would look like: <br>实现格式 traits 的示例如下所示：<br>
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // The `f` value implements the `Write` trait, which is what the write! <br>`f` 值实现 `Write` trait，这就是 `write`！<br> macro is expecting. <br>宏正在等待。<br>
//!         // Note that this formatting ignores the various flags provided to format strings. <br>请注意，这种格式化将忽略为格式化字符串而提供的各种标志。<br>
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Different traits allow different forms of output of a type. <br>不同的 traits 允许类型的不同形式的输出。<br>
//! // The meaning of this format is to print the magnitude of a vector. <br>此格式的含义是打印 vector 的大小。<br>
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respect the formatting flags by using the helper method `pad_integral` on the Formatter object. <br>通过使用 Formatter 对象上的帮助器方法 `pad_integral`，尊重格式设置标志。<br>
//!         // See the method documentation for details, and the function `pad` can be used to pad strings. <br>有关详细信息，请参见方法文档，并且函数 `pad` 可用于填充字符串。<br>
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{myvector}");       // => "(3, 4)"
//!     println!("{myvector:?}");     // => "Vector2D {x: 3, y:4}"
//!     println!("{myvector:10.3b}"); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug` <br>`fmt::Display` 与 `fmt::Debug`<br>
//!
//! These two formatting traits have distinct purposes: <br>这两种格式 traits 具有不同的用途：<br>
//!
//! - [`fmt::Display`][`Display`] implementations assert that the type can be faithfully represented as a UTF-8 string at all times. <br>[`fmt::Display`][`Display`] 实现断言该类型可以始终忠实地表示为 UTF-8 字符串。<br> It is **not** expected that all types implement the [`Display`] trait. <br>并非所有类型都实现 [`Display`] trait。<br>
//! - [`fmt::Debug`][`Debug`] implementations should be implemented for **all** public types. <br>[`fmt::Debug`][`Debug`] 实现应该为所有公共类型实现。<br>
//!   Output will typically represent the internal state as faithfully as possible. <br>输出通常会尽可能忠实地代表内部状态。<br>
//!   The purpose of the [`Debug`] trait is to facilitate debugging Rust code. <br>[`Debug`] trait 的目的是方便调试 Rust 代码。<br> In most cases, using `#[derive(Debug)]` is sufficient and recommended. <br>在大多数情况下，建议使用 `#[derive(Debug)]` 就足够了。<br>
//!
//! Some examples of the output from both traits: <br>这两个 traits 的输出的一些例子：<br>
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Related macros <br>相关宏<br>
//!
//! There are a number of related macros in the [`format!`] family. <br>[`format!`] 系列中有许多相关的宏。<br> The ones that are currently implemented are: <br>当前实现的是：<br>
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above <br>如上所述<br>
//! write!       // first argument is either a &mut io::Write or a &mut fmt::Write, the destination <br>第一个参数是 &mut io::Write 或 &mut fmt::Write，目的地<br>
//! writeln!     // same as write but appends a newline <br>与 write 相同，但追加了一个换行符<br>
//! print!       // the format string is printed to the standard output <br>格式字符串被打印到标准输出<br>
//! println!     // same as print but appends a newline <br>与 print 相同，但追加了一个换行符<br>
//! eprint!      // the format string is printed to the standard error <br>格式字符串被打印到标准错误<br>
//! eprintln!    // same as eprint but appends a newline <br>与 eprint 相同，但追加了一个换行符<br>
//! format_args! // described below. <br>如下面所描述的。<br>
//! ```
//!
//! ### `write!`
//!
//! [`write!`] and [`writeln!`] are two macros which are used to emit the format string to a specified stream. <br>[`write!`] 和 [`writeln!`] 是两个宏，用于将格式字符串发送到指定的流。<br> This is used to prevent intermediate allocations of format strings and instead directly write the output. <br>这用于防止格式字符串的中间分配，而是直接写入输出。<br>
//! Under the hood, this function is actually invoking the [`write_fmt`] function defined on the [`std::io::Write`] and the [`std::fmt::Write`] trait. <br>在底层，这个函数实际上是调用在 [`std::io::Write`] 和 [`std::fmt::Write`] trait 上定义的 [`write_fmt`] 函数。<br>
//! Example usage is: <br>示例用法是：<br>
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! This and [`println!`] emit their output to stdout. <br>此和 [`println!`] 将其输出发送到 stdout。<br> Similarly to the [`write!`] macro, the goal of these macros is to avoid intermediate allocations when printing output. <br>与 [`write!`] 宏类似，这些宏的目标是避免在打印输出时进行中间分配。<br> Example usage is: <br>示例用法是：<br>
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! The [`eprint!`] and [`eprintln!`] macros are identical to [`print!`] and [`println!`], respectively, except they emit their output to stderr. <br>[`eprint!`] 和 [`eprintln!`] 宏分别与 [`print!`] 和 [`println!`] 相同，只不过它们将其输出发送到 stderr。<br>
//!
//! ### `format_args!`
//!
//! [`format_args!`] is a curious macro used to safely pass around an opaque object describing the format string. <br>[`format_args!`] 是一个奇怪的宏，用于安全地传递描述格式字符串的不透明对象。<br> This object does not require any heap allocations to create, and it only references information on the stack. <br>该对象不需要创建任何堆分配，并且仅引用栈上的信息。<br>
//! Under the hood, all of the related macros are implemented in terms of this. <br>在幕后，所有相关的宏都在此方面实现。<br>
//! First off, some example usage is: <br>首先，一些示例用法是：<br>
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! The result of the [`format_args!`] macro is a value of type [`fmt::Arguments`]. <br>[`format_args!`] 宏的结果是 [`fmt::Arguments`] 类型的值。<br>
//! This structure can then be passed to the [`write`] and [`format`] functions inside this module in order to process the format string. <br>然后可以将此结构体传递到此模块内部的 [`write`] 和 [`format`] 函数，以处理格式字符串。<br>
//! The goal of this macro is to even further prevent intermediate allocations when dealing with formatting strings. <br>该宏的目的是在处理格式化字符串时甚至进一步防止中间分配。<br>
//!
//! For example, a logging library could use the standard formatting syntax, but it would internally pass around this structure until it has been determined where output should go to. <br>例如，日志记录库可以使用标准格式语法，但是它将在内部绕过此结构体，直到确定了输出应该到达的位置为止。<br>
//!
//! [`fmt::Result`]: Result "fmt::Result"
//! [Result]: core::result::Result "std::result::Result"
//! [std::fmt::Error]: Error "fmt::Error"
//! [`write`]: write() "fmt::write"
//! [`to_string`]: crate::string::ToString::to_string "ToString::to_string"
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`std::fmt::Write`]: ../../std/fmt/trait.Write.html
//! [`print!`]: ../../std/macro.print.html "print!"
//! [`println!`]: ../../std/macro.println.html "println!"
//! [`eprint!`]: ../../std/macro.eprint.html "eprint!"
//! [`eprintln!`]: ../../std/macro.eprintln.html "eprintln!"
//! [`format_args!`]: ../../std/macro.format_args.html "format_args!"
//! [`fmt::Arguments`]: Arguments "fmt::Arguments"
//! [`format`]: format() "fmt::format"
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

#[cfg(not(no_global_oom_handling))]
use crate::string;

/// The `format` function takes an [`Arguments`] struct and returns the resulting formatted string. <br>`format` 函数采用 [`Arguments`] 结构体，并返回生成的格式化字符串。<br>
///
///
/// The [`Arguments`] instance can be created with the [`format_args!`] macro. <br>可以使用 [`format_args!`] 宏创建 [`Arguments`] 实例。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Please note that using [`format!`] might be preferable. <br>请注意，使用 [`format!`] 可能更可取。<br>
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[cfg(not(no_global_oom_handling))]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub fn format(args: Arguments<'_>) -> string::String {
    fn format_inner(args: Arguments<'_>) -> string::String {
        let capacity = args.estimated_capacity();
        let mut output = string::String::with_capacity(capacity);
        output.write_fmt(args).expect("a formatting trait implementation returned an error");
        output
    }

    args.as_str().map_or_else(|| format_inner(args), crate::borrow::ToOwned::to_owned)
}
