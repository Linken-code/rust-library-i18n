use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Writing a test of integration between third-party allocators and `RawVec` is a little tricky because the `RawVec` API does not expose fallible allocation methods, so we cannot check what happens when allocator is exhausted (beyond detecting a panic). <br>编写第三方分配器和 `RawVec` 之间的集成测试有点棘手，因为 `RawVec` API 不会公开容易出错的分配方法，因此我们无法检查分配器用尽时会发生什么 (除了检测到 panic 之外)。<br>
    //
    //
    // Instead, this just checks that the `RawVec` methods do at least go through the Allocator API when it reserves storage. <br>相反，这仅检查 `RawVec` 方法在保留存储空间时是否至少通过了 Allocator API。<br>
    //
    //
    //
    //
    //

    // A dumb allocator that consumes a fixed amount of fuel before allocation attempts start failing. <br>一个愚蠢的分配器，在分配尝试开始失败之前消耗固定量的燃料。<br>
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (causes a realloc, thus using 50 + 150 = 200 units of fuel) <br>(导致重新分配，因此使用 50 + 150=200 单位燃料)<br>
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // First, `reserve` allocates like `reserve_exact`. <br>首先，`reserve` 像 `reserve_exact` 一样进行分配。<br>
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 is more than double of 7, so `reserve` should work like `reserve_exact`. <br>97 大于 7 的两倍，因此 `reserve` 应该像 `reserve_exact` 一样工作。<br>
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 is less than half of 12, so `reserve` must grow exponentially. <br>3 小于 12 的一半，因此 `reserve` 必须成倍增长。<br>
        // At the time of writing this test grow factor is 2, so new capacity is 24, however, grow factor of 1.5 is OK too. <br>在撰写本文时，该测试的增长因子为 2，因此新容量为 24，但是，1.5 的增长因子也可以。<br>
        //
        // Hence `>= 18` in assert. <br>因此，`>= 18` 处于断言状态。<br>
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}

struct ZST;

// A `RawVec` holding zero-sized elements should always look like this. <br>包含零大小元素的 `RawVec` 应始终如下所示。<br>
fn zst_sanity<T>(v: &RawVec<T>) {
    assert_eq!(v.capacity(), usize::MAX);
    assert_eq!(v.ptr(), core::ptr::Unique::<T>::dangling().as_ptr());
    assert_eq!(v.current_memory(), None);
}

#[test]
fn zst() {
    let cap_err = Err(crate::collections::TryReserveErrorKind::CapacityOverflow.into());

    assert_eq!(std::mem::size_of::<ZST>(), 0);

    // All these different ways of creating the RawVec produce the same thing. <br>所有这些创建 RawVec 的不同方式产生相同的结果。<br>

    let v: RawVec<ZST> = RawVec::new();
    zst_sanity(&v);

    let v: RawVec<ZST> = RawVec::with_capacity_in(100, Global);
    zst_sanity(&v);

    let v: RawVec<ZST> = RawVec::with_capacity_in(100, Global);
    zst_sanity(&v);

    let v: RawVec<ZST> = RawVec::allocate_in(0, AllocInit::Uninitialized, Global);
    zst_sanity(&v);

    let v: RawVec<ZST> = RawVec::allocate_in(100, AllocInit::Uninitialized, Global);
    zst_sanity(&v);

    let mut v: RawVec<ZST> = RawVec::allocate_in(usize::MAX, AllocInit::Uninitialized, Global);
    zst_sanity(&v);

    // Check all these operations work as expected with zero-sized elements. <br>使用零大小元素检查所有这些操作是否按预期工作。<br>

    assert!(!v.needs_to_grow(100, usize::MAX - 100));
    assert!(v.needs_to_grow(101, usize::MAX - 100));
    zst_sanity(&v);

    v.reserve(100, usize::MAX - 100);
    // v.reserve(101, usize::MAX - 100); // panics, in `zst_reserve_panic` below <br>// panics，在下面的 `zst_reserve_panic` 中<br>
    zst_sanity(&v);

    v.reserve_exact(100, usize::MAX - 100);
    // v.reserve_exact(101, usize::MAX - 100); // panics, in `zst_reserve_exact_panic` below <br>// panics，在下面的 `zst_reserve_exact_panic` 中<br>
    zst_sanity(&v);

    assert_eq!(v.try_reserve(100, usize::MAX - 100), Ok(()));
    assert_eq!(v.try_reserve(101, usize::MAX - 100), cap_err);
    zst_sanity(&v);

    assert_eq!(v.try_reserve_exact(100, usize::MAX - 100), Ok(()));
    assert_eq!(v.try_reserve_exact(101, usize::MAX - 100), cap_err);
    zst_sanity(&v);

    assert_eq!(v.grow_amortized(100, usize::MAX - 100), cap_err);
    assert_eq!(v.grow_amortized(101, usize::MAX - 100), cap_err);
    zst_sanity(&v);

    assert_eq!(v.grow_exact(100, usize::MAX - 100), cap_err);
    assert_eq!(v.grow_exact(101, usize::MAX - 100), cap_err);
    zst_sanity(&v);
}

#[test]
#[should_panic(expected = "capacity overflow")]
fn zst_reserve_panic() {
    let mut v: RawVec<ZST> = RawVec::new();
    zst_sanity(&v);

    v.reserve(101, usize::MAX - 100);
}

#[test]
#[should_panic(expected = "capacity overflow")]
fn zst_reserve_exact_panic() {
    let mut v: RawVec<ZST> = RawVec::new();
    zst_sanity(&v);

    v.reserve_exact(101, usize::MAX - 100);
}
