//! Utilities related to FFI bindings. <br>与 FFI 绑定有关的实用工具。<br>
//!
//! This module provides utilities to handle data across non-Rust interfaces, like other programming languages and the underlying operating system. <br>该模块提供了实用工具来处理跨非 Rust 接口的数据，例如其他编程语言和底层操作系统。<br> It is mainly of use for FFI (Foreign Function Interface) bindings and code that needs to exchange C-like strings with other languages. <br>它主要用于 FFI (外部函数接口) 绑定和需要与其他语言交换类 C 字符串的代码。<br>
//!
//! # Overview
//!
//! Rust represents owned strings with the [`String`] type, and borrowed slices of strings with the [`str`] primitive. <br>Rust 代表 [`String`] 类型的拥有的字符串，而借用 [`str`] 原语的字符串切片。<br> Both are always in UTF-8 encoding, and may contain nul bytes in the middle, i.e., if you look at the bytes that make up the string, there may be a `\0` among them. <br>两者始终都是 UTF-8 编码，并且中间可能包含 nul 个字节，即，如果您查看组成字符串的字节，则其中可能有一个 `\0`。<br>
//! Both `String` and `str` store their length explicitly; <br>`String` 和 `str` 都明确存储它们的长度。<br> there are no nul terminators at the end of strings like in C. <br>像 C 中的字符串末尾没有 nul 终止符。<br>
//!
//! C strings are different from Rust strings: <br>C 字符串不同于 Rust 字符串：<br>
//!
//! * **Encodings** - Rust strings are UTF-8, but C strings may use other encodings. <br>**编码**-Rust 字符串是 UTF-8，但是 C 字符串可以使用其他编码。<br> If you are using a string from C, you should check its encoding explicitly, rather than just assuming that it is UTF-8 like you can do in Rust. <br>如果使用的是来自 C 的字符串，则应显式检查其编码，而不是像在 Rust 中那样假定它是 UTF-8。<br>
//!
//! * **Character size** - C strings may use `char` or `wchar_t`-sized characters; <br>**字符大小**-C 字符串可以使用 `char` 或 `wchar_t` 大小的字符；<br> please **note** that C's `char` is different from Rust's. <br>请 **注意** C 的 `char` 与 Rust 的不同。<br>
//! The C standard leaves the actual sizes of those types open to interpretation, but defines different APIs for strings made up of each character type. <br>C 标准使这些类型的实际大小易于解释，但是为由每个字符类型组成的字符串定义了不同的 API。<br> Rust strings are always UTF-8, so different Unicode characters will be encoded in a variable number of bytes each. <br>Rust 字符串始终为 UTF-8，因此每个不同的 Unicode 字符将以可变的字节数进行编码。<br>
//! The Rust type [`char`] represents a '[Unicode scalar value]', which is similar to, but not the same as, a '[Unicode code point]'. <br>Rust 类型 [`char`] 表示 `[Unicode 标量值]`，与 `[Unicode 代码点]` 相似但不相同。<br>
//!
//! * **Nul terminators and implicit string lengths** - Often, C strings are nul-terminated, i.e., they have a `\0` character at the end. <br>**Nul 终止符和隐式字符串长度**-C 字符串通常以 Nul 终止，即，它们的末尾有 `\0` 字符。<br>
//! The length of a string buffer is not stored, but has to be calculated; <br>字符串缓冲区的长度不存储，而是必须计算；<br> to compute the length of a string, C code must manually call a function like `strlen()` for `char`-based strings, or `wcslen()` for `wchar_t`-based ones. <br>要计算字符串的长度，C 代码必须手动调用一个函数，例如 `strlen()` 表示基于 char 的字符串，`wcslen()` 表示基于 wchar_t 的字符串。<br>
//! Those functions return the number of characters in the string excluding the nul terminator, so the buffer length is really `len+1` characters. <br>这些函数返回字符串中不包括 nul 终止符的字符数，因此缓冲区长度实际上是 `len+1` 字符。<br>
//! Rust strings don't have a nul terminator; <br>Rust 字符串没有 nul 终止符；<br> their length is always stored and does not need to be calculated. <br>它们的长度总是存储的，不需要计算。<br>
//! While in Rust accessing a string's length is an *O*(1) operation (because the length is stored); <br>而在 Rust 中，访问字符串的长度是一个 *O*(1) 操作 (因为长度是被存储的) ；<br> in C it is an *O*(*n*) operation because the length needs to be computed by scanning the string for the nul terminator. <br>在 C 中，它是一个 *O*(*n*) 操作，因为需要通过扫描字符串中的 nul 终止符来计算长度。<br>
//!
//! * **Internal nul characters** - When C strings have a nul terminator character, this usually means that they cannot have nul characters in the middle — a nul character would essentially truncate the string. <br>**内部 nul 字符**- 当 C 字符串具有 nul 终止符时，这通常意味着它们中间不能包含 nul 字符 - nul 字符实际上会截断字符串。<br>
//! Rust strings *can* have nul characters in the middle, because nul does not have to mark the end of the string in Rust. <br>Rust 字符串 *可以* 中间有 nul 个字符，因为 nul 不必在 Rust 中标记字符串的结尾。<br>
//!
//! # Representations of non-Rust strings <br>非 Rust 字符串的表示形式<br>
//!
//! [`CString`] and [`CStr`] are useful when you need to transfer UTF-8 strings to and from languages with a C ABI, like Python. <br>[`CString`] 和 [`CStr`] 在您需要将 UTF-8 字符串与带有 C ABI 的语言 (如 Python) 相互传输时很有用。<br>
//!
//! * **From Rust to C:** [`CString`] represents an owned, C-friendly string: it is nul-terminated, and has no internal nul characters. <br>**从 Rust 到 C:**[`CString`] 表示一个拥有的，对 C 友好的字符串：它是 nul 终止的，并且没有内部 nul 字符。<br>
//! Rust code can create a [`CString`] out of a normal string (provided that the string doesn't have nul characters in the middle), and then use a variety of methods to obtain a raw <code>\*mut [u8]</code> that can then be passed as an argument to functions which use the C conventions for strings. <br>Rust 代码可以从一个普通字符串中创建一个 [`CString`] (前提是该字符串中间没有 nul 字符)，然后使用多种方法获得一个原始的 <code>\*mut [u8]</code>，然后可以作为参数传递给使用字符串的 C 约定的函数。<br>
//!
//!
//! * **From C to Rust:** [`CStr`] represents a borrowed C string; <br>**从 C 到 Rust:**[`CStr`] 表示借用的 C 字符串；<br> it is what you would use to wrap a raw <code>\*const [u8]</code> that you got from a C function. <br>它是您用来包装从 C 函数获得的原始 <code>\*const [u8]</code> 的内容。<br> A [`CStr`] is guaranteed to be a nul-terminated array of bytes. <br>[`CStr`] 保证是一个以 nul 结尾的字节数组。<br>
//! Once you have a [`CStr`], you can convert it to a Rust <code>&[str]</code> if it's valid UTF-8, or lossily convert it by adding replacement characters. <br>一旦您有了 [`CStr`]，您可以将它转换为 Rust <code>&[str]</code>，如果它是有效的 UTF-8，或者通过添加替换字符来有损地转换它。<br>
//!
//! [`String`]: crate::string::String
//! [`CStr`]: core::ffi::CStr
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "alloc_ffi", since = "1.64.0")]

#[stable(feature = "alloc_c_string", since = "1.64.0")]
pub use self::c_str::FromVecWithNulError;
#[stable(feature = "alloc_c_string", since = "1.64.0")]
pub use self::c_str::{CString, IntoStringError, NulError};

mod c_str;
